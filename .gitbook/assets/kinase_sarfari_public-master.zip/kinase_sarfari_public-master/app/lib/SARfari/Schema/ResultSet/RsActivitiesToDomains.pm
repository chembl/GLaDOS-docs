package SARfari::Schema::ResultSet::RsActivitiesToDomains;
# $Id: RsActivitiesToDomains.pm 155 2009-08-25 11:02:39Z mdavies $

# SEE LICENSE

use strict;
use warnings;
use base 'DBIx::Class::ResultSet';
use Carp;

1;
