package SARfari::Controller::Admin;
# $Id: Admin.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;
use base 'Catalyst::Controller';

sub auto : Private {
    my ( $self, $c ) = @_;
}

sub index : Private {
    my ( $self, $c ) = @_;

    $c->stash->{body} = "home.tt";
}

sub clear_expired_session_data : Private {
    my ( $self, $c ) = @_;
    
    $c->model('SARfariDB::Dual')->sessionClean();
}

1;
