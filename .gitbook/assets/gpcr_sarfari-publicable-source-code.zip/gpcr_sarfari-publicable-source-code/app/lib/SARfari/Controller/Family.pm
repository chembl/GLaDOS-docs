package SARfari::Controller::Family;
# $Id: Family.pm 624 2010-07-20 15:11:36Z mdavies $

# SEE LICENSE

use strict;
use warnings;
use base 'SARfari::BaseController::Search';
use Data::Dumper;
use Scalar::Util qw (reftype);

sub auto : Private {
    my ( $self, $c ) = @_;
    $c->stash->{subtitle} = "Family";
}

sub index : Private {
    my ( $self, $c ) = @_;

    #delete $c->session->{user_selection};
    
    if(lc($c->config->{family}) eq 'kinase' ){
    	$c->stash->{body} = "family/kinase_family_home.tt";
    } elsif (lc($c->config->{family}) eq 'gpcr'){
    	$c->stash->{body} = "family/gpcr_family_home.tt";
    } else{
		Catalyst::Exception->throw(
            "Family not set in config file");
    }
}

sub wheel_select : Local {
    my ( $self, $c ) = @_;
    
    if ( $c->req->params->{name} && $c->req->params->{level} ) {
        
        my $filter;
        
        if($c->req->params->{level} > 1){
        	$filter = " trim(upper(classification.level".$c->req->params->{level}.")) = '".uc($c->req->params->{name})."'"; 
        }   
        
        #Run query
        my $class_rs = $c->model('SARfariDB::ProtDomain')->search(
                undef,
                {   select => [qw/ dom_id drugstore starlite /],
                	join   => [ { 'gene_domain' => 'classification' } ]
                });
         
        my $query = ($c->req->params->{level} > 1) 
                    ? [$class_rs->search_literal($filter)->cursor->all]
                    : [$class_rs->cursor->all];
                            
        my $class_data = {};
        $class_data->{count}     = 0;
        $class_data->{starlite}  = 0;
        $class_data->{drugstore} = 0;
        
        foreach my $row (@{$query}){
            $class_data->{count}++;
            if($row->[1]){ $class_data->{starlite}  += $row->[1]; }
            if($row->[2]){ $class_data->{drugstore} += $row->[2]; }
        }
        
        my $json =  "\"count\": $class_data->{count}, \"starlite\": $class_data->{starlite}, \"drugstore\": $class_data->{drugstore}";
                
        $c->res->body( '{'.$json.'}' );
    }
}

sub wheel_search : Local {
    my ( $self, $c ) = @_;
    
    my $DOMIDS = {};
            
    if ( $c->req->params->{wheel_query} ) {
        
        #Capture ksdid sub-selection as hash look-up
        my $reftype = reftype $c->req->params->{'wheel_query'};

        my $wheel_filter = ($reftype &&  $reftype eq "ARRAY")
                          ?  $c->req->params->{'wheel_query'}
                          : [$c->req->params->{'wheel_query'}];                
        
        foreach my $filter (@{$wheel_filter}){
            my ($level, $family) = split(/\:/,$filter);
                
                my $filter;
                
                if($level > 1){
        	        $filter = " trim(upper(classification.level$level)) = '".uc($family)."'"; 
                }
                  
                my $class_rs = $c->model('SARfariDB::ProtDomain')->search(
                undef,
                {   select => [qw/ dom_id /],
                	join   => [ { 'gene_domain' => 'classification' } ]
                });
         
                my $ids = ($level > 1) 
                    ? [  map { $_->[0] } $class_rs->search_literal($filter)->cursor->all ]
                    : [  map { $_->[0] } $class_rs->cursor->all ];
            
                foreach my $id (@{$ids}){
                    $DOMIDS->{$id} = 1;
                }
        }                
    }
        
    $c->req->params->{'targetType'} = "domid";
    $c->req->params->{'targetList'} = join("\n", keys%{$DOMIDS} );
    
    $c->detach('/protein/search');
}

sub userSelect : Local {
    my ( $self, $c ) = @_;

    if (   $c->req->params->{level2}
        && $c->req->params->{level3}
        && $c->req->params->{level4} ) {

        my $l2 = $c->req->params->{level2};
        my $l3 = $c->req->params->{level3};
        my $l4 = $c->req->params->{level4};
                 
        # Check search not already done
        if ( !$c->session->{user_selection}
            ->{ $l2 . "--" . $l3 . "--" . $l4 } ) {

            my $select_cols = [
                'me.level3',       'me.level4',
                'me.starlite',     'me.drugstore',
                'me.domain_count', 'me.reference_count',
                'me.level2',
            ];

            my $details = [
                $c->model('SARfariDB::AppFamilyBrowse')->search(
                    {   'me.level2' => $l2,
                        'me.level3' => $l3,
                        'me.level4' => $l4
                    },
                    { select => $select_cols }
                    )->cursor->all
            ];

            my $json =
                [ map { map_columns( $_, $select_cols ) } @{$details} ];
            
            # Add to session
			$c->session->{user_selection}->{ $l2 . "--" . $l3 . "--" . $l4 } = $json;

            $c->res->body( '[' . join( ', ', @{$json} ) . ']' );
        }
        else {
            $c->res->body('{}');
        }
    }
}

sub userSelectCache : Local {
    my ( $self, $c ) = @_;
  
        # Check search not already done
        if (values %{$c->session->{user_selection}} ) {

            my @json = map { @{$_} } values %{$c->session->{user_selection}};
            
            $c->res->body( '[' . join( ', ', @json ) . ']' );
        }
        else {        	
            $c->res->body('{}');
        }
}

sub deleteThis : Local {
    my ( $self, $c ) = @_;

    if (   $c->req->params->{level2}
        && $c->req->params->{level3}
        && $c->req->params->{level4} ) {

        my $l2 = $c->req->params->{level2};
        my $l3 = $c->req->params->{level3};
        my $l4 = $c->req->params->{level4};

        # Check search not already done
        if ($c->session->{user_selection}->{ $l2 . "--" . $l3 . "--" . $l4 } )
        {
            delete $c->session->{user_selection}
                ->{ $l2 . "--" . $l3 . "--" . $l4 };
        }
    }
        
    $c->res->body('{}');
}

sub getSelected : Local {
    my ( $self, $c ) = @_;

    my $json = '['
        . join( ', ',
        map { '\'' . $_ . '\'' } keys %{ $c->session->{user_selection} } )
        . ']';

    $c->res->body($json);
}

sub level2Search : Local {
    my ( $self, $c ) = @_;

    if ( $c->req->params->{level2} ) {

        my $select_cols = [
            'me.level3',       'me.level4',
            'me.starlite',     'me.drugstore',
            'me.domain_count', 'me.reference_count'
        ];

        my $details = [
            $c->model('SARfariDB::AppFamilyBrowse')->search(
                'me.level2' => $c->req->params->{level2},
                { select => $select_cols }
                )->cursor->all
        ];

        my $json = [ map { map_columns( $_, $select_cols ) } @{$details} ];

        $c->res->body( '[' . join( ', ', @{$json} ) . ']' );
    }
}

sub map_columns {
    my $data = shift;
    my $cols = shift;

    my $mapped = [];

    for ( my $i = 0; $i < scalar( @{$data} ); $i++ ) {
        my $tmp = $cols->[$i];
        $tmp =~ s/^\w+\.//;    # Remove table alias
        push( @{$mapped}, "'$tmp': '$data->[$i]'" );
    }

    return "{" . join( ', ', @{$mapped} ) . "}";
}

sub treeSearch : Local {
    my ( $self, $c ) = @_;

    my $DOMIDS = {};

    foreach my $class ( keys %{ $c->session->{user_selection} } ) {
        my ( $l2, $l3, $l4 ) = split( /--/, $class );

        my $filter = "   (trim(classification.level2) = \'$l2\' 
                      AND trim(classification.level3) = \'$l3\'
                      AND trim(classification.level4) = \'$l4\')";

        my $ids = [
            $c->model('SARfariDB::ProtDomain')->search(
                undef,
                {   select => [qw/ dom_id /],
                    join   => [ { 'gene_domain' => 'classification' } ]
                }
                )->search_literal($filter)->cursor->all
        ];

        foreach my $id ( @{$ids} ) {
            $DOMIDS->{ $id->[0] } = 1;
        }
    }    

    $c->req->params->{'targetType'} = "domid";
    $c->req->params->{'targetList'} = join( "\n", keys %{$DOMIDS} );

    #delete $c->session->{user_selection};

    $c->detach('/protein/search');
}

1;
