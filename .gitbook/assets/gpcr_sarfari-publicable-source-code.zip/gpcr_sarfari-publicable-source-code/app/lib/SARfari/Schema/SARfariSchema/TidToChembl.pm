package SARfari::Schema::SARfariSchema::TidToChembl;

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table("tid_to_chembl");

__PACKAGE__->add_columns(
    "tid",    { data_type => "integer", is_nullable => 0, size => undef },
    "chembl_id", { data_type => "VARCHAR2", is_nullable => 0, size => undef }
);

__PACKAGE__->set_primary_key( 'tid', 'chembl_id' );

1;
