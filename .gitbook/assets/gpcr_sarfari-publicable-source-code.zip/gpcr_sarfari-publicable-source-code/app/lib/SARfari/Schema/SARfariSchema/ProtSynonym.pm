package SARfari::Schema::SARfariSchema::ProtSynonym;
# $Id: ProtSynonym.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table("PROT_SYNONYM");
__PACKAGE__->add_columns(
  "int_pk",
  { data_type => "NUMBER", is_nullable => 0, size => undef },
  "dom_id",
  { data_type => "INTEGER", is_nullable => 0, size => undef },
  "syn",
  { data_type => "TEXT", is_nullable => 0, size => undef },
);

1;
