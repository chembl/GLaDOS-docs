package SARfari::Schema::SARfariSchema::StarliteToSarfari;
# $Id: StarliteToSarfari.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table("starlite_to_sarfari");

__PACKAGE__->add_columns(
    "tid",    { data_type => "integer", is_nullable => 0, size => undef },
    "dom_id", { data_type => "integer", is_nullable => 0, size => undef }    
);

__PACKAGE__->set_primary_key( 'tid', 'dom_id' );

1;
