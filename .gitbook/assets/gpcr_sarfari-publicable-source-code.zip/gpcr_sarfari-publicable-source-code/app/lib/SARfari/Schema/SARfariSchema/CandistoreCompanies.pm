package SARfari::Schema::SARfariSchema::CandistoreCompanies;
# $Id: CandistoreCompanies.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table("candistore_companies");

__PACKAGE__->add_columns(
    "company_id",
    { data_type => "integer", is_nullable => 0, size => undef },
    "company_name",
    { data_type => "varchar2", is_nullable => 0, size => undef },
);

__PACKAGE__->set_primary_key('company_id');

1;
