package SARfari::Schema::SARfariSchema::CompoundImages;
# $Id: CompoundImages.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table("COMPOUND_IMAGES");
__PACKAGE__->add_columns(
    "sarregno",
    { data_type => "INTEGER", is_nullable => 0, size => undef },
    "image",
    { data_type => "BLOB", is_nullable => 0, size => undef },
);

__PACKAGE__->set_primary_key('sarregno');

1;
