package SARfari::Schema::SARfariSchema::X3dGpcrStructures;
# $Id: X3dGpcrStructures.pm 2011 kaz manually created $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table("x3d_gpcr_structures");

__PACKAGE__->add_columns(
    "structure_id", { data_type => 'integer',  is_nullable => 0 },
    "unique_id",    { data_type => 'varchar2', is_nullable => 1 },
    "pdb_code",     { data_type => 'varchar2', is_nullable => 1 },
    "chain",        { data_type => 'varchar2', is_nullable => 1 },
    "accession",    { data_type => 'varchar2', is_nullable => 1 },
    "name",         { data_type => 'varchar2', is_nullable => 1 },
    "ligand",       { data_type => 'varchar2', is_nullable => 1 },
    "species",      { data_type => 'varchar2', is_nullable => 1 },
    "resolution",   { data_type => 'number',   is_nullable => 1 },
    "date_released",{ data_type => 'date',     is_nullable => 1 },
    "a",            { data_type => 'number',   is_nullable => 1 },
    "b",            { data_type => 'number',   is_nullable => 1 },
    "c",            { data_type => 'number',   is_nullable => 1 },
    "alpha",        { data_type => 'number',   is_nullable => 1 },
    "beta",         { data_type => 'number',   is_nullable => 1 },
    "gamma",        { data_type => 'number',   is_nullable => 1 },
    "space_group",  { data_type => 'varchar2', is_nullable => 1 }
);

__PACKAGE__->set_primary_key('structure_id');

1;
