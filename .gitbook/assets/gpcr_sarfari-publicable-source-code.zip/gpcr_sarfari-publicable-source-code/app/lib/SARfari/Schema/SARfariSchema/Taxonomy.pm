package SARfari::Schema::SARfariSchema::Taxonomy;
# $Id: Taxonomy.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table("TAXONOMY");
__PACKAGE__->add_columns(
  "tax_id",
  { data_type => "INTEGER", is_nullable => 0, size => undef },
  "name",
  { data_type => "TEXT", is_nullable => 0, size => undef },
  "rank",
  { data_type => "TEXT", is_nullable => 0, size => undef },
);

1;
