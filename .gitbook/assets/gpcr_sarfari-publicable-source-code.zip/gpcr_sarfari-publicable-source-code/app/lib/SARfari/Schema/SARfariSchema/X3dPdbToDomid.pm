package SARfari::Schema::SARfariSchema::X3dPdbToDomid;

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table("x3d_pdb_to_domid");

__PACKAGE__->add_columns(
    "dom_id",       { data_type => 'integer',  is_nullable => 1 },
    "accession",    { data_type => 'varchar2', is_nullable => 1 },
    "pdb_code",     { data_type => 'varchar2', is_nullable => 1 },
    "chain",        { data_type => 'varchar2', is_nullable => 1 },
    "name",         { data_type => 'varchar2', is_nullable => 1 },
    "ligand",       { data_type => 'varchar2', is_nullable => 1 },
    "species",      { data_type => 'varchar2', is_nullable => 1 },
    "resolution",   { data_type => 'number',   is_nullable => 1 },
    "date_created", { data_type => 'date',     is_nullable => 1 }
);

__PACKAGE__->set_primary_key('pdb_code','chain');

1;
