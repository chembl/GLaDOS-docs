package SARfari::Schema::SARfariSchema::X3dFeature;
# $Id: X3dFeature.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table('x3d_feature');

__PACKAGE__->add_columns(
    "feature_id",   { data_type => 'integer',  is_nullable => 1 },
    "feature_name", { data_type => 'varchar2', is_nullable => 1 }
);

__PACKAGE__->set_primary_key('feature_id');

1;
