package SARfari::Schema::ResultSet::RsActivitiesToDomains;
# $Id: RsActivitiesToDomains.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;
use base 'DBIx::Class::ResultSet';
use Carp;

1;
