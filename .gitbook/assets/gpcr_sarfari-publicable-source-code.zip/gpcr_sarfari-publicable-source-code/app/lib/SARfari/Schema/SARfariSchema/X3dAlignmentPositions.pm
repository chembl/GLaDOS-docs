package SARfari::Schema::SARfariSchema::X3dAlignmentPositions;
# $Id: X3dAlignmentPositions.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table('x3d_alignment_positions');

__PACKAGE__->add_columns(
    "px",         { data_type => 'integer',  is_nullable => 0 },
    "seq_pos",    { data_type => 'integer',  is_nullable => 0 },
    "residue",    { data_type => 'varchar2', is_nullable => 1 },
    "aln_pos",    { data_type => 'integer',  is_nullable => 0 },
    "pdb_resnum", { data_type => 'varchar2', is_nullable => 0 }
);

__PACKAGE__->has_many(
    site_defs => 'SARfari::Schema::SARfariSchema::SiteDefinitions',
    { 'foreign.aln_pos' => 'self.aln_pos' }
);

1;
