package SARfari::Schema::SARfariSchema::CompoundParents;
# $Id: CompoundParents.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table("COMPOUND_PARENTS");
__PACKAGE__->add_columns(
    "sarregno",
    { data_type => "INTEGER", is_nullable => 0, size => undef },
    "parent_sarregno",
    { data_type => "INTEGER", is_nullable => 0, size => undef },
);

__PACKAGE__->set_primary_key('sarregno','parent_sarregno');

1;
