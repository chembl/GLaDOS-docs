package SARfari::Schema::SARfariSchema::Dual;
# $Id: Dual.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use base 'DBIx::Class';
use Data::Dumper;

__PACKAGE__->load_components(qw/ Core /);

__PACKAGE__->table('dual');

__PACKAGE__->resultset_class('SARfari::Schema::ResultSet::RsDual');

1;
