package SARfari::Schema::SARfariSchema::X3dGpcrPdbToDomid;
# $Id: X3dGpcrPdbToDomid.pm 2011 kaz manually created $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table('x3d_gpcr_pdb_to_domid');

__PACKAGE__->resultset_class('SARfari::Schema::ResultSet::RsX3dPdbDomain');    

__PACKAGE__->add_columns(
    "structure_id",       { data_type => 'number',   is_nullable => 0 },
    "dom_id",             { data_type => 'number',   is_nullable => 0 },
    "percent_identity",   { data_type => 'number',   is_nullable => 1 }
);

__PACKAGE__->set_primary_key('structure_id','dom_id');

__PACKAGE__->belongs_to( structure => 'SARfari::Schema::SARfariSchema::X3dGpcrStructures',
  { 'foreign.structure_id' => 'self.structure_id' });


1;
