package SARfari::Schema::SARfariSchema;
# $Id: SARfariSchema.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_classes;


# Created by DBIx::Class::Schema::Loader v0.04004 @ 2008-03-12 16:23:41
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:b2ap4gfmrBcK2xTFRqrFvQ


# You can replace this text with custom content, and it will be preserved on regeneration
1;
