package SARfari::Schema::SARfariSchema::Aaindex;
# $Id: Aaindex.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table("AAINDEX");

__PACKAGE__->add_columns(    
    "aaindex_id",
    { data_type => "TEXT", is_nullable => 0, size => undef },
    "description",
    { data_type => "TEXT", is_nullable => 0, size => undef },
    "litdb",
    { data_type => "TEXT", is_nullable => 0, size => undef },
    "pubmed",
    { data_type => "NUMBER", is_nullable => 0, size => undef },
);

__PACKAGE__->set_primary_key('aaindex_id');

1;
