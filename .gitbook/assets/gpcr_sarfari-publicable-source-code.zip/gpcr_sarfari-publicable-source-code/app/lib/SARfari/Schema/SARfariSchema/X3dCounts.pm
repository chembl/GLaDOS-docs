package SARfari::Schema::SARfariSchema::X3dCounts;
# $Id: X3dCounts.pm 622 2010-07-19 13:41:24Z sarfari $

# SEE LICENSE

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");

__PACKAGE__->table('x3d_counts');

__PACKAGE__->add_columns(
    "sunid_px",         { data_type => 'integer', is_nullable => 1 },
    "dom_id",           { data_type => 'integer', is_nullable => 1 },
    "transcript",       { data_type => 'integer', is_nullable => 1 },
    "gene_domain_name", { data_type => 'integer', is_nullable => 1 },
    "bio_all",          { data_type => 'integer', is_nullable => 1 },
    "comp_all",         { data_type => 'integer', is_nullable => 1 },
    "ds_count",         { data_type => 'integer', is_nullable => 1 } 
);

__PACKAGE__->set_primary_key('sunid_px');

1;
