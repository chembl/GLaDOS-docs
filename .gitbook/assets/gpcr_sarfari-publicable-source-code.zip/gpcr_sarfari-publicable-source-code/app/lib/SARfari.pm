package SARfari;
# $Id: SARfari.pm 761 2011-09-15 14:38:49Z mdavies $

# SEE LICENSE

use strict;
use warnings;

use Catalyst::Runtime '5.70';

use Catalyst qw/
    ConfigLoader
    
    Static::Simple

    Session
    Session::Store::Memcached
    Session::State::Cookie

    Scheduler
    
    Browser
    /;

    #Session::Store::Memcached::Fast
    #Session::Store::FastMmap
our $VERSION = '0.01';

print "
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!                                                         !
! Remember to include sarfari_local.yml for live releases !
!                                                         !
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
";

if($ENV{'DATACENTRE'}){	
	__PACKAGE__->config( 'Plugin::ConfigLoader' => {
        config_local_suffix => $ENV{'DATACENTRE'}
    });
}

# Start the application
__PACKAGE__->setup;

# Schedule configuration
__PACKAGE__->schedule(
    at    => '* 0 * * *',
    event => '/admin/clear_expired_session_data'                        
);

1;
