'''
RDKit module for ADMESarfari
Should cover machine learning and other cheminformatic request.
@author:Nathan Dedman
@company: EBI, Hinxton.
'''

import os,re,cPickle,sys
# So we can grab file locations, load in the pyramid settings registry.
from pyramid.threadlocal import get_current_registry


import pandas as pd

# RDKit imports
from rdkit import Chem
from rdkit.Chem import AllChem
#from rdkit.Chem import PandasTools
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import ChemicalFeatures
from rdkit.Chem.Pharm2D.SigFactory import SigFactory
from rdkit.Chem.Pharm2D import Generate


#SciKit Learn imports

from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import GaussianNB,MultinomialNB,BernoulliNB
from sklearn import cross_validation,svm
from sklearn.cross_validation import KFold,LeaveOneOut

from sklearn import metrics
from sklearn.metrics import roc_curve, auc ,classification_report, confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import BernoulliRBM

import numpy as np
from scipy import stats

from sklearn.svm import SVC
from sklearn.cross_validation import StratifiedKFold
from sklearn.feature_selection import RFECV
from sklearn.datasets import make_classification
from sklearn.metrics import zero_one_loss
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectPercentile, SelectKBest, f_classif, chi2
from sklearn import preprocessing


from sklearn.svm import SVC
from sklearn.cross_validation import StratifiedKFold
from sklearn.feature_selection import RFECV
from sklearn.datasets import make_classification
from sklearn.metrics import zero_one_loss


# Pyramid imports
from sqlalchemy.exc import DBAPIError
from sqlalchemy import *

# Others
from math import fabs
from scipy.sparse import *
import tempfile,subprocess

import Logger

# Allow to run in a headless environment by changing backend to image file.
import matplotlib
matplotlib.use('Agg')

import numpy as np
import matplotlib.pyplot as plt





class chemworker(object):
    ''' Runs the predicition, molecular manipulation, etc'''


    def __init__(self):
        self.name='chemworker'
        self.pyrasettings=None
        self.modelpath=None
        self.tmpfolder=None
        self.osra=None
        self.getPyramidSettings()


    def getPyramidSettings(self):
        ''' Setter function retrieves the current global ADME Sarfari settings from the ini file.'''

        self.pyrasettings = get_current_registry().settings

        if 'modelpath' in self.pyrasettings:
            self.modelpath=self.pyrasettings['modelpath']

        # If the following two are missing due to the current registry not being setup (such as unit tests), leave as none types.

        if 'webtemp' in self.pyrasettings:
            self.tmpfolder=self.pyrasettings['webtemp']

        if 'osrabin' in self.pyrasettings:
            self.osra=self.pyrasettings['osrabin']



    def cleanMolecule(self,molIn):

        ''' Not really cleaning, but parsing and spitting back CTAB, just to organize 2D layout.'''

        dirty = Chem.MolFromMolBlock(str(molIn))

        AllChem.Compute2DCoords(dirty)

        return {'CTABOUT':Chem.MolToMolBlock(dirty)}


    def parseUploadFile(self,sdfin):

        ''' Parse the upload sdf,mol,smi write to temp, returning the first molecule (if valid)'''

        tempmolfile = tempfile.NamedTemporaryFile(dir=self.tmpfolder,mode='w+t')

        tempmolfile.writelines(sdfin)

        tempmolfile.seek(0)

        molarray=[]

        molFound = False

        try:
            for mol in Chem.ForwardSDMolSupplier(tempmolfile):
                if mol is None: continue
                molarray.append(mol)
                molFound = True
        except:
            pass


        try:
            if molFound == False:
                for mol in Chem.SmilesMolSupplier(tempmolfile.name):
                    if mol is None: continue
                    molarray.append(mol)
            else:
                pass
        except:
            pass


        firstmol=molarray[0]

        tempmolfile.close()

        AllChem.Compute2DCoords(firstmol)

        return Chem.MolToMolBlock(firstmol)

    def imagetomol(self,molimage):

        '''Use OSRA to convert image to smiles string '''


        if self.osra != None:

            tempmolfile = tempfile.NamedTemporaryFile(dir=self.tmpfolder,mode='wb')

            tempmolfile.write(molimage)

            tempmolfile.seek(0)

            args = (self.osra,tempmolfile.name, "-f", "smi")

            popen = subprocess.Popen(args, stdout=subprocess.PIPE)

            popen.wait()

            output = popen.stdout.read()

            return output

        else:
            return None

    def getmodelinfo(self,modeltype):

        ''' Load the trained NB and extract the classes (CHEMBL target ids) and compound count'''

        try:
            modelObj = cPickle.load(file(self.modelpath+'/'+modeltype+'.model','rb'))
        except:
            return {'status':'Model pickle not found!'}

        model=modelObj['modelClass']
        accuracy=modelObj['accuracy']
        cpdcount =modelObj['cpdcount']

        retdict={}
        retdict['classes']=model.classes_.tolist()
        retdict['cpdcount']=cpdcount

        return retdict



    def runModel(self,inputMol,modeltype):

        ''' Parse the input CTAB, load the relevant model (grabbing the model type from the pickle object)
        '''

        returnArray=[]

        try:
            modelObj = cPickle.load(file(self.modelpath+'/'+modeltype+'.model','rb'))
        except:
            return {'error':'Model pickle not found!'}

        model=modelObj['modelClass']
        accuracy=modelObj['accuracy']
        classes=model.classes_

        # Parse input.
        # TO DO: Extend to SMILES parsing
        testmol = Chem.MolFromMolBlock(str(inputMol))
        
        if testmol.GetNumAtoms()==0:
            return [{'error':'Molecule contains zero atoms!'}]

        nms=[x[0] for x in Descriptors._descList]

        # Using just descriptors
        if modelObj['modelType']=='desc':

            calc = MoleculeDescriptors.MolecularDescriptorCalculator(nms)
            descs = calc.CalcDescriptors(testmol)

        # Use fingerprints only.
        if modelObj['modelType']=='fp':

            descs = AllChem.GetMorganFingerprintAsBitVect(testmol,2,2048)


        # Use a combination of both. Create tuple from fp vector and add to descriptor tuple
        if modelObj['modelType']=='descfp':

            calc = MoleculeDescriptors.MolecularDescriptorCalculator(nms)
            descsFP = AllChem.GetMorganFingerprintAsBitVect(testmol,2,2048).ToBitString()
            descsFP = tuple(int(descsFP[i]) for i in range(0, len(descsFP)))
            descsD = calc.CalcDescriptors(testmol)
            descs = descsD+descsFP

        
        probabilities=[]
        prob = model.predict_proba(descs)
        #prob = stats.zscore(prob,axis=1)
        

        # Now normalise the output
        
        # Flatten the numpy matrix into a list of tuples.
        pflat = prob.flatten()
        pmax = max(pflat)

        for index,probty in enumerate(prob.flatten()):

            probabilities.append((model.classes_[index],probty))

        # Sort by probability descending
        probabilities.sort(key=lambda tup: tup[1],reverse=True)

        # Take top ten results
        probabilities=probabilities[:10]

        # Fill return array via an arbitrary cut-off. (Which seems to be the lowest sensible value for returned probablities to coincide with PP models..)
        for result in probabilities:
            if float(result[1])>0.0005:
                print result[1]
                returnObj={}
                returnObj['PROTEIN_ACCESSION']=result[0]
                returnArray.append(returnObj)


        return returnArray

class chempupil(object):
    ''' Encapsulation of RDKit and SciKit machine learning functionality '''


    def __init__(self):


        self.name='chempupil'
        self.dummy=True
        self.ms=[]
        self.trainset=[]
        self.testset=[]
        self.accuracy=0
        self.aurc=0
        self.X_train=None
        self.X_test=None
        self.y_train=None
        self.y_test=None
        self.model=None
        self.modelclass=None
        self.pyrasettings=None
        self.modelpath=None
        self.rdkitshareddata=None
        self.sigFactory=None
        self.pAct_threshold=5
        self.minCompoundCount=30
        self.numberoftrainingmols=None
        self.asmols=None
        self.pactyes=0
        self.pactno=0
        self.bullcount=0


        self.setPyramidSettings()


    def setPyramidSettings(self):
        ''' Setter function retrieves the current global ADME Sarfari settings from the ini file. Update the path to the model directory '''

        self.pyrasettings = get_current_registry().settings
        self.modelpath=self.pyrasettings['modelpath']
        self.rdkitshareddata=self.pyrasettings['rdkitshared']

        return

    def getTargetID(self,chemblin):
        ''' Return the Uniprot ID for the assay '''
        c2u = DBSession.query(chembl_2_uniprot).filter(chembl_2_uniprot.chembl_id==chemblin).filter(chembl_2_uniprot.primary==1).first()
        return c2u.uniprot_accession

    def getpActFlag(self,pactval,stdrel,actcom):

        '''
         If the pAct score is defined, then return true/false active/inactive
         If the pAct == Null then use the Activity comment to get active/inactive
        '''

        inactivematch = re.compile('^is not a|inactive|^not\s.*|^no\s.*',re.I)
        #actmatch = re.compile('^is not a|inactive|^not\s.*|^no\s.*|^none',re.IGNORECASE)
        actmatch = re.compile('^substrate|inducer',re.I)

        pflag=None

        # Since we're only considering actives, everything else should be False?

        if pactval != None:
            # We've got a pAct value
            self.pactyes=self.pactyes+1

            if pactval >= self.pAct_threshold:

                pflag = 'Active'
                score = 1

                if stdrel == ">":
                    pflag = 'Bull'
                    self.bullcount=self.bullcount+1

            elif pactval < self.pAct_threshold:

                pflag = 'Inactive'
                score = -1

                if stdrel == "<":
                    pflag = 'Bull'
                    self.bullcount=self.bullcount+1
        else:
            # We don't got a pAct value!
            self.pactno=self.pactno+1


            if inactivematch.match(actcom) > 0 :
                pflag = 'Inactive'
                score = -1

            elif actmatch.match(actcom) > 0:
                pflag = 'Active'
                score = 1
            else:
                pflag = 'Inactive'
                score = -1


        return pflag,score

    def justLoadMols(self):

        ''' If we sucessfully created the input last run, load it and create training and validation sets'''
        try:

            modelinput = cPickle.load(file(self.modelpath+'/modelinput.pkl','rb'))

            self.X_train = modelinput['mols']
            self.y_train = modelinput['targets']

        except:
            raise "Can't find pickled molecule set to load!"

        return modelinput

    def createMoleculeSets(self):
        '''
        Find all mols with activity, filter with the defined criteria, a la PP protocol.
        Store in a dict of arrays against assay/target
        Retain those >30
        '''

        # Import retable classes
        from .models import (
           Base,
           DBSession,
           activities,
           assays,
           assay2target,
           target_dictionary,
           target_xref,
           compound_properties,
           compound_mols,
           chembl_2_uniprot,
           compound_structures,
           target
        )

        # Test for existence of input pickle.
        try:

            print "Loading preexisting input data..."
            modelinput = cPickle.load(file(self.modelpath+'/modelinput.pkl','rb'))
            inputdata_mols = modelinput['mols']
            inputdata_targets = modelinput['targets']

        except:


            mols = DBSession.query(compound_structures,activities,assays,target,chembl_2_uniprot,target_dictionary) \
            .join(activities,compound_structures.molregno==activities.molregno) \
            .filter(assays.assay_id==activities.assay_id) \
            .filter(assays.tid==chembl_2_uniprot.tid)\
            .filter(target.chembl_target_component_id==chembl_2_uniprot.component_id) \
            .filter(chembl_2_uniprot.chembl_id==target_dictionary.chembl_id) \
            .filter(chembl_2_uniprot.primary==1)\
            .filter(assays.confidence_score>6) \
            .filter(or_(target_dictionary.target_type == 'SINGLE PROTEIN', target_dictionary.target_type == 'PROTEIN COMPLEX')) \
            .filter("not regexp_like('activities.activity_comment','^efflux|^atpase|^calcein|dependent')")

            #.filter(activities.pact>=self.pAct_threshold)
            #.filter(and_(activities.pact>=self.pAct_threshold,activities.standard_relation!='>'))
            #.filter(activities.pact!=None) \

            #Might reinstate the line below as an overide to using the SQL above...
            #mols = Chem.SDMolSupplier(self.modelpath+'/admesarfariinput.sdf')

            frequencies = []
            inputmols_data=[]
            inputmols_target=[]
            targetsDict={}

            buildreport = open(self.modelpath+'/input_report.txt','w')

            #buildreport.writelines("\n\n"+str(mols.__len__())+" total records for training / testing.\n")

            # Iterate over mols creating activity classes and count

            typematch = re.compile('(potency|IC50|EC50|Kd|Km|Ki|AC50|Ki app)',re.IGNORECASE)


            # Iterate over the compound set to create activity counts

            molset=[]


            self.asmols = pd.DataFrame(columns=['molregno','canonical_smiles','targ_id', 'name', 'gene_name', 'chembl_id','adme_class_id','score','pflag'])


            index=0

            targLookup={}

            for mol,activity,ohisay,targ,chemtouni,targdict in mols:


                targetID = chemtouni.chembl_id
                #molecule = Chem.MolFromMolBlock(mol.molfile,strictParsing=False) # I don't like this but it throws lots of errors parsing mol tabs from the db
                prefname = targdict.pref_name
                stdtype =  typematch.match(activity.standard_type)
                adme_class_id = targ.target_adme_class_id
                canonical_smiles = mol.canonical_smiles.encode('ascii','ignore')
                gene_name = targ.gene_name
                chembl_id = targetID
                molregno = mol.molregno
                id = targ.id
                name = targ.name
                #molfile = mol.molfile




                #try:
                #    targetID = molecule.GetProp('CHEMBL_ID')
                #except:
                #    targetID = molecule.GetProp('target')
                #pflag,score = self.getpActFlag(activity.pact,activity.standard_relation,activity.activity_comment)

                #molecule.SetProp("TARGET",str(targetID))
                #molecule.SetProp("SCORE",str(score))

                pflag,score = self.getpActFlag(activity.pact,activity.standard_relation,activity.activity_comment)

                try:

                    vmol = Chem.MolFromSmiles(canonical_smiles)

                    if vmol.GetNumAtoms() > 0:
                        vmol = True
                    else:
                        vmol = False
                except:
                    vmol = False


                if pflag != 'Bull' and vmol == True:
                    moldict={'index':index,'targ_id':targ.id,'score':score,'canonical_smiles':str(canonical_smiles),'gene_name':gene_name,'chembl_id':chembl_id,'molregno':molregno,'name':name,'adme_class_id':adme_class_id,'pflag':pflag}
                    targLookup[targ.id]=prefname


                    length = len(self.asmols.index)
                    self.asmols.loc[length]=pd.Series(moldict)




                        #if molpACTscore !='Bull' and molpACTscore !='Inactive' and stdtype!=None:
                        #
                        #    FLAG=1
                        #
                        #    molecule.SetProp("TARGET",str(targetID))
                        #    molecule.SetProp("ACTIVITY",str(FLAG))
                        #
                        #    if targetsDict.has_key(targetID):
                        #        targetsDict[targetID]['mols'].append(molecule)
                        #        targetsDict[targetID]['activecount']=targetsDict[targetID]['activecount']+FLAG
                        #    else:
                        #        targetsDict[targetID]={}
                        #        targetsDict[targetID]['mols']=[]
                        #        targetsDict[targetID]['mols'].append(molecule)
                        #        targetsDict[targetID]['activecount']=0
                        #        targetsDict[targetID]['activecount']=targetsDict[targetID]['activecount']+FLAG
                        #        targetsDict[targetID]['pref_name']=prefname



            #buildreport.write("Bull Count="+str(self.bullcount))
            #buildreport.write(str(self.pactyes)+" have pAct values\n")
            #buildreport.write(str(self.pactno)+" do not have pAct values\n\n")

            # Remove targets with less than minCompoundCount actives
            #print self.asmols.head()

            # The following should work but the monkeypatching doesn't work with this rdkit instance due to missing depiction functionality. Probably redundant for this application anyway...
            #PandasTools.AddMoleculeColumnToFrame(self.asmols,'canonical_smiles','Molecule',includeFingerprints=False)


            keystodelete=[]

            targselect = self.asmols[['molregno','targ_id','score']]

            # Group by target
            targselectcriteria = targselect.groupby('targ_id')

            # Calculate score
            targscores = targselectcriteria['score'].agg([np.sum,np.size])

            def goodorbad(testval):
                if testval > 0:

                    return True

                else:

                    return False


            def enoughactives(testval):

                if testval > self.minCompoundCount:

                    return True

                else:

                    return False


            targscores['keepA'] = np.vectorize(goodorbad)(targscores['sum'])
            targscores['keepB'] = np.vectorize(enoughactives)(targscores['sum'])


            # Keep the high scoring targets
            targscores = targscores[targscores['keepA']==True]
            targscores = targscores[targscores['keepB']==True]

            # Still a mixutre of actives/inactives
            #targscores = targscores[targscores['size']>=self.numberoftrainingmols]


            for index,row in targscores.iterrows():

                frequencies.append({'name':targLookup[index],'count':row['size']})



            # Overwrite all properties with the function return
            #targlist = targscores.apply(goodorbad,axis=1,broadcast=True)


            # List of ids
            self.goodtargs = list(targscores.T)

            self.asmols = self.asmols[self.asmols['pflag']=='Active']

            self.asmols = self.asmols[self.asmols['targ_id'].isin(self.goodtargs)]


            # Filter compounds down to just those for good targets
            #self.asmols = self.asmols[]

            # Now remove inactives?


            #for key in targetsDict.keys():
            #    activecount = targetsDict[key]['activecount']
            #
            #    if activecount < self.minCompoundCount:
            #        keystodelete.append(key)
            #        buildreport.write(str(key)+" has "+str(activecount)+" 'actives' - Not included\n")
            #    else:
            #        buildreport.write(str(key)+" has "+str(activecount)+" 'actives'\n")
            #        frequencies.append({'name':[targetsDict[key]['pref_name']],'count':activecount})
            #
            #for key in keystodelete:
            #    del targetsDict[key]


            ## Now build up inputs list
            #for key in targetsDict.keys():
            #    inputmols_data=inputmols_data+targetsDict[key]['mols']
            #
            #buildreport.write("\n\n"+str(inputmols_data.__len__())+" total molecules filtered for training / testing.\n")
            #self.numberoftrainingmols = inputmols_data.__len__()
            #
            #for mol in inputmols_data:
            #    if int(mol.GetProp('ACTIVITY')) == 1:
            #        #inputmols_target.append(self.classes.index(mol.GetProp('TARGET')))
            #        inputmols_target.append(mol.GetProp('TARGET'))

            inputdict={}

            inputdict['mols'] = [Chem.MolFromSmiles(x) for x in self.asmols['canonical_smiles'].values.tolist()]
            inputdata_mols = inputdict['mols']

            inputdict['targets'] = self.asmols['targ_id'].values.tolist()
            inputdict['targets'] = [np.asscalar(targ) for targ in inputdict['targets']]

            inputdata_targets = inputdict['targets']


            # Save a binary pickle for later use
            cPickle.dump(inputdict,file(self.modelpath+'/modelinput.pkl','wb+'))


            self.inputCompoundsFreq(frequencies,frequencies.__len__(),'target_molecule_counts','r')
            self.inputCompoundsFreq(frequencies,25,'target_molecule_counts_top25','b')

        # Create training and validation sets.
        self.X_train, self.X_test, self.y_train, self.y_test = cross_validation.train_test_split(inputdata_mols, inputdata_targets, test_size=0.15, random_state=55)

        # Remove duplicates to ensure unique sets.
        validationDuplicates=[]

        for m,mol in enumerate(self.X_train):
            if mol in self.X_test:
                validationDuplicates.append(m)

        print "Number of duplicates in validation set:",validationDuplicates.__len__()




    def test_cles(self):


        frequencies =[]
        frequencies.append({'name':'alpha','count':1})
        frequencies.append({'name':'beta','count':2});
        frequencies.append({'name':'gamma','count':3});
        frequencies.append({'name':'delta','count':4});

        self.inputCompoundsFreq(frequencies,frequencies.__len__(),'target_molecule_counts','r')
        self.inputCompoundsFreq(frequencies,2,'target_molecule_counts_top25','b')

        return {'status':'complete'}

    def buildDataSetFP(self):

        # build fingerprints:
        fps = [AllChem.GetMorganFingerprintAsBitVect(x,2,2048) for x in self.ms]

        # now build our list of points:

        pts = []

        for i,m in enumerate(self.ms):
            if m.GetProp('ACTIVITY')=='Active':
                act=1
            else:
                act=0
            pts.append([m.GetProp('ASSAY'),fps[i],act])

        # and save them to a file:

        cPickle.dump(pts,file('pts.pkl','wb+'))


    def buildTrainingDesc(self):

        nms=[x[0] for x in Descriptors._descList]
        #nms.remove('MolecularFormula')
        calc = MoleculeDescriptors.MolecularDescriptorCalculator(nms)

        trainDescrs = []
        testDescrs = []


        for mol in self.X_train:
            moldescriptors = list(calc.CalcDescriptors(mol))
            trainDescrs.append(tuple(moldescriptors))

        for mol in self.X_test:
            moldescriptors = list(calc.CalcDescriptors(mol))
            testDescrs.append(tuple(moldescriptors))


        cPickle.dump(trainDescrs,file(self.modelpath+'/desc_trainDescrs.pkl','wb+'))
        cPickle.dump(testDescrs,file(self.modelpath+'/desc_testDescrs.pkl','wb+'))


    def buildTrainingFP(self):

        trainDescrs = [AllChem.GetMorganFingerprintAsBitVect(x,2,2048) for x in self.X_train]
        testDescrs = [AllChem.GetMorganFingerprintAsBitVect(x,2,2048) for x in self.X_test]


        cPickle.dump(trainDescrs,file(self.modelpath+'/fp_trainDescrs.pkl','wb+'))
        cPickle.dump(testDescrs,file(self.modelpath+'/fp_testDescrs.pkl','wb+'))

    def buildCompleteSetFP(self):


        trainDescrs = [AllChem.GetMorganFingerprintAsBitVect(x,2,2048) for x in self.X_train]


        cPickle.dump(trainDescrs,file(self.modelpath+'/fp_completeset.pkl','wb+'))


    def setSigFactory(self):
        #fdefName = self.rdkitshareddata+'BaseFeatures.fdef'
        fdefName = self.rdkitshareddata+'MinimalFeatures.fdef'
        featFactory = ChemicalFeatures.BuildFeatureFactory(fdefName)
        self.sigFactory = SigFactory(featFactory,minPointCount=2,maxPointCount=3)
        self.sigFactory.SetBins([(0,2),(2,5),(5,8)])
        self.sigFactory.Init()

        #sigFactory.GetSigSize()



    def buildTrainingPF(self):


        if self.sigFactory==None:
            self.setSigFactory()

        trainDescrs = [Generate.Gen2DFingerprint(x,self.sigFactory) for x in self.X_train]
        testDescrs = [Generate.Gen2DFingerprint(x,self.sigFactory) for x in self.X_test]


        cPickle.dump(trainDescrs,file(self.modelpath+'/trainDescrs.pkl','wb+'))
        cPickle.dump(testDescrs,file(self.modelpath+'/testDescrs.pkl','wb+'))


    def buildTrainingDescFP(self):

        nms=[x[0] for x in Descriptors._descList]
        #nms.remove('MolecularFormula')
        calc = MoleculeDescriptors.MolecularDescriptorCalculator(nms)


        # Create a tuple from the fingerprint and descriptors

        trainDescrs = []
        testDescrs=[]

        for x in self.X_train:
            descrs = calc.CalcDescriptors(x)
            bv = AllChem.GetMorganFingerprintAsBitVect(x,2,2048).ToBitString()
            final = descrs+tuple(int(bv[i]) for i in range(0, len(bv)))
            trainDescrs.append(final)

        for x in self.X_test:
            descrs = calc.CalcDescriptors(x)
            bv = AllChem.GetMorganFingerprintAsBitVect(x,2,2048).ToBitString()
            final = descrs+tuple(int(bv[i]) for i in range(0, len(bv)))
            testDescrs.append(final)

        cPickle.dump(trainDescrs,file(self.modelpath+'/descfp_trainDescrs.pkl','wb+'))
        cPickle.dump(testDescrs,file(self.modelpath+'/descfp_testDescrs.pkl','wb+'))




    #def trainNaiveBayesian(self,modelType):
    #
    #    modelclass='nb'
    #
    #    trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_trainDescrs.pkl','rb'))
    #    testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))
    #
    #    gnb = GaussianNB()
    #
    #    clf_NB = gnb.fit(trainDescrs,self.y_train)
    #    preds_NB  = clf_NB.predict(testDescrs)
    #
    #    accuracy = clf_NB.score(testDescrs,self.y_test)
    #
    #    model={}
    #    model['modelType'] = modelType
    #    model['modelClass']=clf_NB
    #    model['accuracy']=accuracy
    #    model['classes']=self.classes
    #
    #    cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))
    #
    #    y_pred=[]
    #    for mol in self.X_test:
    #        y_pred.append(self.runBasic(mol,modelclass,modelType))
    #
    #
    #    self.generateReport('Naive Bayesian (Gaussian)',y_pred,accuracy,modelType)
    #
    #
    #def trainMNNaiveBayesian(self,modelType):
    #
    #    modelclass='mnnb'
    #
    #    trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_completeset.pkl','rb'))
    #    testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))
    #
    #    # Trying to recreate PP Naive Bayes multiclass. Appears to be Multinomial with 'leave one out' cross validation
    #
    #    ytrain = np.array(self.Y_train)
    #    xtrain = np.array(trainDescrs)
    #
    #    loo = LeaveOneOut(len(ytrain))
    #
    #    mnnb = MultinomialNB()
    #    mnnbloo = MultinomialNB()
    #
    #
    #    mnnb.fit(xtrain,ytrain)
    #
    #    #cross_validation.cross_val_score(mnnbloo,xtrain ,ytrain, cv=loo)
    #
    #
    #
    #    #mnnb = mnnb.fit(trainDescrs,self.y_train)
    #    #preds_NB  = mnnb.predict(testDescrs)
    #    #
    #    accuracy = mnnb.score(testDescrs,self.y_test)
    #
    #    model={}
    #    model['modelType'] = modelType
    #    model['modelClass']=mnnb
    #    model['accuracy']=accuracy
    #    model['classes']=self.classes
    #
    #    cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))
    #
    #    y_pred=[]
    #    for mol in self.X_test:
    #        y_pred.append(self.runBasic(mol,modelclass,modelType))
    #
    #
    #    self.generateReport('Naive Bayesian (Multinomial)',y_pred,accuracy,modelType)

    def trainBNaiveBayesian(self,modelType):

        modelclass='bnb'

        trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_trainDescrs.pkl','rb'))
        testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))

        # Trying to recreate PP Naive Bayes multiclass.

        #ytrain = np.array(self.y_train)
        #xtrain = np.array(self.X_train)

        bnb = BernoulliNB()

        bnb.fit(trainDescrs,self.y_train)

        #loo = LeaveOneOut(len(self.Y_train))

        #cross_validation.cross_val_score(bnb,xtrain ,ytrain, cv=loo,n_jobs=8)

        accuracy = bnb.score(testDescrs,self.y_test)

        model={}
        model['modelType'] = modelType
        model['modelClass']=bnb
        model['accuracy']=accuracy
        model['cpdcount']=trainDescrs.__len__()

        cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))

        self.validationTests()

        y_pred=[]
        for mol in self.X_test:
            y_pred.append(self.runBasic(mol,modelclass,modelType)['primary'])

        self.generateReport('Naive Bayesian (Bernoulli)',y_pred,accuracy,modelType,bnb)



    #def trainRandomForest(self,modelType):
    #
    #    modelclass = 'rf'
    #
    #    trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_trainDescrs.pkl','rb'))
    #    testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))
    #
    #    nclf = RandomForestClassifier(n_estimators=100,n_jobs=-1)
    #    nclf = nclf.fit(trainDescrs,self.y_train)
    #
    #    accuracy    = nclf.score(testDescrs,self.y_test)
    #
    #    model={}
    #    model['modelType'] = modelType
    #    model['modelClass']=nclf
    #    model['accuracy']=accuracy
    #    model['classes']=self.classes
    #
    #    cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))
    #
    #    y_pred=[]
    #    for mol in self.X_test:
    #        y_pred.append(self.runBasic(mol,modelclass,modelType))
    #
    #    self.generateReport('Random Forest',y_pred,accuracy,modelType)
    #
    #def trainSVM(self,modelType):
    #
    #    modelclass='svm'
    #
    #    trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_trainDescrs.pkl','rb'))
    #    testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))
    #
    #
    #    clf_svm = svm.SVC(gamma=0.001, C=100.,probability=True)
    #    clf_svm = clf_svm.fit(trainDescrs,self.y_train)
    #    preds = clf_svm.predict(testDescrs)
    #    metrics.confusion_matrix(self.y_test,preds)
    #    accuracy = clf_svm.score(testDescrs,self.y_test)
    #
    #
    #    model={}
    #    model['modelType'] = modelType
    #    model['modelClass']=clf_svm
    #    model['accuracy']=accuracy
    #    model['classes']=self.classes
    #
    #    cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))
    #
    #    y_pred=[]
    #
    #    for mol in self.X_test:
    #        y_pred.append(self.runBasic(mol,modelclass,modelType))
    #
    #    self.generateReport('SVM',y_pred,accuracy,modelType)
    #
    #def trainSVC(self,modelType):
    #
    #    modelclass='svc'
    #
    #    trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_trainDescrs.pkl','rb'))
    #    testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))
    #
    #
    #    # Create the RFE object and compute a cross-validated score.
    #    svc = SVC(kernel="linear")
    #    rfecv = RFECV(estimator=svc, step=1, cv=StratifiedKFold(self.y_train, 2),
    #                  scoring='accuracy')
    #    rfecv.fit(trainDescrs, self.y_train)
    #
    #    print("Optimal number of features : %d" % rfecv.n_features_)
    #
    #    # Plot number of features VS. cross-validation scores
    #
    #    pl.figure()
    #    pl.xlabel("Number of features selected")
    #    pl.ylabel("Cross validation score (nb of misclassifications)")
    #    pl.plot(range(1, len(rfecv.grid_scores_) + 1), rfecv.grid_scores_)
    #    pl.show()
    #
    #    accuracy = rfecv.score(testDescrs,self.y_test)
    #
    #    #
    #    #clf_svm = svm.SVC(gamma=0.001, C=100.,probability=True)
    #    #clf_svm = clf_svm.fit(trainDescrs,self.y_train)
    #    #preds = clf_svm.predict(testDescrs)
    #    #metrics.confusion_matrix(self.y_test,preds)
    #    #accuracy = clf_svm.score(testDescrs,self.y_test)
    #
    #
    #    model={}
    #    model['modelType'] = modelType
    #    model['modelClass']=rfecv
    #    model['accuracy']=accuracy
    #    model['classes']=self.classes
    #
    #    cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))
    #
    #    y_pred=[]
    #
    #    for mol in self.X_test:
    #        y_pred.append(self.runBasic(mol,modelclass,modelType))
    #
    #    self.generateReport('SVC',y_pred,accuracy,modelType)
    #
    #def trainkNN(self,modelType):
    #
    #    modelclass='knn'
    #
    #    trainDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_trainDescrs.pkl','rb'))
    #    testDescrs = cPickle.load(file(self.modelpath+'/'+modelType+'_testDescrs.pkl','rb'))
    #
    #
    #    nbrs = KNeighborsClassifier()
    #    nbrs = nbrs.fit(trainDescrs,self.y_train)
    #
    #    preds = nbrs.predict(testDescrs)
    #    metrics.confusion_matrix(self.y_test,preds)
    #    accuracy = nbrs.score(testDescrs,self.y_test)
    #
    #
    #    model={}
    #    model['modelType'] = modelType
    #    model['modelClass']=nbrs
    #    model['accuracy']=accuracy
    #    model['classes']=self.classes
    #
    #    cPickle.dump(model,file(self.modelpath+'/'+modelclass+'_'+modelType+'.model','wb+'))
    #
    #    y_pred=[]
    #
    #    for mol in self.X_test:
    #        y_pred.append(self.runBasic(mol,modelclass,modelType))
    #
    #    self.generateReport('SVM',y_pred,accuracy,modelType)

    def generateReport(self,title,y_pred,accuracy,descorfp,model):
        filestart=title.replace(' ','_')

        trainreport = open(self.modelpath+'/training_report.txt','w+t')
        trainreport.write("\n\n **** "+title+" ("+descorfp+") ****\n\n")
        #trainreport.write("= Classification Report =\n\n"+classification_report(self.y_test, y_pred, target_names=model.classes_)+"\n\n")
        trainreport.write("= Condensed Confusion Matrix =\n\n"+str(confusion_matrix(self.y_test,y_pred))+"\n\n")
        trainreport.write("Model accuracy="+str(accuracy)+"\n")
        trainreport.close()


    def validationTests(self):

        '''
            Akin to George's PP approach, for a validation set of compounds, record how the correct prediction ranks in the probability outputs

            Dump out as a piechart.
        '''

        scoreDict={}
        rightwrongDict={}
        rightwrongDict['Correct']=0
        rightwrongDict['Incorrect']=0



        for mol,target in zip(self.X_test,self.y_test):

            results=self.runBasic(mol,'bnb','fp')

            if results['primary']==target:

                rightwrongDict['Correct']=rightwrongDict['Correct']+1
            else:

                rightwrongDict['Incorrect']=rightwrongDict['Incorrect']+1


            position = int(results['sorted'].index(target))+1


            # Create a '5 and above'
            if position >= 5:
                position='Position '+str(5)+' and above'
            else:
                position='Position '+str(position)


            if position in scoreDict:
                scoreDict[position]=scoreDict[position]+1
            else:
                scoreDict[position]=1

        totalmols=sum(scoreDict.values())

        #for score in scoreDict:
            #scoreDict[score]=100*(float(scoreDict[score])/float(totalmols))

        rwtotal=float(sum(rightwrongDict.values()))

        rightwrongDict['Correct']=100*(float(rightwrongDict['Correct'])/rwtotal)
        rightwrongDict['Incorrect']=100*(float(rightwrongDict['Incorrect']/rwtotal))

        # Set aspect ratio to be equal so that pie is drawn as a circle.
        fig = plt.figure()

        ax = fig.add_subplot(111)

        ax.axis('equal')
        ax.set_title('Rank recall accuracy of validation set')

        ax.pie(scoreDict.values(),labels=scoreDict.keys(),autopct='%1.1f%%', shadow=True, startangle=90)

        fig.savefig(self.modelpath+'/target_ranked_recall.png')

        fig.delaxes(ax)

        ax = fig.add_subplot(111)

        ax.axis('equal')
        ax.set_title('Primary result accuracy')

        ax.pie(rightwrongDict.values(),labels=rightwrongDict.keys(),autopct='%1.1f%%', shadow=True, startangle=90)

        fig.savefig(self.modelpath+'/primary_yes_no.png')


    def inputCompoundsFreq(self,frequencies,number,name,col):
        ''' Generate a bar chart showing activity frequency for targets of input molecules '''

        # Frequences is a list of pref_name:counts.


        frequencies.sort(key=lambda x: x['count'],reverse=True)

        inputlength = frequencies.__len__()

        #Trim to number
        frequencies=frequencies[0:number]

        ind = np.arange(frequencies.__len__())

        ybits = [int(x['count']) for x in frequencies]
        xbits = [x['name'] for x in frequencies]

        fig = plt.figure()



        DefaultSize = fig.get_size_inches()

        fig.set_size_inches( (DefaultSize[0]*2, DefaultSize[1]*1.5))

        ax = fig.add_subplot(111)

        # Set aspect ratio to be equal so that pie is drawn as a circle.
        #ax.axis('equal')

        if inputlength != number:
            ax.set_title('Targets with number of actives >= '+str(self.minCompoundCount)+' (Top '+str(number)+')')
        else:
            ax.set_title('Targets with number of actives >='+str(self.minCompoundCount))

        ax.set_xlabel('Targets')
        ax.set_ylabel('Actives count')
        width = 0.1

        ax.bar(ind,ybits,width=width,color=col)

        ax.set_xticks(np.arange(len(xbits)) + width/2)
        ax.set_xticklabels(xbits,rotation=90,fontsize=8)

        fig.tight_layout()

        fig.savefig(self.modelpath+'/'+name+'.png',dpi=300)


    def buildModel(self,mode):

        if mode == 'GENERATE':

            # This will either reload or create the input set of molecules.
            self.createMoleculeSets()
            self.buildTrainingFP()
            self.trainBNaiveBayesian('fp')
            self.validationTests()

            return 'Model generation complete'

        return {'status':'Unknown option'}





    def runBasic(self,testmol,modelclass,modeltype):
        # Use this function for internal validation testing.


        returnArray=[]

        # Don't reload the model pickle on subsequent calls
        if self.model==None or self.modelclass!=modelclass+modeltype:
            self.model = modelObj = cPickle.load(file(self.modelpath+'/'+modelclass+'_'+modeltype+'.model','rb'))
            self.modelclass=modelclass+modeltype

        else:
            modelObj = self.model


        model=modelObj['modelClass']
        accuracy=modelObj['accuracy']
        classes=model.classes_


        if modelObj['modelType']=='fp':

            descs = AllChem.GetMorganFingerprintAsBitVect(testmol,2,2048)

        prob = model.predict_proba(descs)
        primary = model.predict(descs)[0]

        # Now normalise the output

        probabilities=[]

        # Flatten the numpy matrix into a list of tuples.
        pflat = prob.flatten()

        pmax = max(pflat)

        for index,probty in enumerate(prob.flatten()):
            probabilities.append((classes[index],float(probty/pmax)))


        # Sort by probability descending
        probabilities.sort(key=lambda tup: tup[1])
        probabilities.reverse()

        sortedProbs=[]

        for sprob in probabilities:
            sortedProbs.append(sprob[0])

        resultDict={}

        resultDict['primary']=primary
        resultDict['sorted']=sortedProbs


        return resultDict
