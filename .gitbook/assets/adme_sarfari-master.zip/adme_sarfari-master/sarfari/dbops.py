'''
Database query module for ADMESarfari
@author:Nathan Dedman
@company: EBI, Hinxton.
'''
from sqlalchemy.exc import DBAPIError
#from sqlalchemy import Table, Column, Integer, String, MetaData, join, ForeignKey
from sqlalchemy import *
from sqlalchemy import orm
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import column_property, aliased, joinedload, subqueryload, mapper, relation, relationship, contains_eager

from zope.sqlalchemy import mark_changed
from sqlalchemy.sql import Select
from sqlalchemy.ext.compiler import compiles

import copy,re

from .models import (
    Base,
    DBSession,
    #Base.metadata,
    assay2target,
    activities,
    assays,
    compound_structures,
    compound_properties,
    compound_mols,
    target_source,
    target_source_type,
    target,
    target_sequence_variation,
    target_sequence,
    target_classification,
    target_pfam,
    target_scop,
    target_scop_match_regions,
    target_alignment,
    target_xref,
    target_synonym,
    synonym_type,
    synonym_source,
    xref_type,
    adme_class,
    taxonomy,
    orthologue_mapping,
    protein_atlas_expression,
    protein_atlas_subcell_location,
    expression_tissue,
    expression_cell_type,
    target_protein_expression
    )


hitstable=None

    
def dumprow(rowObj):
    '''Create a dict from a returned row
    Since we've used autoreflection to setup the table models, we have no explicit row object to work with, i.e. we have not used a declarative model.
    Pop out the instance state element from the row dict and return it
    '''
    returndict = rowObj.__dict__

    if '_sa_instance_state' in returndict:
        del returndict['_sa_instance_state']

    return returndict


def get_taxid(species):
    
    taxid = DBSession.query(taxonomy).filter(taxonomy.genbank_common_name.like('%'+species+'%')).first().taxid
    
    return taxid



def get_orthomatrix():
    '''
    Generate the nxn Orthologue Matrix wrt Human taxid (9606)
    
    Since we sending this to datatables, ideally we need an array of objects with nested species, i.e.
    
        returnArray = {human{mappings},rabbit{mappings},monkey{mappings}}_target
    
    '''
    
    data = {}
    mapping = {}
    returnObj = {}
    source = {}
    returnArray = []
    taxids=[10090,10141,9986,9606,9031,10116,9615,9823,9598]

    rows = DBSession.execute('SELECT me.ID,me.TARGET_ID_FROM,me.TARGET_ID_TO,me.HOMOLOGY_DESCRIPTION,me.HOMOLOGY_SUBTYPE,me.PROTEIN_IDENTITY,target_from.ID,target_from.NAME,target_from.FULL_NAME,target_from.CHEMBL_TARGET_ID,target_from.ENSEMBL_GENE_ID,target_from.ENSEMBL_PEPTIDE_ID,target_from.UNIPROT_ACCESION,target_from.FUNCTION,target_from.TAXID,target_from.GENE_NAME,target_from.TARGET_CLASSIFICATION_ID,target_from.ADME_CLASS_ID,target_to.ID,target_to.NAME,target_to.FULL_NAME,target_to.CHEMBL_TARGET_ID,target_to.ENSEMBL_GENE_ID,target_to.ENSEMBL_PEPTIDE_ID,target_to.UNIPROT_ACCESION,target_to.FUNCTION,target_to.TAXID,target_to.GENE_NAME,target_to.TARGET_CLASSIFICATION_ID AS source_id,target_to.ADME_CLASS_ID,clusters.ID,clusters.TARGET_ID_FROM,clusters.TARGET_ID_TO,clusters.CLUSTER_ID,variation.TARGET_ID,variation.SNP_COUNT AS snp_count_to,variationr.SNP_COUNT AS snp_count_from,target_source.TARGET_SRC_TYPE_ID FROM orthologue_mapping me INNER JOIN target target_from ON target_from.ID = me.TARGET_ID_FROM INNER JOIN target target_to ON target_to.ID = me.TARGET_ID_TO INNER JOIN target_clusters clusters ON clusters.TARGET_ID_FROM = me.TARGET_ID_FROM AND clusters.TARGET_ID_TO  = me.TARGET_ID_TO LEFT JOIN target_variation_counts variation ON variation.TARGET_ID = me.TARGET_ID_TO LEFT JOIN target_variation_counts variationr ON variationr.TARGET_ID = me.TARGET_ID_FROM LEFT JOIN target_source ON (target_source.TARGET_ID = me.TARGET_ID_FROM) WHERE target_from.TAXID = 9606')

    for row in rows:
        
        me_id, me_target_id_from, me_target_id_to, me_homology_description, me_homology_subtype, me_protein_identity, target_from_id, target_from_name, target_from_full_name, target_from_chembl_target_id, target_from_ensembl_gene_id, target_from_ensembl_peptide_id, target_from_uniprot_accesion, target_from_function, target_from_taxid, target_from_gene_name, target_from_target_classification_id, target_from_adme_class_id, target_to_id, target_to_name, target_to_full_name, target_to_chembl_target_id, target_to_ensembl_gene_id, target_to_ensembl_peptide_id, target_to_uniprot_accesion, target_to_function, target_to_taxid, target_to_gene_name, target_to_target_classification_id, target_to_adme_class_id, clusters_id, clusters_target_id_from, clusters_target_id_to, clusters_cluster_id, variation_target_id, variation_snp_count_to, variation_snp_count_from, target_source_target_src_type_id = row
    
        
        if target_source_target_src_type_id != None:
            source[target_from_id]=target_source_target_src_type_id
        else:
            source[target_from_id]=3
            
        if target_from_id not in data:
            root={}
            root['target_id']=target_from_id
            root['name_from']=target_from_name
            root['name_to']=target_from_name
            root['gene']=target_from_gene_name
            root['ensembl']=target_from_ensembl_gene_id
            root['uniprot']=target_from_uniprot_accesion
            root['cluster']=clusters_cluster_id,
            root['snp_count']= variation_snp_count_from
            root['taxid']=target_from_taxid
            root['full_name']=target_from_full_name
            root['function']=target_from_function
            root['source']=target_source_target_src_type_id
            root['adme_class_id']=target_to_adme_class_id
            root['chembl_target_id']=target_from_chembl_target_id
            root['mapping']={}
                    
            data[target_from_id]=root
            
        
            
            
        if target_to_taxid not in data[target_from_id]['mapping']:
            
            #First time we're seeing this mapping. Create the array
            data[target_from_id]['mapping'][target_to_taxid]=[]
            
            
        mappingObj={}
        
        mappingObj['name_from']=target_from_name
        mappingObj['target_id']=target_to_id
        mappingObj['name_to']=target_to_name
        mappingObj['gene']=target_to_gene_name
        mappingObj['ensembl']=target_to_ensembl_gene_id
        mappingObj['uniprot']=target_to_uniprot_accesion
        mappingObj['desc']=me_homology_description
        mappingObj['subtype']=me_homology_subtype 
        mappingObj['identity']=me_protein_identity
        mappingObj['taxid']=target_to_taxid
        mappingObj['cluster']=clusters_cluster_id
        mappingObj['snp_count']=variation_snp_count_to
        mappingObj['full_name']=target_to_full_name
        mappingObj['function']=target_to_function
        mappingObj['source']=target_source_target_src_type_id
        mappingObj['adme_class_id']=target_from_adme_class_id
        mappingObj['chembl_target_id']=target_to_chembl_target_id
        
        rootCopy = copy.deepcopy(data[target_from_id])
        
        del rootCopy['mapping']
        
        data[target_from_id]['mapping'][target_to_taxid].append(mappingObj)
        
        data[target_from_id]['mapping'][9606]=[rootCopy]
        data[target_from_id]['mapping'][9606][0]['cluster']=data[target_from_id]['mapping'][9606][0]['cluster'][0] # For some reason, deep copy puts the cluster id into a tuple
        
        
    
    targetSet = data.items()
    
    
    for targety in targetSet:
        target_id = targety[0]
        data = targety[1]
        
        for taxid in taxids:
            # If there's no mapping, add in a blank, otherwise datatables complains!
                       
            if taxid not in data['mapping']:
                data['mapping'][taxid]={}
        
        returnArray.append(data['mapping'])
    
    return returnArray


def get_expression_matrix(tissueset):
    '''Return a list of human targets and corresponding tissue expression levels for the input tissues
    '''
    
    tissueset=tissueset.split(',')
    tissueiter = map(int, tissueset)
    
    for tissue in tissueset:
        tissue = "'"+tissue+"'"
        
    tissueset=",".join(tissueset)
    
    # where target.taxid = 9606 and protein_atlas_expression.reliability in ('High','Supportive') and protein_atlas_expression.exp_level in ('Strong','High','None');
    
    rows = DBSession.execute("SELECT PROTEIN_ATLAS_EXPRESSION.GENE,PROTEIN_ATLAS_EXPRESSION.EXP_LEVEL,PROTEIN_ATLAS_EXPRESSION.EXPRESSION_TYPE,PROTEIN_ATLAS_EXPRESSION.RELIABILITY,TARGET.ID               AS TARGET_ID,EXPRESSION_TISSUE.ID AS TISSUE_ID,PROTEIN_ATLAS_EXPRESSION.TISSUE, EXPRESSION_CELL_TYPE.ID AS CELL_ID,TARGET.FULL_NAME,TARGET.NAME FROM PROTEIN_ATLAS_EXPRESSION INNER JOIN TARGET ON PROTEIN_ATLAS_EXPRESSION.GENE = TARGET.ENSEMBL_GENE_ID INNER JOIN EXPRESSION_TISSUE ON PROTEIN_ATLAS_EXPRESSION.TISSUE = EXPRESSION_TISSUE.TISSUE INNER JOIN EXPRESSION_CELL_TYPE ON PROTEIN_ATLAS_EXPRESSION.CELL_TYPE = EXPRESSION_CELL_TYPE.CELL_TYPE WHERE EXPRESSION_TISSUE.ID in ("+tissueset+")")

    dataObj={}
    returnArray=[]
    targets=set()
    
    for row in rows:
        
        gene_id,exp_level,expression_type,reliability,target_id,tissue_id,tissue,cell_type,full_name,name = row
        
        targets.add(target_id)
        
        if target_id not in dataObj:
            dataObj[target_id]={}
            
        
        if tissue_id not in dataObj[target_id]:
            dataObj[target_id][tissue_id]={}    
        
        for t in tissueiter:
            if t not in dataObj[target_id]:
                dataObj[target_id][t]={}    
            
        if cell_type not in dataObj[target_id][tissue_id]:
            dataObj[target_id][tissue_id][cell_type]={}
        
        dataObj[target_id][tissue_id][cell_type]['expression_type']=expression_type
        dataObj[target_id][tissue_id][cell_type]['reliability']=reliability
        dataObj[target_id][tissue_id][cell_type]['exp_level']=exp_level
        dataObj[target_id][tissue_id][cell_type]['target_id']=target_id
        dataObj[target_id][tissue_id][cell_type]['gene_id']=gene_id
        dataObj[target_id][tissue_id][cell_type]['full_name']=full_name
        dataObj[target_id][tissue_id][cell_type]['tissue']="+".join(tissue.split(' '))
        dataObj[target_id][tissue_id][cell_type]['name']=name
        
        
    for tid in list(targets):
        returnArray.append(dataObj[tid])

    return returnArray


    
def get_target(tid):
    ''' Return the target data '''    
    targetObj = DBSession.query(target).filter(target.id==tid).first()
    
    holder = []
    holder.append(dumprow(targetObj))
    return holder

def get_target_alignment(tid):
    ''' Return the target alignment data '''
    
    # Ideally this will accept a list of the currently displayed organisms and return only those.
    
    holder = []

    snpsObj={}
    
    for targObj,alnObj in DBSession.query(target, target_alignment).join(target_alignment, target.id==target_alignment.target_id_to).filter(target_alignment.target_id_from==tid).all():
        
        alnObj=dumprow(alnObj)
        targObj=dumprow(targObj)
        
        #Merge the dictionary contents for each record
        holder.append(dict(alnObj.items() + targObj.items()))
    
    
    for alignment in holder:
        
        alignment['snps']={}
        
        snpObj = DBSession.query(target_sequence_variation).filter(target_sequence_variation.target_id==alignment['id']).all()
        
        for snp in snpObj:
            
            snp=dumprow(snp)
            
            alignment['snps'][snp['aa_position']]=snp
        
    
    return holder

def get_organism(taxid):
    
    taxidRow = DBSession.query(taxonomy).filter(taxonomy.taxid==taxid).first()
    
    return taxidRow.name

    


def get_sequence_set(tid):
    '''Return the set of orthologue fasta sequences for a particular target and itself'''
    
    holder=[]
    seqObj={}
    
    # Target sequence first
    root = DBSession.query(target_sequence).filter(target_sequence.target_id==tid).first()
    root=dumprow(root)
    
    seqObj['sequence']=root['sequence']
    seqObj['target_id']=root['target_id']
    
    
    data = get_target(tid).pop()
    
    seqObj['taxon']=get_organism(data['taxid'])
    seqObj['name']=str(data['id'])+'-'+str(data['name'])+'-'+str(seqObj['taxon'])
    
    seqObj['full_name']=data['full_name']
    
    
    holder.append(seqObj)
    
    
    # Orthologue sequences
    for rowbit1,rowbit2 in DBSession.query(orthologue_mapping, target_sequence).join(target_sequence, orthologue_mapping.target_id_to==target_sequence.target_id).filter(orthologue_mapping.target_id_from==tid).all():
        
        
        seqObj={}
        
        rowbit1=dumprow(rowbit1)
        rowbit2=dumprow(rowbit2)
        
        row=dict(rowbit1.items()+rowbit2.items())
        
        
        seqObj['sequence']=row['sequence']
        seqObj['target_id']=row['target_id']        
        
        data=get_target(row['target_id']).pop()
            
        seqObj['taxon']=get_organism(data['taxid'])
        seqObj['name']=str(data['id'])+'-'+str(data['name'])+'-'+str(seqObj['taxon'])
        seqObj['full_name']=data['full_name']
        
        holder.append(seqObj)

    return holder
    

def accession_to_target_id(accession):
    ''' Return the Target ID for a particular accession. '''
    acctargetObj = DBSession.query(target_xref).filter(target_xref.value==accession).first()
    
    return acctargetObj.target_id
    

def get_target_sequence(tid):

    holder = []

    seqObj1, seqObj2 = DBSession.query(target, target_sequence).join(target_sequence, target.id==target_sequence.target_id).filter(target_sequence.target_id==tid).first()
   
    seqObj1=dumprow(seqObj1)
    seqObj2=dumprow(seqObj2)
    
    newDict = dict(seqObj1.items() + seqObj2.items())
    newDict['sequence']="".join(newDict['sequence']) 
    newDict['snps']={}
    
    for varObj in DBSession.query(target_sequence_variation).filter(target_sequence_variation.target_id==tid).all():
    
        varObj=dumprow(varObj)
    
        newDict['snps'][varObj['aa_position']]=varObj   
    
    
    
    holder.append(newDict)
    
    return holder
    



def text_search(querystring):
    '''
    Simple string comparison on key columns rather than index/whoosh/solr
    
    To keep in line with the other searches, return an array of objects with target_id properties
    
    '''
    
    searchhits=set()
    
      
    records = DBSession.query(target_synonym).filter(target_synonym.value.ilike('%'+querystring+'%')).all()
                                                             
    for record in records:
        searchhits.add(record.target_id)

    records = DBSession.query(target_xref).filter(target_xref.value.ilike('%'+querystring+'%')).all()
                                                             
    for record in records:
        searchhits.add(record.target_id)
    
    
    records = DBSession.query(target).filter(or_(target.full_name.ilike('%'+querystring+'%'),target.function.ilike('%'+querystring+'%'),target.name.ilike('%'+querystring+'%'))).all()
                                                             
    for record in records:
        searchhits.add(record.id)
    
    #Turn the set into a list => Unique array of target ids.
    searchhits=list(searchhits);
    
    returnhits=[]
    
    for tid in searchhits:
        
        targetObj={}
        targetObj['target_id']=tid
        returnhits.append(targetObj)
    
    return returnhits


def get_suggestion(querystring):
    ''' Simple string comparison on key columns rather than index/whoosh/solr returning single words '''
    
    searchhits=set()
 
    exactMatch = re.compile(querystring,re.I)
    
    records = DBSession.query(target_synonym).filter(target_synonym.value.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.value):
            if re.search(querystring, word, re.I):
                searchhits.add(word)

    records = DBSession.query(target_xref).filter(target_xref.value.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.value):
            if re.search(querystring, word, re.I):
                searchhits.add(word)
                
    records = DBSession.query(target).filter(target.full_name.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.full_name):
            if re.search(querystring, word, re.I):
                searchhits.add(word)
                
    records = DBSession.query(target).filter(target.function.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.function):
            if re.search(querystring, word, re.I):
                searchhits.add(word)
                
    records = DBSession.query(target).filter(target.name.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.name):
            if re.search(querystring, word, re.I):
                searchhits.add(word)
                
    
    #target_xref_records = DBSession.query(target_xref).filter(target_xref.value.ilike('%'+querystring+'%').all()
    #
    #
    #for record in target_xref_records:
    #    hits.append(record.target_id)
    
    
    return list(searchhits)

def multisplit(querystring):
    return re.split(' |,|\.|;|\(|\)|\[|\]|\:|\/',querystring)



def getTissueTypes():
    '''Get a list of known tissue types'''
    
    returnBox=[]
    
    box = DBSession.query(expression_tissue).all()
    
    tissueObj = {}
    
    for tissue in box:
        
        tissue=dumprow(tissue)
        
        tissueid = tissue['id']
        tissue = tissue['tissue']
        
        tissueObj[tissueid]=tissue
    
        
    returnBox.append(tissueObj)    
    return returnBox

def getCellTypes():
    '''Get a list of known cell types'''
    
    returnBox=[]
    
    box = DBSession.query(expression_cell_type).all()
    
    cellObj={}
    
    for cell in box:
        cell=dumprow(cell)
        
        cellid = cell['id']
        celltype = cell['cell_type']
        
        cellObj[cellid]=celltype
        
    returnBox.append(cellObj);
    
    return returnBox


def getSimSub(ctab,simsubval,sessionid):
    '''Get a set of molecules via a similarity or substructure search. Results go into session temporary table'''
    sesh = DBSession.execute("select sys_context('USERENV','SID') from dual")
    sesh = sesh.first()[0]
    print "1 Session ID:",sesh
    
    try:
        if int(ctab)==0 and int(simsubval)==0:
            clearHitsTable(sessionid)
            return '0'
    except:
            pass
    
    # If simubval == 100 then we're performing a substructure. A full molecule will return it's exact match anyway, unless we want superstructure searching...
    returnregnos=[]
    
    DBSession.execute("begin execute immediate 'truncate table simsubhits_"+sessionid+"'; exception when others then null; end;")
    DBSession.execute("begin execute immediate 'drop table simsubhits_"+sessionid+"'; exception when others then null; end;")
        
    #DBSession.execute("begin execute immediate 'truncate table simsubhits'; exception when others then null; end;")
    #DBSession.execute("begin execute immediate 'drop table simsubhits'; exception when others then null; end;")
    
    if float(simsubval) < 100:
        
        sql1 = "create GLOBAL TEMPORARY table simsubhits_"+sessionid+" on commit PRESERVE ROWS as SELECT molregno,similarity(3) "
        sql2 = '"SIM"'
        sql3 = " FROM compound_mols cm WHERE similar(cm.CTAB, '"+ctab+"', '"+simsubval+"',3) = 1"
        
        sql=sql1+sql2+sql3        
    
    else:
        
        sql = "create GLOBAL TEMPORARY table simsubhits_"+sessionid+" on commit PRESERVE ROWS as SELECT molregno FROM compound_mols cm WHERE sss(cm.CTAB, '"+ctab+"') = 1"
    
    DBSession.execute(sql)    

    counter = DBSession.execute('select count (*) from simsubhits_'+sessionid)
    
    hitscount = counter.first()[0]
    
    
    
    return hitscount


def getMolInfo(inputTuples,sessionid):
    '''Return Sim/Sub search hit info for a datatable running serverside'''
        
    returnObj = {}
    returnmols=[]
    opsDict={}
    hitscount=0
    
    for tup in inputTuples.items():
        
        opsDict[tup[0]]=tup[1]

    returnObj['sEcho']=int(opsDict['sEcho'])
    
    try:
        hitscount = DBSession.execute('select count (*) from simsubhits_'+sessionid).first()[0]
    except:
        pass
    
    totalrecords = DBSession.query(compound_structures).count()
        
    mstart = int(opsDict['iDisplayStart'])
    mstop = mstart+int(opsDict['iDisplayLength'])
    
    sortingColumn = opsDict['mDataProp_'+opsDict['iSortCol_0']]
    sortingDirection = opsDict['sSortDir_0']
    sortingSQL = sortingColumn+' '+sortingDirection
        
    print "hitscount: ",hitscount
    
    if hitscount > 0:# Test to see if we hits from a search (and therfore a table to join against!)
        
    
        # Reflect newly created hits table into object, overwriting previous object (if it exists in the session metadata)
        hitstable = Table('simsubhits_'+sessionid, Base.metadata,autoload=True,autoload_replace=True,extend_existing=True)
        
        if hitstable.columns.__len__() > 1:
            simsearch=True
        else:
            simsearch=False
        
        
        returnObj['iTotalRecords']=hitscount            
        
        molQ = DBSession.query(compound_properties, compound_structures,hitstable).join(compound_structures, compound_properties.molregno==compound_structures.molregno).join(hitstable, compound_properties.molregno==hitstable.columns.molregno).order_by(sortingSQL).slice(start=mstart,stop=mstop)
        
        for mol in molQ:
            
            if simsearch:
                
                molObj1, molObj2, molregno, sim = mol
                    
            else:
            
                molObj1, molObj2, molregno = mol
                sim=-1
                
            
            molObj1=dumprow(molObj1)
            molObj2=dumprow(molObj2)
        
            molPropsDict = dict(molObj1.items() + molObj2.items())
            
            
            #if simsearch:
            molPropsDict['sim']=sim
            
            del molPropsDict['molfile']
            
            returnmols.append(molPropsDict)
            
            Base.metadata.remove(hitstable)
            
    else:
        
        if sortingColumn == 'sim':
            sortingSQL = 'mw_freebase'+' '+sortingDirection
        
        for mol in DBSession.query(compound_properties, compound_structures).join(compound_structures, compound_properties.molregno==compound_structures.molregno).order_by(sortingSQL).slice(start=mstart,stop=mstop):
            
            molObj1, molObj2 = mol
        
            molObj1=dumprow(molObj1)
            molObj2=dumprow(molObj2)
        
            molPropsDict = dict(molObj1.items() + molObj2.items())
            molPropsDict['sim']=-1
            del molPropsDict['molfile']
            
            returnmols.append(molPropsDict)
    
    
        
    # If we've filtered some results, we need a count for the table length.
    
    returnObj['iTotalRecords']=totalrecords
    
    if hitscount > 0:
        returnObj['iTotalDisplayRecords']=hitscount
    else:
        returnObj['iTotalDisplayRecords']=totalrecords
    
    
    returnObj['aaData']=returnmols
    
    return returnObj
    
def clearHitsTable(sessionid):
    '''Truncate the hits table associated with this session'''
    
    DBSession.execute("begin execute immediate 'truncate table simsubhits_"+sessonid+"'; exception when others then null; end;")
    DBSession.execute("begin execute immediate 'drop table simsubhits_"+sessonid+"'; exception when others then null; end;")
    


