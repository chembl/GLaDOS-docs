scripts Package
===============

:mod:`scripts` Package
----------------------

.. automodule:: sarfari.scripts
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`initializedb` Module
--------------------------

.. automodule:: sarfari.scripts.initializedb
    :members:
    :undoc-members:
    :show-inheritance:

