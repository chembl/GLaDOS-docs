USERS = {'admesarfari':'serengeti16','sarfari':'kDamZ2a'}
GROUPS = {'admesarfari':['group:users'],'sarfari':['group:admins']}

def groupfinder(userid, request):
    if userid in USERS:
        return GROUPS.get(userid, [])