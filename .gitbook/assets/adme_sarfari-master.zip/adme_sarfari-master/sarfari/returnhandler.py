'''
Handle returns from web services.
@author:Nathan Dedman
@company: EBI, Hinxton.
'''

import json,re
from errorhandler import *

def parseresult(*args, **kwargs):
    
    '''
    Returns a list of hits against a particular key. If the key is undefined handle the return object.
    * If we have an array of one, just pop the result.
    * If we have an error defined, raise a response error.
    '''

    try:
        request = kwargs.get('request')

    except:
        pass
    
    try:
        result = kwargs.get('result')
        
    except:
        pass
    
    try:
        keyid = kwargs.get('keyid')
    except:
        pass
    
    
    
    if keyid:        
        
        resultslist = []
        
        for row in result:
                
            resultslist.append(getattr(row,keyid))

        return resultslist
        
    
    if type(result) is list:
       
        #: Array of one. Just pop the result back
        if result.__len__() == 1:
                
            result = result.pop()
            
            #: If we got an error, raise it.
            if 'error' in result or 'errorText' in result:
            
                return errorhandler(422,request)
            
            else:    
                    
                return result
            
        else:
        
            return result
    else:
        
        return result
    

def fixJSON(j):
    
    j = re.sub(r"{\s*(\w)", r'{"\1', j)
    j = re.sub(r",\s*(\w)", r',"\1', j)
    j = re.sub(r"(\w):", r'\1":', j)
    
    return j