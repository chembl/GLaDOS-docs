'''
Handle Sequence based methods for ADMEsarfari
@author:Nathan Dedman
@company: EBI, Hinxton.
'''
from pyramid.threadlocal import get_current_registry
from Bio.Blast.Applications import NcbiblastpCommandline
from Bio import SeqIO
from Bio import SeqRecord
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import generic_protein
from Bio.Blast import NCBIXML
from Bio.Align.Applications import ClustalwCommandline,ClustalOmegaCommandline
from Bio import AlignIO
from Bio import Phylo
from Bio.Phylo import PhyloXMLIO
import StringIO,urllib2,os,shutil,re


dummy1=dummy2=0

class seqopsbase(object):
    '''Base functions for all sequence handling webservices'''

    def __init__(self,encodedsequence,unencodedsequence,tempstub,fev,lcf):

        #Set up some intial variables and parse the input
        self.encodedinput = encodedsequence
        self.unencodedinput = unencodedsequence
        self.fev = fev
        
        if lcf == False:
            self.lcf = 'no'
        else:
            self.lcf = 'yes'

        self.tempstub = tempstub
        self.workingdir = None
        self.results = []
        self.sequences= []
        self.settings = None

        self.getPyramidSettings()
        self.setscratch()

        if self.encodedinput is not None:
            self.input = self.encodedinput
            self.parseinput()

        if self.unencodedinput is not None:
            self.input = self.unencodedinput
            self.parsesequences()

        self.status = None


    def setscratch(self):
        # Create the path for the working dir
        self.workingdir = self.settings['webtemp']+self.tempstub

        # Create dir
        try:

            if not os.path.exists(self.workingdir):
                os.makedirs(self.workingdir)

        except:

            raise Exception('Could not create scratch folder')


    def removeScratch(self):
        # Remove the scratch folder
        if self.workingdir != None:
            shutil.rmtree(self.workingdir)

    def getPyramidSettings(self):
        """ Retrieves the current global ADME Sarfari settings from the ini file.
        """
        self.settings = get_current_registry().settings

        #Append the BLAST/ClustalW paths to the PATH

        os.putenv('PATH',os.getenv('PATH')+':'+self.settings['blastbin']+':'+self.settings['clustalwbin'])

        return

    def setstatus(self,status):
        self.status = status

    def getstatus(self):
        return self.status


    def getinput(self):
        '''Return the input'''
        return self.input

    def getsequences(self):
        '''Return the parsed sequences'''
        return self.sequences

    def parsesequences(self):
        '''Take input sequences object and create fasta sequences to commit to file for clustalw'''

        # The input object is an array of dicts

        for inseq in self.input:

            seq_record = SeqRecord(Seq(inseq['sequence'], generic_protein),id=str(inseq['name']),name=str(inseq['target_id']))

            self.sequences.append(seq_record)


        self.writefile()


    def parseinput(self):
        '''Parse the URL encoded input and turn it into a sequence list
           Also write to a file, should we need to BLAST them later
        '''
        # Check for leading '>sequence id' line and add it if missing

        goodfasta = re.compile('^>')

        if goodfasta.match(self.input)==None:
            # Concatenate on the missing chevron
            self.input = '>'+self.input

        fastaString = urllib2.unquote(self.input)



        reader = StringIO.StringIO(fastaString)

        # We could add a number of parser methods here, try and make it automagic!
        for seq_record in SeqIO.parse(reader, "fasta"):
            self.sequences.append(seq_record)


        self.writefile()

    def writefile(self):
        # Change to our working dir, open a fasta file and write the output

        try:
            os.chdir(str(self.workingdir))

            output_handle = open("input.fasta", "w")

            SeqIO.write(self.sequences, output_handle, "fasta")

            output_handle.close()

        except:

            raise Exception("Couldn't write input file to "+self.workingdir)

    def getFirstSeq(self):

        self.removeScratch()
        return ">"+self.sequences[0].id+" | "+self.sequences[0].description+"\n"+"".join(self.sequences[0].seq)

    def setresults(self,results):
        self.results = results



class blaster(seqopsbase):
    '''blaster handles BLASTing input sequences'''

    def __init__(self,encodedsequence,unencodedsequence,tempstub,fev,lcf):
        super(blaster,self).__init__(encodedsequence,unencodedsequence,tempstub,fev,lcf)

        # Minimum Percentage Threshold.
        self.min_perc_id = 34

    def blast(self):
        '''BLAST the input sequence(s) against the ADMESARfari sequences'''

        blastcmdline = NcbiblastpCommandline(query="input.fasta", db=self.settings['blastdbs'], outfmt=5, out="output.xml", num_threads=4, evalue=self.fev, seg=self.lcf)
        print blastcmdline
        try:

            stdout, stderr = blastcmdline()
            
            # Parse the resulting output
            blast_output = open('output.xml')
            blast_results = NCBIXML.parse(blast_output)
            blast_records = list(blast_results)

            self.setresults(blast_records)

            return {'status':'completed','statusmessage':'BLAST success'}

        except:

            return {'status':'error','statusmessage':'BLAST run could not be completed!'}





    def blastresults(self):
        return self.results

    def blastids(self):

        ids = []


        for blast in self.results:

            for alignment in blast.alignments:

                for hsp in alignment.hsps:

                    result = {}

                    # Calculate the percentage identity
                    percid=int(100*float(hsp.identities)/float(alignment.length))

                    if percid >= self.min_perc_id:

                        result['title']=alignment.title
                        parts = alignment.title.split(' ')
                        result['target_id']=int(parts[1])
                        result['score']=hsp.score
                        result['expvalue']=hsp.expect
                        #result['id']=hsp.identities
                        #result['length']=alignment.length
                        result['percentid']=percid

                        ids.append(result)


        self.removeScratch()
        return ids

class clustal(seqopsbase):
    '''clustal handles clustalw operations'''
    def __init__(self,encodedsequence,unencodedsequence,tempstub):
        super(clustal,self).__init__(encodedsequence,unencodedsequence,tempstub,dummy1,dummy2)



    def createtree(self):

        clustalw_cline = ClustalwCommandline("clustalw2", infile="input.fasta",outputtree='nexus',clustering='nj')
        stdout, sterr = clustalw_cline()

        if sterr:
            raise sterr

        returnString = open('input.dnd').read().replace('\n', '').replace('"',"'")
        self.removeScratch()

        #return open('input.dnd').read().replace('\n', '')
        return returnString
