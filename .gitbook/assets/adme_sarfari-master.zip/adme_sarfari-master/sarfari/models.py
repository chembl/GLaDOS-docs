'''
Models module for ADMESarfari
Features database reflection/introspection to create table classes automagically.
@author:Nathan Dedman
@company: EBI, Hinxton.
'''

from sqlalchemy.exc import DBAPIError
#from sqlalchemy import Table, Column, Integer, String, MetaData, join, ForeignKey
from sqlalchemy import *
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import column_property, aliased, joinedload, subqueryload, mapper, relation, relationship, contains_eager,scoped_session,sessionmaker
from sqlalchemy.pool import *
from sqlalchemy.sql import Select
from sqlalchemy.ext.compiler import compiles
from sets import Set
from zope.sqlalchemy import mark_changed
from zope.sqlalchemy import ZopeTransactionExtension
import hashlib
import datetime,copy,re
from time import mktime
from pyramid.threadlocal import get_current_request
from pyramid.response import Response
from pyramid import request

from cheminfo import chemworker
import sqlalchemy as sqla
import csv,gzip,sys,os
import numpy


Base = declarative_base()

DBSession = scoped_session(sessionmaker(extension=ZopeTransactionExtension()))

def DBSetup(settings):

    #Setup engine

    engine = engine_from_config(settings, 'sqlalchemy.')


    # Call the reflection method on this engine instance
    initialize_sql(engine)

class ReflectedTable(object):
    """
    Base class for database objects that are mapped to tables by reflection.
    """
    __tablename__ = None


# Base classes for table reflection
class assay2target(ReflectedTable):
    __tablename__ = 'assay2target'

class activities(ReflectedTable):
    __tablename__ = 'activities'

class activities2(ReflectedTable):
    __tablename__ = 'activities2'

class assays(ReflectedTable):
    __tablename__ = 'assays'

class compound_structures(ReflectedTable):
    __tablename__ = 'compound_structures'

class compound_properties(ReflectedTable):
    __tablename__ = 'compound_properties'

class compound_mols(ReflectedTable):
    __tablename__ = 'compound_mols'

class current_human(ReflectedTable):
    __tablename__ = 'current_human'

class docs(ReflectedTable):
    __tablename__ = 'docs'

class molecule_dictionary(ReflectedTable):
    __tablename__ = 'molecule_dictionary'

class target_source(ReflectedTable):
    __tablename__ = 'target_source'

class target_source_type(ReflectedTable):
    __tablename__ = 'target_source_type'

class target(ReflectedTable):
    __tablename__ = 'target'

class target_dictionary(ReflectedTable):
    __tablename__ = 'target_dictionary'

class target_clusters(ReflectedTable):
    __tablename__ = 'target_clusters'

class target_sequence_variation(ReflectedTable):
    __tablename__ = 'target_sequence_variation'

class target_sequence(ReflectedTable):
    __tablename__ = 'target_sequence'

class target_classification(ReflectedTable):
    __tablename__ = 'target_classification'

class target_pfam(ReflectedTable):
    __tablename__ = 'target_pfam'

class target_scop(ReflectedTable):
    __tablename__ = 'target_scop'

class target_scop_match_regions(ReflectedTable):
    __tablename__ = 'target_scop_match_regions'

class target_alignment(ReflectedTable):
    __tablename__ = 'target_alignment'

class target_xref(ReflectedTable):
    __tablename__ = 'target_xref'

class target_synonym(ReflectedTable):
    __tablename__ = 'target_synonym'

class synonym_type(ReflectedTable):
    __tablename__ = 'synonym_type'

class synonym_source(ReflectedTable):
    __tablename__ = 'synonym_source'

class xref_type(ReflectedTable):
    __tablename__ = 'xref_type'

class adme_class(ReflectedTable):
    __tablename__ = 'adme_class'

class taxonomy(ReflectedTable):
    __tablename__ = 'taxonomy'

class orthologue_mapping(ReflectedTable):
    __tablename__ = 'orthologue_mapping'

class protein_atlas_subcell_location(ReflectedTable):
    __tablename__ = 'protein_atlas_subcell_location'

class expression_tissue(ReflectedTable):
    __tablename__ = 'expression_tissue'

class expression_cell_type(ReflectedTable):
    __tablename__ = 'expression_cell_type'

class target_protein_expression(ReflectedTable):
    __tablename__ = 'target_protein_expression'

class protein_atlas_expression(ReflectedTable):
    __tablename__ = 'protein_atlas_expression'

class simsubhits(ReflectedTable):
    __tablename__ = 'simsubhits'

class chembl_2_uniprot(ReflectedTable):
    __tablename__ = 'chembl_2_uniprot'

class adme_invivo_ranges(ReflectedTable):
    __tablename__ = 'adme_invivo_ranges'

def map_tables(to_reflect):
    '''
    Method to iterate over the defined base classes and populate them from the db
    '''

    for _class in to_reflect:

        table = Table(_class.__tablename__, Base.metadata, autoload=True)
        mapper(_class, table)


def initialize_sql(engine):
    '''
    Method to initialise the database engine and provide a list of tables to reflect (this could be automated even further!)
    '''
    Base.metadata.bind=engine
    DBSession.configure(bind=engine)

    to_reflect = (
        activities,
        assays,
        chembl_2_uniprot,
        compound_structures,
        compound_properties,
        compound_mols,
        docs,
        molecule_dictionary,
        target_source,
        target_source_type,
        target,
        target_clusters,
        target_sequence_variation,
        target_sequence,
        target_classification,
        target_pfam,
        target_scop,
        target_scop_match_regions,
        target_alignment,
        target_xref,
        target_synonym,
        target_dictionary,
        synonym_type,
        synonym_source,
        xref_type,
        adme_class,
        taxonomy,
        orthologue_mapping,
        protein_atlas_expression,
        protein_atlas_subcell_location,
        expression_tissue,
        expression_cell_type,
        target_protein_expression,
        simsubhits,
        adme_invivo_ranges
    )

    map_tables(to_reflect)

#class RootFactory(object):
#    __acl__ = [(Allow, 'group:users', 'user'),(Allow, 'group:admins', 'admin'),(Allow, 'group:admins', 'user')]
#    def __init__(self, request):
#        pass


def dumprow(rowObj):
    '''Create a dict from a returned row
    Pop out the instance state element from the row dict and return it
    '''
    returndict = rowObj.__dict__

    if '_sa_instance_state' in returndict:
        del returndict['_sa_instance_state']

    return returndict


def get_taxid(species):

    taxid = DBSession.query(taxonomy).filter(taxonomy.genbank_common_name.like('%'+species+'%')).first().taxid

    return taxid

def get_taxids():
    returnArray=[]
    taxids = DBSession.query(taxonomy).filter(taxonomy.included==1).order_by(taxonomy.distance.desc()).all()

    for taxid in taxids:
        taxObj={}
        taxObj['name']=taxid.name
        taxObj['distance']=taxid.distance
        taxObj['taxid']=taxid.taxid

        returnArray.append(taxObj)

    return returnArray

def get_adme_classes():

    returnDict={}

    klasses = DBSession.query(adme_class).all()

    for klass in klasses:
        returnDict[klass.id]=klass.value

    return returnDict

def get_adme_sources():

    returnDict={}

    sources = DBSession.query(target_source_type).all()

    for source in sources:

        returnDict[source.id]=source.value

    return returnDict

def get_adme_tissues():

    returnDict={}

    tissues = DBSession.query(expression_tissue).all()

    for tissue in tissues:

        returnDict[tissue.id]=tissue.tissue

    return returnDict

def get_adme_cells():

    returnDict={}

    celltypes = DBSession.query(expression_cell_type).all()

    for celltype in celltypes:

        returnDict[celltype.id]=celltype.cell_type

    return returnDict

def get_species_invivo_limits():

    returnDict={}

    transformer = DBSession.query(adme_invivo_ranges).filter(adme_invivo_ranges.class_comment=='3 classes').all()

    for autobot in transformer:
        returnDict[autobot.class_id]=autobot

    return returnDict

def get_full_invivomatrix(inputTuples,session,export):
    ''' Generate the full In vivo matrix via Mark's SQL. Adapted to include Sim/Sub hits and the Average assay value '''

    returnObj={}
    opsDict={}
    returnList=[]
    sortingProp=''

    for tup in inputTuples.items():

        opsDict[tup[0]]=tup[1]

    sessionid = session.get_csrf_token()

    molshitscount = DBSession.query(simsubhits).filter(simsubhits.sessionid==sessionid).count()

    if molshitscount > 0:
        wegotmols=False
        wegothits=False

    if 'sEcho' in opsDict:
        #Do we have a call from datatables?
        datatables=True
        returnObj['sEcho']=int(opsDict['sEcho'])
        mstart = int(opsDict['iDisplayStart'])
        mstop = mstart+int(opsDict['iDisplayLength'])

        sortingColumn = opsDict['mDataProp_'+opsDict['iSortCol_0']]

        #Create sorting props
        #opsDict['sortAss'],opsDict['sortTax']=sortingColumn.split(' ')

        sortingDirection = opsDict['sSortDir_0']
        sortingProp = 'order by '+sortingColumn+' '+sortingDirection+' nulls last'

    reccount = 0

    totalrecords = DBSession.query(activities).filter(activities.invivo=='Y').count()


    if molshitscount > 0:
        invivomatrix = DBSession.execute("SELECT * FROM (SELECT mols.molregno,mols.chembl_id, data1.cl_class, data1.pivot_colname,data1.standard_value_avg,rownum rnum FROM (SELECT DISTINCT md.molregno,md.chembl_id FROM activities a, molecule_dictionary md WHERE invivo  ='Y' AND a.molregno=md.molregno) mols,(SELECT a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,COUNT(*)              AS value_count,AVG(a.standard_value) AS standard_value_avg,CASE WHEN (AVG(a.standard_value) < ranges.class_low) THEN 1 WHEN (AVG(a.standard_value) >= ranges.class_low AND AVG(a.standard_value)    < ranges.class_high) THEN 2 ELSE 3 END AS cl_class FROM activities a,assays s,( SELECT DISTINCT(trim(lower(cl_data.assay_organism))) assay_organism,cl_data.standard_type,regexp_replace(cl_data.standard_type,'/','_') AS standard_type_print,regexp_replace(regexp_replace(cl_data.standard_type ||'__'||cl_data.assay_organism,'/','_'),' ','_') AS pivot_colname, cl_data.class_low, cl_data.class_high FROM ADME_INVIVO_RANGES cl_data WHERE cl_data.standard_type='CL' AND cl_data.class_comment  ='3 classes' UNION SELECT DISTINCT(trim(lower(orgs.assay_organism))),noncl_data.standard_type,regexp_replace(noncl_data.standard_type,'/','_'),regexp_replace(regexp_replace(noncl_data.standard_type||'__'||orgs.assay_organism,'/','_'),' ','_'), noncl_data.class_low, noncl_data.class_high FROM ADME_INVIVO_RANGES noncl_data, ADME_INVIVO_RANGES orgs WHERE noncl_data.standard_type != 'CL' AND noncl_data.class_comment    ='3 classes' AND orgs.assay_organism  IS NOT NULL ) ranges WHERE a.assay_id=s.assay_id AND trim(lower(s.assay_organism)) = trim(lower(ranges.assay_organism)) AND a.standard_type               = ranges.standard_type GROUP BY a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,ranges.class_low,ranges.class_high) data1 WHERE mols.molregno =data1.molregno(+) and  mols.molregno in (select molregno from simsubhits where sessionid =  '"+sessionid+"')) pivot (MAX(cl_class) FOR (pivot_colname) IN ( 'CL__Canis_lupus_familiaris' as CL__Canis_lupus_familiaris,'Cmax__Canis_lupus_familiaris' as Cmax__Canis_lupus_familiaris,'F__Canis_lupus_familiaris' as F__Canis_lupus_familiaris,'T1_2__Canis_lupus_familiaris' as T1_2__Canis_lupus_familiaris,'Tmax__Canis_lupus_familiaris' as Tmax__Canis_lupus_familiaris,'Vd__Canis_lupus_familiaris' as Vd__Canis_lupus_familiaris,'Vdss__Canis_lupus_familiaris' as Vdss__Canis_lupus_familiaris,'CL__Cercopithecidae' as CL__Cercopithecidae,'Cmax__Cercopithecidae' as Cmax__Cercopithecidae,'F__Cercopithecidae' as F__Cercopithecidae,'T1_2__Cercopithecidae' as T1_2__Cercopithecidae,'Tmax__Cercopithecidae' as Tmax__Cercopithecidae,'Vd__Cercopithecidae' as Vd__Cercopithecidae,'Vdss__Cercopithecidae' as Vdss__Cercopithecidae,'CL__Homo_sapiens' as CL__Homo_sapiens,'Cmax__Homo_sapiens' as Cmax__Homo_sapiens,'F__Homo_sapiens' as F__Homo_sapiens,'T1_2__Homo_sapiens' as T1_2__Homo_sapiens,'Tmax__Homo_sapiens' as Tmax__Homo_sapiens,'Vd__Homo_sapiens' as Vd__Homo_sapiens,'Vdss__Homo_sapiens' as Vdss__Homo_sapiens,'CL__Macaca' as CL__Macaca,'Cmax__Macaca' as Cmax__Macaca,'F__Macaca' as F__Macaca,'T1_2__Macaca' as T1_2__Macaca,'Tmax__Macaca' as Tmax__Macaca,'Vd__Macaca' as Vd__Macaca,'Vdss__Macaca' as Vdss__Macaca,'CL__Macaca_fascicularis' as CL__Macaca_fascicularis,'Cmax__Macaca_fascicularis' as Cmax__Macaca_fascicularis,'F__Macaca_fascicularis' as F__Macaca_fascicularis,'T1_2__Macaca_fascicularis' as T1_2__Macaca_fascicularis,'Tmax__Macaca_fascicularis' as Tmax__Macaca_fascicularis,'Vd__Macaca_fascicularis' as Vd__Macaca_fascicularis,'Vdss__Macaca_fascicularis' as Vdss__Macaca_fascicularis,'CL__Macaca_mulatta' as CL__Macaca_mulatta,'Cmax__Macaca_mulatta' as Cmax__Macaca_mulatta,'F__Macaca_mulatta' as F__Macaca_mulatta,'T1_2__Macaca_mulatta' as T1_2__Macaca_mulatta,'Tmax__Macaca_mulatta' as Tmax__Macaca_mulatta,'Vd__Macaca_mulatta' as Vd__Macaca_mulatta,'Vdss__Macaca_mulatta' as Vdss__Macaca_mulatta,'CL__marmosets' as CL__marmosets,'Cmax__marmosets' as Cmax__marmosets,'F__marmosets' as F__marmosets,'T1_2__marmosets' as T1_2__marmosets,'Tmax__marmosets' as Tmax__marmosets,'Vd__marmosets' as Vd__marmosets,'Vdss__marmosets' as Vdss__marmosets,'CL__monkey' as CL__monkey,'Cmax__monkey' as Cmax__monkey,'F__monkey' as F__monkey,'T1_2__monkey' as T1_2__monkey,'Tmax__monkey' as Tmax__monkey,'Vd__monkey' as Vd__monkey,'Vdss__monkey' as Vdss__monkey,'CL__Mus_musculus' as CL__Mus_musculus,'Cmax__Mus_musculus' as Cmax__Mus_musculus,'F__Mus_musculus' as F__Mus_musculus,'T1_2__Mus_musculus' as T1_2__Mus_musculus,'Tmax__Mus_musculus' as Tmax__Mus_musculus,'Vd__Mus_musculus' as Vd__Mus_musculus,'Vdss__Mus_musculus' as Vdss__Mus_musculus,'CL__Primates' as CL__Primates,'Cmax__Primates' as Cmax__Primates,'F__Primates' as F__Primates,'T1_2__Primates' as T1_2__Primates,'Tmax__Primates' as Tmax__Primates,'Vd__Primates' as Vd__Primates,'Vdss__Primates' as Vdss__Primates,'CL__Rattus_norvegicus' as CL__Rattus_norvegicus,'Cmax__Rattus_norvegicus' as Cmax__Rattus_norvegicus,'F__Rattus_norvegicus' as F__Rattus_norvegicus,'T1_2__Rattus_norvegicus' as T1_2__Rattus_norvegicus,'Tmax__Rattus_norvegicus' as Tmax__Rattus_norvegicus,'Vd__Rattus_norvegicus' as Vd__Rattus_norvegicus,'Vdss__Rattus_norvegicus' as Vdss__Rattus_norvegicus )) "+sortingProp)
        reccount = DBSession.execute("SELECT count (*) FROM (SELECT mols.molregno,mols.chembl_id, data1.cl_class, data1.pivot_colname,data1.standard_value_avg,rownum rnum FROM (SELECT DISTINCT md.molregno,md.chembl_id FROM activities a, molecule_dictionary md WHERE invivo  ='Y' AND a.molregno=md.molregno) mols,(SELECT a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,COUNT(*)              AS value_count,AVG(a.standard_value) AS standard_value_avg,CASE WHEN (AVG(a.standard_value) < ranges.class_low) THEN 1 WHEN (AVG(a.standard_value) >= ranges.class_low AND AVG(a.standard_value)    < ranges.class_high) THEN 2 ELSE 3 END AS cl_class FROM activities a,assays s,( SELECT DISTINCT(trim(lower(cl_data.assay_organism))) assay_organism,cl_data.standard_type,regexp_replace(cl_data.standard_type,'/','_') AS standard_type_print,regexp_replace(regexp_replace(cl_data.standard_type ||'__'||cl_data.assay_organism,'/','_'),' ','_') AS pivot_colname, cl_data.class_low, cl_data.class_high FROM ADME_INVIVO_RANGES cl_data WHERE cl_data.standard_type='CL' AND cl_data.class_comment  ='3 classes' UNION SELECT DISTINCT(trim(lower(orgs.assay_organism))),noncl_data.standard_type,regexp_replace(noncl_data.standard_type,'/','_'),regexp_replace(regexp_replace(noncl_data.standard_type||'__'||orgs.assay_organism,'/','_'),' ','_'), noncl_data.class_low, noncl_data.class_high FROM ADME_INVIVO_RANGES noncl_data, ADME_INVIVO_RANGES orgs WHERE noncl_data.standard_type != 'CL' AND noncl_data.class_comment    ='3 classes' AND orgs.assay_organism  IS NOT NULL ) ranges WHERE a.assay_id=s.assay_id AND trim(lower(s.assay_organism)) = trim(lower(ranges.assay_organism)) AND a.standard_type               = ranges.standard_type GROUP BY a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,ranges.class_low,ranges.class_high) data1 WHERE mols.molregno =data1.molregno(+) and  mols.molregno in (select molregno from simsubhits where sessionid =  '"+sessionid+"')) pivot (MAX(cl_class) FOR (pivot_colname) IN ( 'CL__Canis_lupus_familiaris' as CL__Canis_lupus_familiaris,'Cmax__Canis_lupus_familiaris' as Cmax__Canis_lupus_familiaris,'F__Canis_lupus_familiaris' as F__Canis_lupus_familiaris,'T1_2__Canis_lupus_familiaris' as T1_2__Canis_lupus_familiaris,'Tmax__Canis_lupus_familiaris' as Tmax__Canis_lupus_familiaris,'Vd__Canis_lupus_familiaris' as Vd__Canis_lupus_familiaris,'Vdss__Canis_lupus_familiaris' as Vdss__Canis_lupus_familiaris,'CL__Cercopithecidae' as CL__Cercopithecidae,'Cmax__Cercopithecidae' as Cmax__Cercopithecidae,'F__Cercopithecidae' as F__Cercopithecidae,'T1_2__Cercopithecidae' as T1_2__Cercopithecidae,'Tmax__Cercopithecidae' as Tmax__Cercopithecidae,'Vd__Cercopithecidae' as Vd__Cercopithecidae,'Vdss__Cercopithecidae' as Vdss__Cercopithecidae,'CL__Homo_sapiens' as CL__Homo_sapiens,'Cmax__Homo_sapiens' as Cmax__Homo_sapiens,'F__Homo_sapiens' as F__Homo_sapiens,'T1_2__Homo_sapiens' as T1_2__Homo_sapiens,'Tmax__Homo_sapiens' as Tmax__Homo_sapiens,'Vd__Homo_sapiens' as Vd__Homo_sapiens,'Vdss__Homo_sapiens' as Vdss__Homo_sapiens,'CL__Macaca' as CL__Macaca,'Cmax__Macaca' as Cmax__Macaca,'F__Macaca' as F__Macaca,'T1_2__Macaca' as T1_2__Macaca,'Tmax__Macaca' as Tmax__Macaca,'Vd__Macaca' as Vd__Macaca,'Vdss__Macaca' as Vdss__Macaca,'CL__Macaca_fascicularis' as CL__Macaca_fascicularis,'Cmax__Macaca_fascicularis' as Cmax__Macaca_fascicularis,'F__Macaca_fascicularis' as F__Macaca_fascicularis,'T1_2__Macaca_fascicularis' as T1_2__Macaca_fascicularis,'Tmax__Macaca_fascicularis' as Tmax__Macaca_fascicularis,'Vd__Macaca_fascicularis' as Vd__Macaca_fascicularis,'Vdss__Macaca_fascicularis' as Vdss__Macaca_fascicularis,'CL__Macaca_mulatta' as CL__Macaca_mulatta,'Cmax__Macaca_mulatta' as Cmax__Macaca_mulatta,'F__Macaca_mulatta' as F__Macaca_mulatta,'T1_2__Macaca_mulatta' as T1_2__Macaca_mulatta,'Tmax__Macaca_mulatta' as Tmax__Macaca_mulatta,'Vd__Macaca_mulatta' as Vd__Macaca_mulatta,'Vdss__Macaca_mulatta' as Vdss__Macaca_mulatta,'CL__marmosets' as CL__marmosets,'Cmax__marmosets' as Cmax__marmosets,'F__marmosets' as F__marmosets,'T1_2__marmosets' as T1_2__marmosets,'Tmax__marmosets' as Tmax__marmosets,'Vd__marmosets' as Vd__marmosets,'Vdss__marmosets' as Vdss__marmosets,'CL__monkey' as CL__monkey,'Cmax__monkey' as Cmax__monkey,'F__monkey' as F__monkey,'T1_2__monkey' as T1_2__monkey,'Tmax__monkey' as Tmax__monkey,'Vd__monkey' as Vd__monkey,'Vdss__monkey' as Vdss__monkey,'CL__Mus_musculus' as CL__Mus_musculus,'Cmax__Mus_musculus' as Cmax__Mus_musculus,'F__Mus_musculus' as F__Mus_musculus,'T1_2__Mus_musculus' as T1_2__Mus_musculus,'Tmax__Mus_musculus' as Tmax__Mus_musculus,'Vd__Mus_musculus' as Vd__Mus_musculus,'Vdss__Mus_musculus' as Vdss__Mus_musculus,'CL__Primates' as CL__Primates,'Cmax__Primates' as Cmax__Primates,'F__Primates' as F__Primates,'T1_2__Primates' as T1_2__Primates,'Tmax__Primates' as Tmax__Primates,'Vd__Primates' as Vd__Primates,'Vdss__Primates' as Vdss__Primates,'CL__Rattus_norvegicus' as CL__Rattus_norvegicus,'Cmax__Rattus_norvegicus' as Cmax__Rattus_norvegicus,'F__Rattus_norvegicus' as F__Rattus_norvegicus,'T1_2__Rattus_norvegicus' as T1_2__Rattus_norvegicus,'Tmax__Rattus_norvegicus' as Tmax__Rattus_norvegicus,'Vd__Rattus_norvegicus' as Vd__Rattus_norvegicus,'Vdss__Rattus_norvegicus' as Vdss__Rattus_norvegicus )) "+sortingProp)
        reccount = reccount.first()[0]

    else:
        invivomatrix = DBSession.execute("SELECT * FROM (SELECT mols.molregno,mols.chembl_id, data1.cl_class, data1.pivot_colname,data1.standard_value_avg,rownum rnum FROM (SELECT DISTINCT md.molregno,md.chembl_id FROM activities a, molecule_dictionary md WHERE invivo  ='Y' AND a.molregno=md.molregno) mols,(SELECT a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,COUNT(*)              AS value_count,AVG(a.standard_value) AS standard_value_avg,CASE WHEN (AVG(a.standard_value) < ranges.class_low) THEN 1 WHEN (AVG(a.standard_value) >= ranges.class_low AND AVG(a.standard_value)    < ranges.class_high) THEN 2 ELSE 3 END AS cl_class FROM activities a,assays s,( SELECT DISTINCT(trim(lower(cl_data.assay_organism))) assay_organism,cl_data.standard_type,regexp_replace(cl_data.standard_type,'/','_') AS standard_type_print,regexp_replace(regexp_replace(cl_data.standard_type ||'__'||cl_data.assay_organism,'/','_'),' ','_') AS pivot_colname, cl_data.class_low, cl_data.class_high FROM ADME_INVIVO_RANGES cl_data WHERE cl_data.standard_type='CL' AND cl_data.class_comment  ='3 classes' UNION SELECT DISTINCT(trim(lower(orgs.assay_organism))),noncl_data.standard_type,regexp_replace(noncl_data.standard_type,'/','_'),regexp_replace(regexp_replace(noncl_data.standard_type||'__'||orgs.assay_organism,'/','_'),' ','_'), noncl_data.class_low, noncl_data.class_high FROM ADME_INVIVO_RANGES noncl_data, ADME_INVIVO_RANGES orgs WHERE noncl_data.standard_type != 'CL' AND noncl_data.class_comment    ='3 classes' AND orgs.assay_organism  IS NOT NULL ) ranges WHERE a.assay_id=s.assay_id AND trim(lower(s.assay_organism)) = trim(lower(ranges.assay_organism)) AND a.standard_type               = ranges.standard_type GROUP BY a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,ranges.class_low,ranges.class_high) data1 WHERE mols.molregno =data1.molregno(+)) pivot (MAX(cl_class) FOR (pivot_colname) IN ( 'CL__Canis_lupus_familiaris' as CL__Canis_lupus_familiaris,'Cmax__Canis_lupus_familiaris' as Cmax__Canis_lupus_familiaris,'F__Canis_lupus_familiaris' as F__Canis_lupus_familiaris,'T1_2__Canis_lupus_familiaris' as T1_2__Canis_lupus_familiaris,'Tmax__Canis_lupus_familiaris' as Tmax__Canis_lupus_familiaris,'Vd__Canis_lupus_familiaris' as Vd__Canis_lupus_familiaris,'Vdss__Canis_lupus_familiaris' as Vdss__Canis_lupus_familiaris,'CL__Cercopithecidae' as CL__Cercopithecidae,'Cmax__Cercopithecidae' as Cmax__Cercopithecidae,'F__Cercopithecidae' as F__Cercopithecidae,'T1_2__Cercopithecidae' as T1_2__Cercopithecidae,'Tmax__Cercopithecidae' as Tmax__Cercopithecidae,'Vd__Cercopithecidae' as Vd__Cercopithecidae,'Vdss__Cercopithecidae' as Vdss__Cercopithecidae,'CL__Homo_sapiens' as CL__Homo_sapiens,'Cmax__Homo_sapiens' as Cmax__Homo_sapiens,'F__Homo_sapiens' as F__Homo_sapiens,'T1_2__Homo_sapiens' as T1_2__Homo_sapiens,'Tmax__Homo_sapiens' as Tmax__Homo_sapiens,'Vd__Homo_sapiens' as Vd__Homo_sapiens,'Vdss__Homo_sapiens' as Vdss__Homo_sapiens,'CL__Macaca' as CL__Macaca,'Cmax__Macaca' as Cmax__Macaca,'F__Macaca' as F__Macaca,'T1_2__Macaca' as T1_2__Macaca,'Tmax__Macaca' as Tmax__Macaca,'Vd__Macaca' as Vd__Macaca,'Vdss__Macaca' as Vdss__Macaca,'CL__Macaca_fascicularis' as CL__Macaca_fascicularis,'Cmax__Macaca_fascicularis' as Cmax__Macaca_fascicularis,'F__Macaca_fascicularis' as F__Macaca_fascicularis,'T1_2__Macaca_fascicularis' as T1_2__Macaca_fascicularis,'Tmax__Macaca_fascicularis' as Tmax__Macaca_fascicularis,'Vd__Macaca_fascicularis' as Vd__Macaca_fascicularis,'Vdss__Macaca_fascicularis' as Vdss__Macaca_fascicularis,'CL__Macaca_mulatta' as CL__Macaca_mulatta,'Cmax__Macaca_mulatta' as Cmax__Macaca_mulatta,'F__Macaca_mulatta' as F__Macaca_mulatta,'T1_2__Macaca_mulatta' as T1_2__Macaca_mulatta,'Tmax__Macaca_mulatta' as Tmax__Macaca_mulatta,'Vd__Macaca_mulatta' as Vd__Macaca_mulatta,'Vdss__Macaca_mulatta' as Vdss__Macaca_mulatta,'CL__marmosets' as CL__marmosets,'Cmax__marmosets' as Cmax__marmosets,'F__marmosets' as F__marmosets,'T1_2__marmosets' as T1_2__marmosets,'Tmax__marmosets' as Tmax__marmosets,'Vd__marmosets' as Vd__marmosets,'Vdss__marmosets' as Vdss__marmosets,'CL__monkey' as CL__monkey,'Cmax__monkey' as Cmax__monkey,'F__monkey' as F__monkey,'T1_2__monkey' as T1_2__monkey,'Tmax__monkey' as Tmax__monkey,'Vd__monkey' as Vd__monkey,'Vdss__monkey' as Vdss__monkey,'CL__Mus_musculus' as CL__Mus_musculus,'Cmax__Mus_musculus' as Cmax__Mus_musculus,'F__Mus_musculus' as F__Mus_musculus,'T1_2__Mus_musculus' as T1_2__Mus_musculus,'Tmax__Mus_musculus' as Tmax__Mus_musculus,'Vd__Mus_musculus' as Vd__Mus_musculus,'Vdss__Mus_musculus' as Vdss__Mus_musculus,'CL__Primates' as CL__Primates,'Cmax__Primates' as Cmax__Primates,'F__Primates' as F__Primates,'T1_2__Primates' as T1_2__Primates,'Tmax__Primates' as Tmax__Primates,'Vd__Primates' as Vd__Primates,'Vdss__Primates' as Vdss__Primates,'CL__Rattus_norvegicus' as CL__Rattus_norvegicus,'Cmax__Rattus_norvegicus' as Cmax__Rattus_norvegicus,'F__Rattus_norvegicus' as F__Rattus_norvegicus,'T1_2__Rattus_norvegicus' as T1_2__Rattus_norvegicus,'Tmax__Rattus_norvegicus' as Tmax__Rattus_norvegicus,'Vd__Rattus_norvegicus' as Vd__Rattus_norvegicus,'Vdss__Rattus_norvegicus' as Vdss__Rattus_norvegicus )) "+sortingProp)
        reccount = DBSession.execute("SELECT count (*) FROM (SELECT mols.molregno,mols.chembl_id, data1.cl_class, data1.pivot_colname,data1.standard_value_avg,rownum rnum FROM (SELECT DISTINCT md.molregno,md.chembl_id FROM activities a, molecule_dictionary md WHERE invivo  ='Y' AND a.molregno=md.molregno) mols,(SELECT a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,COUNT(*)              AS value_count,AVG(a.standard_value) AS standard_value_avg,CASE WHEN (AVG(a.standard_value) < ranges.class_low) THEN 1 WHEN (AVG(a.standard_value) >= ranges.class_low AND AVG(a.standard_value)    < ranges.class_high) THEN 2 ELSE 3 END AS cl_class FROM activities a,assays s,( SELECT DISTINCT(trim(lower(cl_data.assay_organism))) assay_organism,cl_data.standard_type,regexp_replace(cl_data.standard_type,'/','_') AS standard_type_print,regexp_replace(regexp_replace(cl_data.standard_type ||'__'||cl_data.assay_organism,'/','_'),' ','_') AS pivot_colname, cl_data.class_low, cl_data.class_high FROM ADME_INVIVO_RANGES cl_data WHERE cl_data.standard_type='CL' AND cl_data.class_comment  ='3 classes' UNION SELECT DISTINCT(trim(lower(orgs.assay_organism))),noncl_data.standard_type,regexp_replace(noncl_data.standard_type,'/','_'),regexp_replace(regexp_replace(noncl_data.standard_type||'__'||orgs.assay_organism,'/','_'),' ','_'), noncl_data.class_low, noncl_data.class_high FROM ADME_INVIVO_RANGES noncl_data, ADME_INVIVO_RANGES orgs WHERE noncl_data.standard_type != 'CL' AND noncl_data.class_comment    ='3 classes' AND orgs.assay_organism  IS NOT NULL ) ranges WHERE a.assay_id=s.assay_id AND trim(lower(s.assay_organism)) = trim(lower(ranges.assay_organism)) AND a.standard_type               = ranges.standard_type GROUP BY a.molregno,ranges.assay_organism,ranges.standard_type,ranges.pivot_colname,ranges.class_low,ranges.class_high) data1 WHERE mols.molregno =data1.molregno(+)) pivot (MAX(cl_class) FOR (pivot_colname) IN ( 'CL__Canis_lupus_familiaris' as CL__Canis_lupus_familiaris,'Cmax__Canis_lupus_familiaris' as Cmax__Canis_lupus_familiaris,'F__Canis_lupus_familiaris' as F__Canis_lupus_familiaris,'T1_2__Canis_lupus_familiaris' as T1_2__Canis_lupus_familiaris,'Tmax__Canis_lupus_familiaris' as Tmax__Canis_lupus_familiaris,'Vd__Canis_lupus_familiaris' as Vd__Canis_lupus_familiaris,'Vdss__Canis_lupus_familiaris' as Vdss__Canis_lupus_familiaris,'CL__Cercopithecidae' as CL__Cercopithecidae,'Cmax__Cercopithecidae' as Cmax__Cercopithecidae,'F__Cercopithecidae' as F__Cercopithecidae,'T1_2__Cercopithecidae' as T1_2__Cercopithecidae,'Tmax__Cercopithecidae' as Tmax__Cercopithecidae,'Vd__Cercopithecidae' as Vd__Cercopithecidae,'Vdss__Cercopithecidae' as Vdss__Cercopithecidae,'CL__Homo_sapiens' as CL__Homo_sapiens,'Cmax__Homo_sapiens' as Cmax__Homo_sapiens,'F__Homo_sapiens' as F__Homo_sapiens,'T1_2__Homo_sapiens' as T1_2__Homo_sapiens,'Tmax__Homo_sapiens' as Tmax__Homo_sapiens,'Vd__Homo_sapiens' as Vd__Homo_sapiens,'Vdss__Homo_sapiens' as Vdss__Homo_sapiens,'CL__Macaca' as CL__Macaca,'Cmax__Macaca' as Cmax__Macaca,'F__Macaca' as F__Macaca,'T1_2__Macaca' as T1_2__Macaca,'Tmax__Macaca' as Tmax__Macaca,'Vd__Macaca' as Vd__Macaca,'Vdss__Macaca' as Vdss__Macaca,'CL__Macaca_fascicularis' as CL__Macaca_fascicularis,'Cmax__Macaca_fascicularis' as Cmax__Macaca_fascicularis,'F__Macaca_fascicularis' as F__Macaca_fascicularis,'T1_2__Macaca_fascicularis' as T1_2__Macaca_fascicularis,'Tmax__Macaca_fascicularis' as Tmax__Macaca_fascicularis,'Vd__Macaca_fascicularis' as Vd__Macaca_fascicularis,'Vdss__Macaca_fascicularis' as Vdss__Macaca_fascicularis,'CL__Macaca_mulatta' as CL__Macaca_mulatta,'Cmax__Macaca_mulatta' as Cmax__Macaca_mulatta,'F__Macaca_mulatta' as F__Macaca_mulatta,'T1_2__Macaca_mulatta' as T1_2__Macaca_mulatta,'Tmax__Macaca_mulatta' as Tmax__Macaca_mulatta,'Vd__Macaca_mulatta' as Vd__Macaca_mulatta,'Vdss__Macaca_mulatta' as Vdss__Macaca_mulatta,'CL__marmosets' as CL__marmosets,'Cmax__marmosets' as Cmax__marmosets,'F__marmosets' as F__marmosets,'T1_2__marmosets' as T1_2__marmosets,'Tmax__marmosets' as Tmax__marmosets,'Vd__marmosets' as Vd__marmosets,'Vdss__marmosets' as Vdss__marmosets,'CL__monkey' as CL__monkey,'Cmax__monkey' as Cmax__monkey,'F__monkey' as F__monkey,'T1_2__monkey' as T1_2__monkey,'Tmax__monkey' as Tmax__monkey,'Vd__monkey' as Vd__monkey,'Vdss__monkey' as Vdss__monkey,'CL__Mus_musculus' as CL__Mus_musculus,'Cmax__Mus_musculus' as Cmax__Mus_musculus,'F__Mus_musculus' as F__Mus_musculus,'T1_2__Mus_musculus' as T1_2__Mus_musculus,'Tmax__Mus_musculus' as Tmax__Mus_musculus,'Vd__Mus_musculus' as Vd__Mus_musculus,'Vdss__Mus_musculus' as Vdss__Mus_musculus,'CL__Primates' as CL__Primates,'Cmax__Primates' as Cmax__Primates,'F__Primates' as F__Primates,'T1_2__Primates' as T1_2__Primates,'Tmax__Primates' as Tmax__Primates,'Vd__Primates' as Vd__Primates,'Vdss__Primates' as Vdss__Primates,'CL__Rattus_norvegicus' as CL__Rattus_norvegicus,'Cmax__Rattus_norvegicus' as Cmax__Rattus_norvegicus,'F__Rattus_norvegicus' as F__Rattus_norvegicus,'T1_2__Rattus_norvegicus' as T1_2__Rattus_norvegicus,'Tmax__Rattus_norvegicus' as Tmax__Rattus_norvegicus,'Vd__Rattus_norvegicus' as Vd__Rattus_norvegicus,'Vdss__Rattus_norvegicus' as Vdss__Rattus_norvegicus )) "+sortingProp)
        reccount = reccount.first()[0]

    propNames=['molregno','chembl_id','standard_value_avg','rnum','cl__mus_musculus','cmax__mus_musculus','f__mus_musculus','t1_2__mus_musculus','tmax__mus_musculus','vd__mus_musculus','vdss__mus_musculus','cl__cercopithecidae','cmax__cercopithecidae','f__cercopithecidae','t1_2__cercopithecidae','tmax__cercopithecidae','vd__cercopithecidae','vdss__cercopithecidae','cl__homo_sapiens','cmax__homo_sapiens','f__homo_sapiens','t1_2__homo_sapiens','tmax__homo_sapiens','vd__homo_sapiens','vdss__homo_sapiens','cl__macaca','cmax__macaca','f__macaca','t1_2__macaca','tmax__macaca','vd__macaca','vdss__macaca','cl__macaca_fascicularis','cmax__macaca_fascicularis','f__macaca_fascicularis','t1_2__macaca_fascicularis','tmax__macaca_fascicularis','vd__macaca_fascicularis','vdss__macaca_fascicularis','cl__macaca_mulatta','cmax__macaca_mulatta','f__macaca_mulatta','t1_2__macaca_mulatta','tmax__macaca_mulatta','vd__macaca_mulatta','vdss__macaca_mulatta','cl__marmosets','cmax__marmosets','f__marmosets','t1_2__marmosets','tmax__marmosets','vd__marmosets','vdss__marmosets','cl__monkey','cmax__monkey','f__monkey','t1_2__monkey','tmax__monkey','vd__monkey','vdss__monkey','cl__mus_musculus','cmax__mus_musculus','f__mus_musculus','t1_2__mus_musculus','tmax__mus_musculus','vd__mus_musculus','vdss__mus_musculus','cl__primates','cmax__primates','f__primates','t1_2__primates','tmax__primates','vd__primates','vdss__primates','cl__rattus_norvegicus','cmax__rattus_norvegicus','f__rattus_norvegicus','t1_2__rattus_norvegicus','tmax__rattus_norvegicus','vd__rattus_norvegicus','vdss__rattus_norvegicus']




    for cnt,row in enumerate(invivomatrix):
            # We've got a tuple here...

        if export==False:


            if 'sEcho' in opsDict:

                if cnt >mstart and cnt <=mstop:

                    rowDict={}

                    for i,v in enumerate(row):
                        rowDict[propNames[i]]=v

                    del rowDict['rnum']
                    returnList.append(rowDict)

            else:

                rowDict={}

                for i,v in enumerate(row):
                    rowDict[propNames[i]]=v

                del rowDict['rnum']
                returnList.append(rowDict)

        if export==True:
                rowDict={}

                for i,v in enumerate(row):
                    rowDict[propNames[i]]=v

                del rowDict['rnum']
                returnList.append(rowDict)


    if 'sEcho' in opsDict:


        # Slice the array and create the datatables output
        returnObj['iTotalRecords']=totalrecords
        returnObj['iTotalDisplayRecords']=reccount
        returnObj['aaData']=returnList
    else:
        returnObj={'invivomatrix':returnList}

    if export==False:
        return returnObj
    else:
        return parseExport(opsDict,returnList,'full_invivomatrix')



def get_target_invivomatrix(astid):
    ''' Generate the In vivo data matrix for a single ADME Sarfari target

        We can combine Vd and VdSS and also all "monkey/primate" species

        Dump out into a format for Highcharts heatmap plugin

        This will give a 'condensed' view.

        Create some 'dummy' parameters to call the main function (one target, all taxids)

    '''

    session={}
    session['hittids']=[astid]
    session['hitsource']='API'

    alltaxids = DBSession.query(taxonomy).filter(taxonomy.included==1).order_by(taxonomy.distance.desc()).all()

    taxidlist = []

    for txd in alltaxids:

        taxidlist.append(str(txd.taxid))


    return get_invivomatrix(",".join(taxidlist),{'sortprop':'alogp'},session,False)


def get_invivomatrix(taxidsin,inputTuples,session,export):
    ''' Generate the In vivo data matrix for a set of taxids and compounds

        We can combine Vd and VdSS and also all "monkey/primate" species

        Dump out into a format for Highcharts heatmap plugin

        This will give a 'condensed' view.


    '''


    opsDict={}
    returnObj={}
    datatables=False

    for tup in inputTuples.items():

        opsDict[tup[0]]=tup[1]


    if 'sortprop' not in opsDict:
        opsDict['sortprop']=opsDict['property']

    opsDict['sortprop']=opsDict['sortprop'].lower()



    taxidsin=taxidsin.split(',')

    try:
        molhitscount=DBSession.query(simsubhits).filter(simsubhits.sessionid==session.get_csrf_token()).count()
    except:
        molhitscount=0

    if 'hittids' in session and session['hitsource']!='simsub':
        wegothits=True
        hittype=True
        if type(session['hittids'])==list:
            myhits = session['hittids'][:] # List of target IDs
        else:
            myhits = session['hittids'].keys() # Dict of target IDs and BLAST values

        myhits.sort()

        #We've got a list of target ids, so pull mols via target

        #mols via target
        invivomatrix = DBSession.query(compound_properties) \
        .join(activities,compound_properties.molregno==activities.molregno) \
        .join(assays,activities.assay_id==assays.assay_id) \
        .join(chembl_2_uniprot,assays.tid==chembl_2_uniprot.tid) \
        .join(target,chembl_2_uniprot.component_id==target.chembl_target_component_id) \
        .distinct(compound_properties.molregno) \
        .filter(target.id.in_(session['hittids']))



        ## Subquery to generate distinct list of compounds
        invivomatrix = invivomatrix.from_self(compound_properties,activities,molecule_dictionary,assays) \
        .filter(activities.invivo=='Y') \
        .filter(molecule_dictionary.molregno==compound_properties.molregno) \
        .filter(activities.molregno==compound_properties.molregno) \
        .filter(assays.assay_id==activities.assay_id)

        #.filter(molecule_dictionary.molregno==activities.molregno) \
        #.filter(compound_properties.molregno==activities.molregno) \


        #invivomatrix = DBSession.query(compound_properties.molregno,activities) \
        #.join(compound_properties,activities.molregno==compound_properties.molregno) \
        #.join(assays,activities.assay_id==assays.assay_id) \
        #.join(assays,chembl_2_uniprot.tid==assays.tid) \
        #.join(chembl_2_uniprot,target.chembl_target_component_id==chembl_2_uniprot.component_id)\
        #.filter(target.id.in_(session['hittids']))

    elif molhitscount > 0:
        wegotmols=True
        wegothits=False
        invivomatrix = DBSession.query(activities, assays,molecule_dictionary,simsubhits,compound_properties) \
        .join(assays,activities.assay_id==assays.assay_id) \
        .filter(molecule_dictionary.molregno==activities.molregno) \
        .filter(molecule_dictionary.molregno==simsubhits.molregno) \
        .filter(compound_properties.molregno==simsubhits.molregno) \
        .distinct(molecule_dictionary.molregno)\
        .filter(activities.invivo=='Y') \
        .filter(simsubhits.sessionid==session.get_csrf_token())


    else:

        # Send empty dictionary back since we can't display the whole matrix in highcharts.

        return {"xcats": [], "ycats": [], "data": [],"error":"No subset of compounds defined"}



    lookup = get_species_invivo_limits()


    returnDict={}
    returnDict['data']=[]
    returnDict['xcats']=[] #Invivo properties per taxonomy
    returnDict['ycats']=[] #Chembl IDs / molregno

    biggusDictus={}
    myassays=[]
    myorganisms=[]

    # Group the following taxonomies under the 'Monkey' moniker!
    lookupDict={'Primates':'Monkey','Macaca':'Monkey','Macaca fascicularis':'Monkey','Macaca mulatta':'Monkey','marmosets':'Monkey','Cercopithecidae':'Monkey','Monkey':'Monkey','monkey':'Monkey','Rattus norvegicus':'Rat','Homo sapiens':'Human','Canis lupus familiaris':'Dog','Mus musculus':'Mouse'}

    myorganisms = ['Monkey','Rat','Human','Dog','Mouse']
    myassays =['T1/2','CL','F','Vd','Cmax','Tmax']

    for thingy in invivomatrix:

        if wegothits==True:
            comp,act,md,ass = thingy
        elif wegotmols==True:
            act,ass,md,ssh,comp  = thingy
        elif wegothits==False:
            comp,act,md,ass = thingy

        myid = md.chembl_id

        chemblid = md.chembl_id

        props = dumprow(comp)


        if myid not in biggusDictus.keys():

            biggusDictus[myid]={}
            biggusDictus[myid]['chemblid']=md.chembl_id
            biggusDictus[myid]['molregno']=md.molregno
            biggusDictus[myid]['sortbyme']=props[opsDict['sortprop']]
            biggusDictus[myid]['sortedby']=props[opsDict['sortprop']]

        for binner in lookup:

            ibinner=lookup[binner]

            if ibinner.assay_organism==ass.assay_organism or ibinner.assay_organism==None and ibinner.standard_type==act.standard_type:

                if ass.assay_organism!=None:

                    org = ass.assay_organism
                    ivass = act.standard_type


                    # An equivalent assay
                    if ivass=='Vdss':
                        ivass='Vd'

                    #Primate grouping and renam
                    org=lookupDict[org]

                    if ivass not in myassays:
                        myassays.append(ivass)

                    if org not in myorganisms:
                        myorganisms.append(org)


                    if ivass not in biggusDictus[myid]:

                        biggusDictus[myid][ivass]={}
                        biggusDictus[myid][ivass][org]={}

                        biggusDictus[myid][ivass][org]['avg']=0
                        biggusDictus[myid][ivass][org]['values']=[]
                        biggusDictus[myid][ivass][org]['score']=0

                        if act.standard_value == None:
                            biggusDictus[myid][ivass][org]['values'].append(0)
                        else:
                            biggusDictus[myid][ivass][org]['values'].append(act.standard_value)

                        biggusDictus[myid][ivass][org]['avg']=float(sum(biggusDictus[myid][ivass][org]['values']))/float(biggusDictus[myid][ivass][org]['values'].__len__())

                    else:

                        if org not in biggusDictus[myid][ivass]:

                            biggusDictus[myid][ivass][org]={}
                            biggusDictus[myid][ivass][org]['avg']=0
                            biggusDictus[myid][ivass][org]['values']=[]
                            biggusDictus[myid][ivass][org]['score']=0

                        if act.standard_value == None:
                            biggusDictus[myid][ivass][org]['values'].append(0)
                        else:
                            biggusDictus[myid][ivass][org]['values'].append(act.standard_value)

                        biggusDictus[myid][ivass][org]['avg']=float(sum(biggusDictus[myid][ivass][org]['values']))/float(biggusDictus[myid][ivass][org]['values'].__len__())


                    # Now do the scoring

                    if biggusDictus[myid][ivass][org]['avg'] !=0:
                        biggusDictus[myid][ivass][org]['score']=2

                    if biggusDictus[myid][ivass][org]['avg'] < ibinner.class_low:
                        biggusDictus[myid][ivass][org]['score']=1

                    if biggusDictus[myid][ivass][org]['avg'] >= ibinner.class_high:
                        biggusDictus[myid][ivass][org]['score']=3

                    #if mytype not in returnDict['xcats']:
                    #    returnDict['xcats'].append(mytype)

    largusArrayus=[]

    myassays.sort()
    myorganisms.sort()

    for molec in biggusDictus:

        if molec != None:
            completeDict={}
            completeDict=biggusDictus[molec]


            if 'sortTax' in opsDict and 'sortAss' in opsDict:

                if opsDict['sortAss'] in completeDict:
                    if opsDict['sortTax'] in completeDict[opsDict['sortAss']]:
                        completeDict['sortbyme']=completeDict[opsDict['sortAss']][opsDict['sortTax']]['score']
                    else:
                        completeDict['sortbyme']=-1
                else:
                        completeDict['sortbyme']=-1



                #    completeDict['sortbyme']=biggusDictus[molec][opsDict['sortAss']][opsDict['sortTax']]['score']
                #else:
                #    completeDict['sortbyme']=-1

            largusArrayus.append(completeDict)


    largusArrayus.sort(key=lambda x: x['sortbyme'])



    #returnDict['xcats']={}
    #returnDict['xcats']['categories']=[]
    #
    #for anassay in myassays:
    #    xaxisObj={}
    #    xaxisObj['name']=anassay
    #    xaxisObj['categories']=myorganisms
    #
    #    returnDict['xcats']['categories'].append(xaxisObj)

    if 'sEcho' not in opsDict:
        # Create the input for highcharts heatmap plugin
        for i,molec in enumerate(largusArrayus):

            #if molec['sortedby'] not in returnDict['ycats']:
            if molec['sortbyme']!=None:
                returnDict['ycats'].append(molec['sortedby'])

            # This is per compound, fool! You need a complete list of columns for all taxonomies!

            inc=0


            for j,anassay in enumerate(myassays):

                for k,myorg in enumerate(myorganisms):



                    pointDict={}
                    pointDict['row']=i
                    pointDict['col']=inc
                    pointDict['chemblid']=molec['chemblid']
                    pointDict['molregno']=molec['molregno']

                    if anassay+' '+myorg not in returnDict['xcats']:
                        returnDict['xcats'].append(anassay+' '+myorg)

                    if anassay in molec and myorg in molec[anassay]:
                        pointDict['y']=molec[anassay][myorg]['score']

                    else:
                        pointDict['y']=-1

                    returnDict['data'].append(pointDict)

                    inc=inc+1




        #For the Highcharts map extension, we need to supply {row col val data} and category lists for x,y


    if export==False:
        return returnDict
    else:
        return parseExport(opsDict,largusArrayus,'invivomatrix')




def getSimSubCTAB(ctab,simsubval,session):
    '''Get a set of molecules via a similarity or substructure search. Results go into session temporary table, returns SDF file.'''

    sessionid=session.get_csrf_token()

    clearHitsTable(sessionid)

    try:
        if int(ctab)==0:
            return
        else:
            pass
    except:
        pass

    # If simubval == 100 then we're performing a substructure. A full molecule will return it's exact match anyway, unless we want superstructure searching...
    returnregnos=[]

    #try:
    #    DBSession.execute("begin execute immediate 'truncate table simsubhits'; exception when others then null; end;")
    #except:
    #    pass

    if float(simsubval) < 100:

        sql1 = "insert into simsubhits SELECT molregno,similarity(3) "
        sql2 = '"SIM"'
        sql3 = " ,'"+sessionid+"' "" FROM compound_mols cm WHERE similar(cm.CTAB, '"+ctab+"', '"+simsubval+"',3) = 1 "

        sql=sql1+sql2+sql3

    else:

        sql = "insert into simsubhits SELECT molregno, -1, '"+sessionid+"' FROM compound_mols cm WHERE sss(cm.CTAB, '"+ctab+"') = 1"

    DBSession.execute(sql)

    searchresults = DBSession.query(simsubhits).filter(simsubhits.sessionid==sessionid).all()

    #Get associated targets
    generateTargetsFromMols(session)

    fullresults = DBSession.query(simsubhits,compound_structures,molecule_dictionary.chembl_id)\
    .join(compound_structures,simsubhits.molregno==compound_structures.molregno)\
    .join(molecule_dictionary,simsubhits.molregno==molecule_dictionary.molregno)\
    .filter(simsubhits.sessionid==sessionid).all()

    mollump=""

    for m in fullresults:
        simbit,molbit,mdbit=m
        moltab = str(molbit.molfile)+'\n\n>  <similarity>\n'+str(simbit.sim)+'\n'+'\n>  <ChEMBL ID>\n'+str(mdbit)+'\n\n$$$$\n'
        mollump=mollump+moltab

    return mollump

def get_orthomatrix(taxidsin,inputTuples,session,export):
    '''
    Generate the nxn Orthologue Matrix wrt Human taxid (9606)

    Since we are sending this to datatables, ideally we need an array of objects with nested species.

    '''

    #target = targetreturn()

    mychemworker = chemworker()

    modeldict= mychemworker.getmodelinfo('bnb_fp')

    try:
        learnedtargets = modeldict['classes']
    except:
        learnedtargets = []

    data = {}
    mapping = {}
    returnObj = {}
    source = {}
    returnArray = []
    opsDict={}
    sourceselection=[1,2,3,4]
    classselection=[1,2,3,4,5]
    unmatchedTargets=[]
    inmodelonly='false'
    sortingDirection = 'asc'
    sortingColumn='geneid'
    # Check to see if we have a set of targets or compounds from a search.

    deleteAfter=False

    if 'hittids' in session:
        if type(session['hittids']) is list:
            unmatchedTargets = session['hittids'][:]

    for tup in inputTuples.items():

        opsDict[tup[0]]=tup[1]

    if 'sEcho' in opsDict:
        #Do we have a call from datatables?
        returnObj['sEcho']=int(opsDict['sEcho'])
        mstart = int(opsDict['iDisplayStart'])
        mstop = mstart+int(opsDict['iDisplayLength'])

        sortingColumn = opsDict['mDataProp_'+opsDict['iSortCol_0']]
        sortingDirection = opsDict['sSortDir_0']
        sourceselection = opsDict['source'].split(',')
        classselection = opsDict['class'].split(',')
        inmodelonly = opsDict['inmodel']

        try:
            sourceselection = [int(numeric_string) for numeric_string in sourceselection]
        except:
            sourceselection = [100]

        try:
            classselection = [int(numeric_string) for numeric_string in classselection]
        except:
            classselection = [100]

        #sortingSQL = sortingColumn+' '+sortingDirection

    taxids=taxidsin.split(',')
    taxidsin=taxidsin.split(',')


    # Cast to numbers
    taxids = [int(numeric_string) for numeric_string in taxids]

    ## Remove human taxid from taxids in
    #if '9606' in taxidsin:
    #    taxidsin.remove('9606')

    taxidsin=",".join(taxidsin)


    # Generate filter SQL
    orArray=[]
    sortSQL=''

    if 'filter' in opsDict and opsDict['filter'].__len__()>1:
        for columnName in ['NAME','FULL_NAME','FUNCTION','GENE_NAME','CHEMBL_TARGET_COMPONENT_ID','ENSEMBL_GENE_ID','ENSEMBL_PEPTIDE_ID']:
            orArray.append("regexp_like(TARGET_TO."+columnName+", '"+opsDict['filter']+"', 'i')")
            orArray.append("regexp_like(TARGET_FROM."+columnName+", '"+opsDict['filter']+"', 'i')")

        sortSQL = ' and ('+" or ".join(orArray)+')'


    #rows = DBSession.execute('SELECT me.ID,me.TARGET_ID_FROM,me.TARGET_ID_TO,me.HOMOLOGY_DESCRIPTION,me.HOMOLOGY_SUBTYPE,nvl(me.PROTEIN_IDENTITY,me.PROTEIN_IDENTITY_MATCHER) as PROTEIN_IDENTITY,target_from.ID,target_from.NAME,target_from.FULL_NAME,target_from.CHEMBL_TARGET_COMPONENT_ID,target_from.ENSEMBL_GENE_ID,target_from.ENSEMBL_PEPTIDE_ID,target_from.UNIPROT_ACCESSION,target_from.FUNCTION,target_from.TAXID,target_from.GENE_NAME,target_from.TARGET_CLASSIFICATION_ID,target_from.TARGET_ADME_CLASS_ID,target_to.ID,target_to.NAME,target_to.FULL_NAME,target_to.CHEMBL_TARGET_COMPONENT_ID,target_to.ENSEMBL_GENE_ID,target_to.ENSEMBL_PEPTIDE_ID,target_to.UNIPROT_ACCESSION,target_to.FUNCTION,target_to.TAXID,target_to.GENE_NAME,target_to.TARGET_CLASSIFICATION_ID AS source_id,target_to.TARGET_ADME_CLASS_ID,clusters.ID,clusters.TARGET_ID_FROM,clusters.TARGET_ID_TO,clusters.CLUSTER_ID,variation.TARGET_ID,variation.SNP_COUNT AS snp_count_to,variationr.SNP_COUNT AS snp_count_from,target_source.TARGET_SRC_TYPE_ID FROM orthologue_mapping me INNER JOIN target target_from ON target_from.ID = me.TARGET_ID_FROM INNER JOIN target target_to ON target_to.ID = me.TARGET_ID_TO INNER JOIN target_clusters clusters ON clusters.TARGET_ID_FROM = me.TARGET_ID_FROM AND clusters.TARGET_ID_TO  = me.TARGET_ID_TO LEFT JOIN target_variation_counts variation ON variation.TARGET_ID = me.TARGET_ID_TO LEFT JOIN target_variation_counts variationr ON variationr.TARGET_ID = me.TARGET_ID_FROM LEFT JOIN target_source ON (target_source.TARGET_ID = me.TARGET_ID_FROM) WHERE target_from.TAXID = 9606 and target_to.taxid in ('+taxidsin+') '+sortSQL) #order by target_from.id

    #rows = DBSession.execute('SELECT me.ID,me.TARGET_ID_FROM,me.TARGET_ID_TO,me.HOMOLOGY_DESCRIPTION,me.HOMOLOGY_SUBTYPE,nvl(me.PROTEIN_IDENTITY,me.PROTEIN_IDENTITY_MATCHER) as PROTEIN_IDENTITY,target_from.ID,target_from.NAME,target_from.FULL_NAME,target_from.CHEMBL_TARGET_COMPONENT_ID,target_from.ENSEMBL_GENE_ID,target_from.ENSEMBL_PEPTIDE_ID,target_from.UNIPROT_ACCESSION,target_from.FUNCTION,target_from.TAXID,target_from.GENE_NAME,target_from.TARGET_CLASSIFICATION_ID,target_from.TARGET_ADME_CLASS_ID,target_to.ID,target_to.NAME,target_to.FULL_NAME,target_to.CHEMBL_TARGET_COMPONENT_ID,target_to.ENSEMBL_GENE_ID,target_to.ENSEMBL_PEPTIDE_ID,target_to.UNIPROT_ACCESSION,target_to.FUNCTION,target_to.TAXID,target_to.GENE_NAME,target_to.TARGET_CLASSIFICATION_ID AS source_id,target_to.TARGET_ADME_CLASS_ID,clusters.ID,clusters.TARGET_ID_FROM,clusters.TARGET_ID_TO,clusters.CLUSTER_ID,variation.TARGET_ID,variation.SNP_COUNT AS snp_count_to,variationr.SNP_COUNT AS snp_count_from,target_source.TARGET_SRC_TYPE_ID, c2u1.chembl_id AS chembl_id_from,c2u2.chembl_id AS chembl_id_to FROM orthologue_mapping me INNER JOIN target target_from ON target_from.ID = me.TARGET_ID_FROM INNER JOIN target target_to ON target_to.ID = me.TARGET_ID_TO INNER JOIN target_clusters clusters ON clusters.TARGET_ID_FROM = me.TARGET_ID_FROM AND clusters.TARGET_ID_TO  = me.TARGET_ID_TO LEFT JOIN target_variation_counts variation ON variation.TARGET_ID = me.TARGET_ID_TO LEFT JOIN target_variation_counts variationr ON variationr.TARGET_ID = me.TARGET_ID_FROM LEFT JOIN target_source ON (target_source.TARGET_ID = me.TARGET_ID_FROM) left  JOIN chembl_2_uniprot c2u1 ON(target_from.chembl_target_component_id = c2u1.component_id) left  JOIN chembl_2_uniprot c2u2 ON(target_to.chembl_target_component_id = c2u2.component_id) WHERE target_from.TAXID = 9606 and target_to.taxid in ('+taxidsin+') and c2u2.primary=1 '+sortSQL) #order by target_from.id


    rows =           DBSession.execute('select  \
                                        ME_ID,   \
                                        TARGET_ID_FROM,\
                                        TARGET_ID_TO, \
                                        HOMOLOGY_DESCRIPTION,\
                                        HOMOLOGY_SUBTYPE,\
                                        PROTEIN_IDENTITY,\
                                        ID_1,\
                                        NAME_1,\
                                        FULL_NAME_1,\
                                        CHEMBL_TARGET_COMPONENT_ID_1,\
                                        ENSEMBL_GENE_ID_1,\
                                        ENSEMBL_PEPTIDE_ID_1,\
                                        UNIPROT_ACCESSION_1,\
                                        FUNCTION_1,\
                                        TAXID_1,\
                                        GENE_NAME_1,\
                                        TARGET_CLASSIFICATION_ID_1,\
                                        TARGET_ADME_CLASS_ID_1,\
                                        ID_2,\
                                        NAME_2,\
                                        FULL_NAME_2,\
                                        CHEMBL_TARGET_COMPONENT_ID_2,\
                                        ENSEMBL_GENE_ID_2,\
                                        ENSEMBL_PEPTIDE_ID_2,\
                                        UNIPROT_ACCESSION_2,\
                                        FUNCTION_2,\
                                        TAXID_2,\
                                        GENE_NAME_2,\
                                        TARGET_CLASSIFICATION_ID_2,\
                                        TARGET_ADME_CLASS_ID_2,\
                                        cid,\
                                        cluster_TARGET_ID_FROM,\
                                        cluster_TARGET_ID_TO ,\
                                        CLUSTER_ID,\
                                        TARGET_ID,\
                                        snp_count_to,\
                                        snp_count_from,\
                                        TARGET_SRC_TYPE_ID,\
                                        wm_concat(distinct c2u1.chembl_id) as chembl_ids_1, \
                                        wm_concat(distinct c2u2.chembl_id) as chembl_ids_2\
                                        from(\
                                        SELECT me.ID as ME_ID,\
                                          me.TARGET_ID_FROM,\
                                          me.TARGET_ID_TO,\
                                          me.HOMOLOGY_DESCRIPTION,\
                                          me.HOMOLOGY_SUBTYPE,\
                                          NVL(me.PROTEIN_IDENTITY, me.PROTEIN_IDENTITY_MATCHER) AS PROTEIN_IDENTITY,\
                                          target_from.ID as ID_1,\
                                          target_from.NAME as NAME_1,\
                                          target_from.FULL_NAME as FULL_NAME_1,\
                                          target_from.CHEMBL_TARGET_COMPONENT_ID as CHEMBL_TARGET_COMPONENT_ID_1,\
                                          target_from.ENSEMBL_GENE_ID as ENSEMBL_GENE_ID_1,\
                                          target_from.ENSEMBL_PEPTIDE_ID as ENSEMBL_PEPTIDE_ID_1,\
                                          target_from.UNIPROT_ACCESSION as UNIPROT_ACCESSION_1,\
                                          target_from.FUNCTION as FUNCTION_1,\
                                          target_from.TAXID as TAXID_1,\
                                          target_from.GENE_NAME as GENE_NAME_1,\
                                          target_from.TARGET_CLASSIFICATION_ID as TARGET_CLASSIFICATION_ID_1,\
                                          target_from.TARGET_ADME_CLASS_ID as TARGET_ADME_CLASS_ID_1,\
                                          target_to.ID as ID_2,\
                                          target_to.NAME as NAME_2,\
                                          target_to.FULL_NAME as FULL_NAME_2,\
                                          target_to.CHEMBL_TARGET_COMPONENT_ID as CHEMBL_TARGET_COMPONENT_ID_2,\
                                          target_to.ENSEMBL_GENE_ID as ENSEMBL_GENE_ID_2,\
                                          target_to.ENSEMBL_PEPTIDE_ID as ENSEMBL_PEPTIDE_ID_2,\
                                          target_to.UNIPROT_ACCESSION as UNIPROT_ACCESSION_2,\
                                          target_to.FUNCTION as FUNCTION_2,\
                                          target_to.TAXID as TAXID_2,\
                                          target_to.GENE_NAME as GENE_NAME_2,\
                                          target_to.TARGET_CLASSIFICATION_ID AS TARGET_CLASSIFICATION_ID_2,\
                                          target_to.TARGET_ADME_CLASS_ID as TARGET_ADME_CLASS_ID_2,\
                                          clusters.ID as cid,\
                                          clusters.TARGET_ID_FROM as cluster_TARGET_ID_FROM,\
                                          clusters.TARGET_ID_TO as cluster_TARGET_ID_TO ,\
                                          clusters.CLUSTER_ID,\
                                          variation.TARGET_ID,\
                                          variation.SNP_COUNT  AS snp_count_to,\
                                          variationr.SNP_COUNT AS snp_count_from,\
                                          target_source.TARGET_SRC_TYPE_ID\
                                        FROM orthologue_mapping me\
                                        INNER JOIN target target_from\
                                        ON target_from.ID = me.TARGET_ID_FROM\
                                        INNER JOIN target target_to\
                                        ON target_to.ID = me.TARGET_ID_TO\
                                        INNER JOIN target_clusters clusters\
                                        ON clusters.TARGET_ID_FROM = me.TARGET_ID_FROM\
                                        AND clusters.TARGET_ID_TO  = me.TARGET_ID_TO\
                                        LEFT JOIN target_variation_counts variation\
                                        ON variation.TARGET_ID = me.TARGET_ID_TO\
                                        LEFT JOIN target_variation_counts variationr\
                                        ON variationr.TARGET_ID = me.TARGET_ID_FROM\
                                        LEFT JOIN target_source\
                                        ON (target_source.TARGET_ID = me.TARGET_ID_FROM)\
                                        WHERE target_from.TAXID     = 9606\
                                        AND target_to.taxid in ('+taxidsin+')'+sortSQL+') big_table ,\
                                        chembl_2_uniprot c2u1,\
                                        chembl_2_uniprot c2u2\
                                        where c2u1.component_id(+) = big_table.chembl_target_component_id_1\
                                        and c2u2.component_id(+) = big_table.chembl_target_component_id_2\
                                        group by \
                                        ME_ID,\
                                        TARGET_ID_FROM,\
                                        TARGET_ID_TO,\
                                        HOMOLOGY_DESCRIPTION,\
                                        HOMOLOGY_SUBTYPE,\
                                        PROTEIN_IDENTITY,\
                                        ID_1,\
                                        NAME_1,\
                                        FULL_NAME_1,\
                                        CHEMBL_TARGET_COMPONENT_ID_1,\
                                        ENSEMBL_GENE_ID_1,\
                                        ENSEMBL_PEPTIDE_ID_1,\
                                        UNIPROT_ACCESSION_1,\
                                        FUNCTION_1,\
                                        TAXID_1,\
                                        GENE_NAME_1,\
                                        TARGET_CLASSIFICATION_ID_1,\
                                        TARGET_ADME_CLASS_ID_1,\
                                        ID_2,\
                                        NAME_2,\
                                        FULL_NAME_2,\
                                        CHEMBL_TARGET_COMPONENT_ID_2,\
                                        ENSEMBL_GENE_ID_2,\
                                        ENSEMBL_PEPTIDE_ID_2,\
                                        UNIPROT_ACCESSION_2,\
                                        FUNCTION_2,\
                                        TAXID_2,\
                                        GENE_NAME_2,\
                                        TARGET_CLASSIFICATION_ID_2,\
                                        TARGET_ADME_CLASS_ID_2,\
                                        cid,\
                                        cluster_TARGET_ID_FROM,\
                                        cluster_TARGET_ID_TO ,\
                                        CLUSTER_ID,TARGET_ID,\
                                        snp_count_to,\
                                        snp_count_from,\
                                        TARGET_SRC_TYPE_ID ')

    foundcount=0

    for row in rows:

        #me_id, me_target_id_from, me_target_id_to, me_homology_description, me_homology_subtype, me_protein_identity, target_from_id, target_from_name, target_from_full_name, target_from_chembl_target_id, target_from_ensembl_gene_id, target_from_ensembl_peptide_id, target_from_uniprot_accesion, target_from_function, target_from_taxid, target_from_gene_name, target_from_target_classification_id, target_from_adme_class_id, target_to_id, target_to_name, target_to_full_name, target_to_chembl_target_id, target_to_ensembl_gene_id, target_to_ensembl_peptide_id, target_to_uniprot_accesion, target_to_function, target_to_taxid, target_to_gene_name, target_to_target_classification_id, target_to_adme_class_id, clusters_id, clusters_target_id_from, clusters_target_id_to, clusters_cluster_id, variation_target_id, variation_snp_count_to, variation_snp_count_from, target_source_target_src_type_id = row

        me_id,me_target_id_from,me_target_id_to,me_homology_description,me_homology_subtype,me_protein_identity,target_from_id,target_from_name,target_from_full_name,target_from_chembl_target_id,target_from_ensembl_gene_id,target_from_ensembl_peptide_id,target_from_uniprot_accesion,target_from_function,target_from_taxid,target_from_gene_name,target_from_target_classification_id,target_from_adme_class_id,target_to_id,target_to_name,target_to_full_name,target_to_chembl_target_id,target_to_ensembl_gene_id,target_to_ensembl_peptide_id,target_to_uniprot_accesion,target_to_function,target_to_taxid,target_to_gene_name,target_to_target_classification_id,target_to_adme_class_id,clusters_id,clusters_target_id_from,clusters_target_id_to,clusters_cluster_id,variation_target_id,variation_snp_count_to,variation_snp_count_from,target_source_target_src_type_id,chembl_tid_from,chembl_tid_to = row


        target_to_in_model=0
        target_from_in_model=0

        citf=chembl_tid_from
        citt=chembl_tid_to



        if citf is not None:
            citf=chembl_tid_from.split(',')
            for ctid in citf:
                if ctid in learnedtargets:
                    target_from_in_model=1


        if citt is not None:
            citt=chembl_tid_to.split(',')
            for ctid in citt:
                if ctid in learnedtargets:
                    target_to_in_model=1


        # String cleanup for GSK names
        target_to_name = cleanGSKnames(target_to_name,target_to_taxid)


        if target_from_id not in data:
            root={}
            root['target_id']=target_from_id
            root['name_from']=target_from_name
            root['name_to']=target_from_name
            root['gene']=target_from_gene_name
            root['ensembl']=target_from_ensembl_gene_id
            root['uniprot']=target_from_uniprot_accesion
            root['cluster']=clusters_cluster_id,
            root['snp_count']= variation_snp_count_from
            root['taxid']=target_from_taxid
            root['full_name']=target_from_full_name
            root['function']=target_from_function
            root['source']=target_source_target_src_type_id
            root['adme_class_id']=target_to_adme_class_id
            root['chembl_target_id']=target_from_chembl_target_id
            root['inmodel']=target_from_in_model
            root['mapping']={}

            if 'hittids' in session:

                if type(session['hittids']) is list:

                    if target_from_id in session['hittids']:
                        #Remove from our target copy
                        if target_to_id in unmatchedTargets:
                            unmatchedTargets.remove(target_to_id)

                        root['hit']=-1
                    else:
                        root['miss']=-1



                if type(session['hittids']) is dict:
                    if target_from_id in session['hittids'].keys():
                        root['hit']=session['hittids'][target_from_id]
                    else:
                        root['miss']=1



            data[target_from_id]=root




        if target_to_taxid not in data[target_from_id]['mapping']:

            #First time we're seeing this mapping. Create the array
            data[target_from_id]['mapping'][target_to_taxid]=[]


        mappingObj={}

        mappingObj['name_from']=target_from_name
        mappingObj['target_id']=target_to_id
        mappingObj['name_to']=target_to_name
        mappingObj['gene']=target_to_gene_name
        mappingObj['ensembl']=target_to_ensembl_gene_id
        mappingObj['uniprot']=target_to_uniprot_accesion
        mappingObj['desc']=me_homology_description
        mappingObj['subtype']=me_homology_subtype
        mappingObj['inmodel']=target_to_in_model

        if me_protein_identity==None:
            mappingObj['identity']='false'
        else:
            mappingObj['identity']=me_protein_identity

        mappingObj['taxid']=target_to_taxid
        mappingObj['cluster']=clusters_cluster_id
        mappingObj['snp_count']=variation_snp_count_to
        mappingObj['full_name']=target_to_full_name
        mappingObj['function']=target_to_function
        mappingObj['source']=target_source_target_src_type_id
        mappingObj['adme_class_id']=target_from_adme_class_id
        mappingObj['chembl_target_id']=target_to_chembl_target_id

        if 'hittids' in session:

            if type(session['hittids']) is list:

                # We have a list of targets (from a model prediciton)
                if target_to_id in session['hittids']:

                    #Remove from our target copy
                    if target_to_id in unmatchedTargets:
                        unmatchedTargets.remove(target_to_id)

                    mappingObj['hit']=-1
                else:
                    mappingObj['miss']=-2

            # We have a dict of targets (from a BLAST search)
            if type(session['hittids']) is dict:

                if target_to_id in session['hittids'].keys():
                    mappingObj['hit']=session['hittids'][target_to_id]

        data[target_from_id]['mapping'][target_to_taxid].append(mappingObj)

        rootCopy = copy.deepcopy(data[target_from_id])

        del rootCopy['mapping']



        data[target_from_id]['mapping'][9606]=[rootCopy]
        data[target_from_id]['mapping'][9606][0]['cluster']=data[target_from_id]['mapping'][9606][0]['cluster'][0] # For some reason, deep copy puts the cluster id into a tuple



    targetSet = data.items()

    targetSetFilter=[]


    # Filter targets from GUI drop-downs
    for target in targetSet:

        appendFlag=1

        if int(target[1]['source']) in sourceselection:
            pass
        else:
            appendFlag=appendFlag * 0

        if int(target[1]['adme_class_id']) in classselection:
            pass
        else:
            appendFlag=appendFlag * 0

        if inmodelonly=='true':
            if int(target[1]['inmodel'])==1:
                pass
            else:
                appendFlag=appendFlag * 0

        if appendFlag>0:
            targetSetFilter.append(target)

    targetSet = targetSetFilter



    if sortingDirection == 'asc':
        direction=False
    else:
        direction=True

    if sortingColumn=='geneid' or sortingColumn.isdigit():
        sortingColumn='gene'



    targetSet.sort(key=lambda x: x[1][sortingColumn], reverse=direction)

    returnObj['iTotalRecords']=targetSet.__len__()


    if 'hittids' in session:
        pass
    else:
        if 'mstart' in locals() and export==False:
            # Slice targetset here, from incoming table params.

            targetSet = targetSet[mstart:mstop]

    # Now looping over list of human targets.
    for targety in targetSet:
        target_id = targety[0]

        data = targety[1]


        data['mapping']['source']=data['mapping'][9606][0]['source']

        #print "**************************************"
        #print data['mapping'][9606][0]
        #print "**************************************"
        #
        data['mapping']['geneid']=data['mapping'][9606][0]['name_to'][:3] #Take the first 3 characters from the gene id as Gene group.
        data['mapping']['adme_class_id']=data['mapping'][9606][0]['adme_class_id']
        data['mapping']['target_id']=data['mapping'][9606][0]['target_id']
        if data['mapping'][9606][0]['function'] == None:
            data['mapping']['function']=""
        else:
            data['mapping']['function']='"'+str(data['mapping'][9606][0]['function'])+'"'

        for taxid in taxids:
        # If there's no mapping, add in a blank, otherwise datatables complains!
            if taxid not in data['mapping']:
                data['mapping'][taxid]={}

            if 'hittids' in session:
                for element in data['mapping'][taxid]:
                    if 'hit' in element:
                        if data['mapping'] not in returnArray:
                            returnArray.append(data['mapping'])

                if 'mstart' in locals():
                    targetSet = targetSet[mstart:mstop]

        if 'hittids' in session:
            pass
        else:
            returnArray.append(data['mapping'])


    returnObj['aaData']=returnArray

    if 'hittids' in session:
        returnObj['iTotalDisplayRecords']=returnArray.__len__()
        if unmatchedTargets.__len__()>0 and type(unmatchedTargets)==list:

            for unmatch in unmatchedTargets:
                returnObj['additional']=get_target(unmatch)


    else:
        returnObj['iTotalDisplayRecords']=returnObj['iTotalRecords']

    if export==False:
        if 'sEcho' in opsDict:
            return returnObj
        else:
            return {'orthologue_matrix':returnArray}
    else:
        return parseExport(opsDict,returnObj['aaData'],'orthomatrix')

def get_expression_matrix(tissueset,inputTuples,session,export):
    '''Return a list of human targets and corresponding tissue expression levels for the input tissues
    '''
    opsDict={}
    returnObj={}
    sortingDirection='asc'
    sortingColumn='gene_id'

    for tup in inputTuples.items():

        opsDict[tup[0]]=tup[1]

    if 'sEcho' in opsDict:
        #Do we have a call from datatables?
        returnObj['sEcho']=int(opsDict['sEcho'])
        mstart = int(opsDict['iDisplayStart'])
        mstop = mstart+int(opsDict['iDisplayLength'])

        sortingColumn = opsDict['mDataProp_'+opsDict['iSortCol_0']]
        sortingDirection = opsDict['sSortDir_0']

    tissueset=tissueset.split(',')
    tissueiter = map(int, tissueset)

    for tissue in tissueset:
        tissue = "'"+tissue+"'"

    tissueset=",".join(tissueset)

    # Generate filter SQL
    orArray=[]
    sortSQL=''

    if 'filter' in opsDict and opsDict['filter'].__len__()>1:

        for columnName in ['RELIABILITY','EXPRESSION_TYPE','EXP_LEVEL','GENE']:
            orArray.append("regexp_like(PROTEIN_ATLAS_EXPRESSION."+columnName+", '"+opsDict['filter']+"', 'i')")

        for columnName in ['FULL_NAME','NAME','ENSEMBL_GENE_ID','GENE_NAME','CHEMBL_TARGET_COMPONENT_ID','FUNCTION']:
            orArray.append("regexp_like(TARGET."+columnName+", '"+opsDict['filter']+"', 'i')")

        sortSQL = ' and ('+" or ".join(orArray)+')'

    rows = DBSession.execute("SELECT PROTEIN_ATLAS_EXPRESSION.GENE,PROTEIN_ATLAS_EXPRESSION.EXP_LEVEL,PROTEIN_ATLAS_EXPRESSION.EXPRESSION_TYPE,PROTEIN_ATLAS_EXPRESSION.RELIABILITY,TARGET.ID AS TARGET_ID,EXPRESSION_TISSUE.ID AS TISSUE_ID,PROTEIN_ATLAS_EXPRESSION.TISSUE, EXPRESSION_CELL_TYPE.ID AS CELL_ID,TARGET.FULL_NAME,TARGET.NAME,TARGET.FUNCTION FROM PROTEIN_ATLAS_EXPRESSION INNER JOIN TARGET ON PROTEIN_ATLAS_EXPRESSION.GENE = TARGET.ENSEMBL_GENE_ID INNER JOIN EXPRESSION_TISSUE ON PROTEIN_ATLAS_EXPRESSION.TISSUE = EXPRESSION_TISSUE.TISSUE INNER JOIN EXPRESSION_CELL_TYPE ON PROTEIN_ATLAS_EXPRESSION.CELL_TYPE = EXPRESSION_CELL_TYPE.CELL_TYPE WHERE EXPRESSION_TISSUE.ID in ("+tissueset+") "+sortSQL)

    dataObj={}
    returnArray=[]
    targets=set()

    for row in rows:

        gene_id,exp_level,expression_type,reliability,target_id,tissue_id,tissue,cell_type,full_name,name,function = row

        targets.add(target_id)

        if target_id not in dataObj:
            dataObj[target_id]={}


        if tissue_id not in dataObj[target_id]:
            dataObj[target_id][tissue_id]={}

        for t in tissueiter:
            if t not in dataObj[target_id]:
                dataObj[target_id][t]={}

        if cell_type not in dataObj[target_id][tissue_id]:
            dataObj[target_id][tissue_id][cell_type]={}

        dataObj[target_id][tissue_id][cell_type]['expression_type']=expression_type
        dataObj[target_id][tissue_id][cell_type]['reliability']=reliability
        dataObj[target_id][tissue_id][cell_type]['exp_level']=exp_level
        dataObj[target_id][tissue_id][cell_type]['target_id']=target_id
        dataObj[target_id][tissue_id][cell_type]['gene_id']=gene_id

        dataObj[target_id]['gene_id']={}
        dataObj[target_id]['gene_id']['name']=name[:3]
        dataObj[target_id]['gene_id']['gene']=gene_id
        dataObj[target_id]['gene_id']['tid']=target_id
        dataObj[target_id]['gene_id']['fullname']=full_name
        dataObj[target_id]['gene_id']['function']=function
        #dataObj[target_id]['description']={}
        #dataObj[target_id]['description']['fullname']=full_name
        #dataObj[target_id]['description']['name']=name

        dataObj[target_id][tissue_id][cell_type]['full_name']=full_name
        dataObj[target_id][tissue_id][cell_type]['tissue']="+".join(tissue.split(' '))
        dataObj[target_id][tissue_id][cell_type]['name']=name



    returnObj['iTotalRecords']=targets.__len__()

    if 'hittids' in session:

        if type(session['hittids']) is list:

                for hittid in session['hittids']:
                    try:
                        returnArray.append(dataObj[hittid])
                    except Exception:
                        pass


        if type(session['hittids']) is dict:

                for hittid in session['hittids'].keys():
                    try:
                        returnArray.append(dataObj[hittid])
                    except Exception:
                        pass

    else:

        for tid in list(targets):
            returnArray.append(dataObj[tid])




    if sortingDirection == 'asc':
        direction=False
    else:
        direction=True

    returnArray.sort(key=lambda x: x['gene_id']['name'], reverse=direction)





    if 'filter' in opsDict:
        returnObj['iTotalDisplayRecords']=returnArray.__len__()
    else:
        returnObj['iTotalDisplayRecords']=returnObj['iTotalRecords']

    if export==False:
        if 'sEcho' in opsDict:
            returnObj['aaData'] = returnArray[mstart:mstop]
            return returnObj
        else:
            return {'expression_matrix':returnArray}
    else:
        return parseExport(opsDict,returnArray,'tissuematrix');

def get_target(tid):
    ''' Return the target data '''
    try:

        targetObj1,targetObj2 = DBSession.query(target,chembl_2_uniprot).join(chembl_2_uniprot,target.chembl_target_component_id==chembl_2_uniprot.component_id).filter(target.id==tid).first()

        holder = []
        targetObj1=dumprow(targetObj1).items()
        targetObj2=dumprow(targetObj2).items()

        holder.append(dict(targetObj1+targetObj2))


        return holder
    except:
        # With no chembl_component_id just pull back the target information
        targetObj1 = DBSession.query(target).filter(target.id==tid).first()

        holder = []
        targetObj1=dumprow(targetObj1).items()
        holder.append(dict(targetObj1))

        return holder



def get_targets(targets):

    returnarray=[]

    for singular in targets:

            if 'PROTEIN_ACCESSION' in singular:
                singular['target_id'] = accession_to_target_id(singular['PROTEIN_ACCESSION'])
                target_data = get_target(singular['target_id']).pop()
                targetfull=dict(singular.items() + target_data.items())

                returnarray.append(targetfull)

    return returnarray

def gettargbioactivity(astid):

    returnArray=[]

    activaytae = DBSession.query(activities, assays, docs,molecule_dictionary,target_dictionary,chembl_2_uniprot,target) \
                .join(assays,activities.assay_id==assays.assay_id) \
                .join(docs,assays.doc_id==docs.doc_id) \
                .filter(molecule_dictionary.molregno==activities.molregno) \
                .filter(target_dictionary.tid==assays.tid) \
                .distinct(activities.activity_id) \
                .filter(chembl_2_uniprot.tid==assays.tid) \
                .filter(chembl_2_uniprot.component_id==target.chembl_target_component_id) \
                .filter(target.id==astid)


    requiredprops=['standard_type','standard_relation','standard_value','standard_units','activity_comment','assay_type','description','name']

    for act in activaytae:
        actObj1, actObj2, actObj3,actObj4,actObj5,actObj6,actObj7 = act

        actObj1 = dumprow(actObj1)
        actObj2 = dumprow(actObj2)
        actObj3 = dumprow(actObj3)
        actObj4 = dumprow(actObj4)
        actObj5 = dumprow(actObj5)
        actObj6 = dumprow(actObj6)
        actObj7 = dumprow(actObj7)


        #if 'updated_on' in actObj1:
        #    del actObj1['updated_on']
        #
        #if 'updated_on' in actObj2:
        #    del actObj2['updated_on']
        #
        #if 'insert_date' in actObj4:
        #    del actObj4['insert_date']
        #
        #if 'molfile_update' in actObj4:
        #    del actObj4['molfile_update']

        #actObj3['insert_date']=int(mktime(actObj3['insert_date'].timetuple()))
        #actObj3['molfile_update']=int(mktime(actObj3['molfile_update'].timetuple()))


        allprops = dict(actObj1.items()+actObj2.items()+actObj3.items()+actObj4.items()+actObj5.items()+actObj6.items()+actObj7.items())
        singledict={}
        for req in requiredprops:
            singledict[req]=allprops[req]

        returnArray.append(singledict)




    return {'results':returnArray}

def gettargetcompounds(astid):
    '''
    SELECT DISTINCT COMPOUND_STRUCTURES.CANONICAL_SMILES,
      MOLECULE_DICTIONARY.CHEMBL_ID
    FROM ACTIVITIES,
      COMPOUND_STRUCTURES,
      TARGET,
      CHEMBL_2_UNIPROT,
      ASSAYS,
      MOLECULE_DICTIONARY
    WHERE TARGET.CHEMBL_TARGET_COMPONENT_ID = CHEMBL_2_UNIPROT.COMPONENT_ID
    AND ACTIVITIES.MOLREGNO                 = COMPOUND_STRUCTURES.MOLREGNO
    AND ASSAYS.ASSAY_ID                     = ACTIVITIES.ASSAY_ID
    AND ASSAYS.TID                          = CHEMBL_2_UNIPROT.TID
    AND COMPOUND_STRUCTURES.MOLREGNO        = MOLECULE_DICTIONARY.MOLREGNO
    AND (TARGET.ID                          = 5368)
    '''
    returnArray=[]

    targetcompounds = DBSession.query(compound_structures.canonical_smiles,molecule_dictionary.chembl_id) \
                .distinct(compound_structures.canonical_smiles) \
                .filter(target.chembl_target_component_id==chembl_2_uniprot.component_id) \
                .filter(activities.molregno==compound_structures.molregno) \
                .filter(assays.assay_id==activities.assay_id) \
                .filter(assays.tid==chembl_2_uniprot.tid) \
                .filter(compound_structures.molregno==molecule_dictionary.molregno) \
                .filter(target.id==astid)

    for cmpdobj in targetcompounds:
        cs,ci = cmpdobj
        moldict={}
        moldict[ci]=cs
        returnArray.append(moldict)

    return {'results':returnArray}

def getBiodata(molregno,inputTuples,session,export):
    '''Pull back assay results for a particular MOLREGNO'''

    molregno=int(molregno)

    returnObj = {}
    returnacts=[]
    opsDict={}
    hitscount=0

    simsubcount = DBSession.query(simsubhits).filter(simsubhits.sessionid==session.get_csrf_token()).count()

    for tup in inputTuples.items():

        opsDict[tup[0]]=tup[1]

    if 'hittids' in session and session['hitsource']=='model' or 'hittids' in session and session['hitsource']=='text':
        # This will control targets/mol hits.
        hittype=False # Not strictly, since it's from a target search

    elif 'hittids' in session and session['hitsource']=='simsub':

        hittype='mols'

    else:

        hittype=True


    if 'sEcho' in opsDict:
        #Do we have a call from datatables?
        returnObj['sEcho']=int(opsDict['sEcho'])
        mstart = int(opsDict['iDisplayStart'])
        mstop = mstart+int(opsDict['iDisplayLength'])

        sortingColumn = opsDict['mDataProp_'+opsDict['iSortCol_0']]
        
        # Don't sort on the image column!
        if sortingColumn == 'molregno':
            sortingColumn = 'activities.activity_id'

        if sortingColumn == 'target_pref_name':
            sortingColumn = 'target_dictionary.pref_name'

        sortingDirection = opsDict['sSortDir_0']
        sortingSQL = sortingColumn+' '+sortingDirection+' nulls last'


        if hittype==False:
            activaytae = DBSession.query(activities, assays, docs,molecule_dictionary,target_dictionary,chembl_2_uniprot,target)
        elif hittype==True:
            activaytae = DBSession.query(activities, assays, docs,molecule_dictionary,target_dictionary)
        elif hittype=='mols':
            activaytae = DBSession.query(activities, assays, docs,molecule_dictionary,target_dictionary,simsubhits) \
            .filter(molecule_dictionary.molregno==simsubhits.molregno) \
            .filter(simsubhits.sessionid==session.get_csrf_token())

        activaytae = activaytae\
        .join(assays,activities.assay_id==assays.assay_id) \
        .join(docs,assays.doc_id==docs.doc_id) \
        .filter(molecule_dictionary.molregno==activities.molregno) \
        .filter(target_dictionary.tid==assays.tid)

        if hittype==False:
            activaytae = activaytae \
            .distinct(activities.activity_id) \
            .filter(chembl_2_uniprot.tid==assays.tid) \
            .filter(chembl_2_uniprot.component_id==target.chembl_target_component_id) \
            .filter(target.id.in_(session['hittids']))


        hitscount = activaytae.count()

        # If we have a filter condtion
        if 'sSearch' in opsDict and opsDict['sSearch'].__len__() >0:

            term = opsDict['sSearch']

            if term.isdigit():
                activaytae = activaytae.filter(or_(activities.standard_value==float(term),activities.published_value==float(term)))
            else:
                activaytae = activaytae.filter(or_(assays.assay_organism.ilike('%'+term+'%'),assays.assay_source.ilike('%'+term+'%'),assays.description.ilike('%'+term+'%'),assays.chembl_id.ilike('%'+term+'%'),activities.activity_type.ilike('%'+term+'%'),activities.standard_type.ilike('%'+term+'%')))

            totalDisplayRecords = activaytae.count()

        activaytae = activaytae.order_by(sortingSQL)

        # If we have a molregno of -1, then pull back the whole of the actvities table (sliced, of course!)
        if molregno < 0:

            #activaytae=activaytae.filter(compoun)

            if export==False:
                activaytae = activaytae.slice(start=mstart,stop=mstop)

        else:
            activaytae = activaytae.filter(activities.molregno==molregno).slice(start=mstart,stop=mstop)

            hitscount = activaytae.count()

    else:
        #activaytae = DBSession.query(activities2)

        hittype=True

        activaytae = DBSession.query(activities, assays, docs,molecule_dictionary,target_dictionary) \
        .join(assays,activities.assay_id==assays.assay_id) \
        .join(docs,assays.doc_id==docs.doc_id) \
        .filter(molecule_dictionary.molregno==activities.molregno) \
        .filter(target_dictionary.tid==assays.tid)

        if molregno > 0:
            activaytae = activaytae.filter(activities.molregno==molregno)


    totalrecords = DBSession.query(activities).count()

    #if molregno < 0:
    #
    #    if 'sSearch' in opsDict and opsDict['sSearch'].__len__() >0:
    #        totalDisplayRecords = activaytae.count()
    #    else:
    #        totalDisplayRecords = totalrecords
    #else:
    ##    #totalDisplayRecords =DBSession.query(activities, assays).join(assays,activities.assay_id==assays.assay_id).filter(activities.molregno==molregno).count()
    #


    #
    for activity in activaytae:


        if hittype==False:
            actObj1, actObj2, actObj3,actObj4,actObj5,actObj6,actObj7 = activity
        elif hittype==True:
            actObj1, actObj2, actObj3,actObj4,actObj5 = activity
        elif hittype=='mols':
            actObj1, actObj2, actObj3,actObj4,actObj5,actObj6 = activity


        actObj1=dumprow(actObj1) #activities
        actObj2=dumprow(actObj2) #assays
        actObj3=dumprow(actObj3) #docs
        actObj4=dumprow(actObj4) #molecule_dict
        actObj5=dumprow(actObj5) #target_dict

        if hittype==False:
            actObj6=dumprow(actObj6) #chembl_2_uniprot
            actObj7=dumprow(actObj7) #target

        if hittype=='mols':
            actObj6=dumprow(actObj6) #simsubhits

        # Rename so we don't overwrite.
        if 'chembl_id' in actObj2:
            actObj2['assays_chembl_id']=actObj2['chembl_id']
            del actObj2['chembl_id']

        if 'chembl_id' in actObj3:
            actObj3['docs_chembl_id']=actObj3['chembl_id']
            del actObj3['chembl_id']

        if 'pref_name' in actObj5:
            actObj5['target_pref_name']=actObj5['pref_name']
            del actObj5['pref_name']

        if 'chembl_id' in actObj5:
            actObj5['target_chembl_id']=actObj5['chembl_id']
            del actObj5['chembl_id']


        if hittype==False:

            if 'chembl_id' in actObj6:

                del actObj6['chembl_id']

            actPropsDict = dict(actObj1.items() + actObj2.items()+ actObj3.items() + actObj4.items()+ actObj5.items()+ actObj6.items()+ actObj7.items())
        else:
            actPropsDict = dict(actObj1.items() + actObj2.items()+ actObj3.items() + actObj4.items()+ actObj5.items())

        del actPropsDict['assay_source']

        for dicprop in actPropsDict:

            if isinstance(actPropsDict[dicprop],datetime.datetime):
                actPropsDict[dicprop]=int(mktime(actPropsDict[dicprop].timetuple()))

        returnacts.append(actPropsDict)

    totalDisplayRecords = activaytae.count()


    if hittype==False and molregno > 1:

        returnObj['iTotalDisplayRecords']=totalDisplayRecords


    elif hittype=='mols' and molregno > 1:

        returnObj['iTotalDisplayRecords']=totalDisplayRecords

    elif hittype=='mols' and molregno < 0:


        returnObj['iTotalDisplayRecords']=hitscount

    elif hittype==True and molregno >1:


        returnObj['iTotalDisplayRecords']=totalDisplayRecords

    elif hittype==True and molregno < 0:


        returnObj['iTotalDisplayRecords']=hitscount

    else:

        returnObj['iTotalDisplayRecords']=hitscount

    returnObj['iTotalRecords']=totalrecords
    returnObj['aaData']=returnacts

    if export == False:

        if 'sEcho' in opsDict:
            return returnObj
        else:
            return returnacts
    else:
        return parseExport(opsDict,returnacts,'activitytable')



def get_target_alignment(tid,tax):
    ''' Return the target orthologue alignment data '''

    # Ideally this will accept a list of the currently displayed organisms and return only those.
    taxids = tax.split(',')
    holder = []

    snpsObj={}

    for targObj,alnObj in DBSession.query(target, target_alignment).join(target_alignment, target.id==target_alignment.target_id_to).filter(target_alignment.target_id_from==tid).filter(target.taxid.in_(taxids)).all():

        alnObj=dumprow(alnObj)
        targObj=dumprow(targObj)

        targObj['name']=cleanGSKnames(targObj['name'],targObj['taxid'])

        #Merge the dictionary contents for each record
        holder.append(dict(alnObj.items() + targObj.items()))


    for alignment in holder:

        alignment['snps']={}

        snpObj = DBSession.query(target_sequence_variation).filter(target_sequence_variation.target_id==alignment['id']).all()

        for snp in snpObj:

            snp=dumprow(snp)

            alignment['snps'][snp['aa_position']]=snp


    return holder

def get_organism(taxid):

    taxidRow = DBSession.query(taxonomy).filter(taxonomy.taxid==taxid).first()

    return taxidRow.name




def get_sequence_set(tid,tax):
    '''Return the set of orthologue fasta sequences for a particular target and itself against a set of Tax IDs'''

    holder=[]
    seqObj={}

    taxids=tax.split(',')

    seqs = get_target_alignment(tid,tax)

    for row in seqs:


        seqObj={}

        sequenceHere = get_target_sequence(row['id']).pop()

        seqObj['sequence']=sequenceHere['sequence']
        seqObj['target_id']=row['id']

        seqObj['taxon']=get_organism(row['taxid'])
        seqObj['name']=str(row['id'])+'-'+str(row['name']).upper() +'-'+str(get_organism(row['taxid']))
        seqObj['full_name']=row['full_name']

        holder.append(seqObj)

    return holder


def accession_to_target_id(inputID):

    ''' Return the Target ID for a particular accession. '''
    #acctargetObj = DBSession.query(target_xref).filter(target_xref.value==accession).first()
    #
    #
    #if type(acctargetObj) != None:
    #    return acctargetObj.target_id
    #else:
    #    return 0

    try:
        part1,part2=DBSession.query(target,chembl_2_uniprot) \
        .join(chembl_2_uniprot,target.chembl_target_component_id==chembl_2_uniprot.component_id) \
        .filter(chembl_2_uniprot.primary==1) \
        .filter(chembl_2_uniprot.chembl_id==inputID).first()

    except:
        # Can't pull from chembl_2_uniprot, so grab from target
        part1=DBSession.query(target) \
        .filter(target.uniprot_accession==inputID).first()


    if type(part1) != None:

        return part1.id

    else:

        return 0


def get_target_sequence(tid):

    holder = []

    seqObj1, seqObj2 = DBSession.query(target, target_sequence).join(target_sequence, target.id==target_sequence.target_id).filter(target_sequence.target_id==tid).first()

    seqObj1=dumprow(seqObj1)
    seqObj2=dumprow(seqObj2)

    newDict = dict(seqObj1.items() + seqObj2.items())

    newDict['name']=cleanGSKnames(newDict['name'],newDict['taxid'])

    newDict['sequence']="".join(newDict['sequence'])
    newDict['snps']={}

    for varObj in DBSession.query(target_sequence_variation).filter(target_sequence_variation.target_id==tid).all():

        varObj=dumprow(varObj)

        newDict['snps'][varObj['aa_position']]=varObj


    holder.append(newDict)

    return holder




def text_search(querystring):
    '''
    Simple string comparison on key columns rather than index/whoosh/solr

    To keep in line with the other searches, return an array of objects with target_id properties

    '''

    searchhits=set()


    records = DBSession.query(target_synonym).filter(target_synonym.value.ilike('%'+querystring+'%')).all()

    for record in records:
        searchhits.add(record.target_id)

    records = DBSession.query(target_xref).filter(target_xref.value.ilike('%'+querystring+'%')).all()

    for record in records:
        searchhits.add(record.target_id)


    records = DBSession.query(target).filter(or_(target.full_name.ilike(querystring),target.function.ilike(querystring),target.name.ilike('%'+querystring+'%'))).all()

    for record in records:
        searchhits.add(record.id)

    #Turn the set into a list => Unique array of target ids.
    searchhits=list(searchhits);

    returnhits=[]

    for tid in searchhits:

        targetObj={}
        targetObj['target_id']=tid
        returnhits.append(targetObj)

    return returnhits


def get_suggestion(querystring):
    ''' Simple string comparison on key columns rather than index/whoosh/solr returning single words '''

    searchhits=set()

    exactMatch = re.compile(querystring,re.I)

    records = DBSession.query(target_synonym).filter(target_synonym.value.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.value):
            if re.search(querystring, word, re.I):
                searchhits.add(word)

    records = DBSession.query(target_xref).filter(target_xref.value.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.value):
            if re.search(querystring, word, re.I):
                searchhits.add(word)

    records = DBSession.query(target).filter(target.full_name.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.full_name):
            if re.search(querystring, word, re.I):
                searchhits.add(word)

    records = DBSession.query(target).filter(target.function.ilike(querystring)).all()
    for record in records:
        for word in multisplit(record.function):
            if re.search(querystring, word, re.I):
                searchhits.add(word)

    records = DBSession.query(target).filter(target.name.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.name):
            if re.search(querystring, word, re.I):
                searchhits.add(word)


    #target_xref_records = DBSession.query(target_xref).filter(target_xref.value.ilike('%'+querystring+'%').all()
    #
    #
    #for record in target_xref_records:
    #    hits.append(record.target_id)


    return list(searchhits)


def get_fasta_suggestion(querystring):
    ''' Simple string comparison on key columns rather than index/whoosh/solr returning single words '''

    searchhits=set()

    exactMatch = re.compile(querystring,re.I)

    foundsome=False

    records = DBSession.query(target).filter(target.taxid==9606).filter(target.gene_name.ilike('%'+querystring+'%')).all()
    for record in records:
        for word in multisplit(record.gene_name):
            if re.search(querystring, word, re.I):
                searchhits.add(word+'_'+str(record.id))
                foundsome=True

    if foundsome==False:

        records = DBSession.query(target).filter(target.taxid==9606).filter(target.uniprot_accession.ilike('%'+querystring+'%')).all()
        for record in records:
            for word in multisplit(record.uniprot_accession):
                if re.search(querystring, word, re.I):
                    searchhits.add(word+'_'+str(record.id))
                    foundsome=True

    if foundsome==False:
        records = DBSession.query(target).filter(target.taxid==9606).filter(target.function.ilike('%'+querystring+'%')).all()
        for record in records:
            for word in multisplit(record.function):
                if re.search(querystring, word, re.I):
                    searchhits.add(word+'_'+str(record.id))
                    foundsome=True

    if foundsome==False:
        records = DBSession.query(target).filter(target.taxid==9606).filter(target.full_name.ilike('%'+querystring+'%')).all()
        for record in records:
            for word in multisplit(record.full_name):
                if re.search(querystring, word, re.I):
                    searchhits.add(word+'_'+str(record.id))
                    foundsome=True




    return list(searchhits)

def multisplit(querystring):
    return re.split(' |,|\.|;|\(|\)|\[|\]|\:|\/',querystring)



def getTissueTypes():
    '''Get a list of known tissue types'''

    returnBox=[]

    box = DBSession.query(expression_tissue).all()

    tissueObj = {}

    for tissue in box:

        tissue=dumprow(tissue)

        tissueid = tissue['id']
        tissue = tissue['tissue']

        tissueObj[tissueid]=tissue


    returnBox.append(tissueObj)
    return returnBox

def getCellTypes():
    '''Get a list of known cell types'''

    returnBox=[]

    box = DBSession.query(expression_cell_type).all()

    cellObj={}

    for cell in box:
        cell=dumprow(cell)

        cellid = cell['id']
        celltype = cell['cell_type']

        cellObj[cellid]=celltype

    returnBox.append(cellObj);

    return returnBox


def generateTargetsFromMols(session):

    # Generate the list of targets associated with these compounds
    targethits = DBSession.query(target.id) \
    .distinct(target.id) \
    .join(chembl_2_uniprot,target.chembl_target_component_id==chembl_2_uniprot.component_id) \
    .join(assays,chembl_2_uniprot.tid==assays.tid) \
    .join(activities,assays.assay_id==activities.assay_id) \
    .join(simsubhits,activities.molregno==simsubhits.molregno) \
    .filter(simsubhits.sessionid==session.get_csrf_token())

    session['hittids']=[]

    session['hitsource']='simsub'

    for hit in targethits:
        session['hittids'].append(hit.id)


def getSimSub(ctab,simsubval,session):
    '''Get a set of molecules via a similarity or substructure search. Results go into session temporary table'''

    sessionid=session.get_csrf_token()

    clearHitsTable(sessionid)

    try:
        if int(ctab)==0:
            return
        else:
            pass
    except:
        pass

    # If simubval == 100 then we're performing a substructure. A full molecule will return it's exact match anyway, unless we want superstructure searching...
    returnregnos=[]

    #try:
    #    DBSession.execute("begin execute immediate 'truncate table simsubhits'; exception when others then null; end;")
    #except:
    #    pass

    if float(simsubval) < 100:

        sql1 = "insert into simsubhits SELECT molregno,similarity(3) "
        sql2 = '"SIM"'
        sql3 = " ,'"+sessionid+"' "" FROM compound_mols cm WHERE similar(cm.CTAB, '"+ctab+"', '"+simsubval+"',3) = 1 "

        sql=sql1+sql2+sql3

    else:

        sql = "insert into simsubhits SELECT molregno, -1, '"+sessionid+"' FROM compound_mols cm WHERE sss(cm.CTAB, '"+ctab+"') = 1"

    DBSession.execute(sql)

    hitscount = DBSession.query(simsubhits).filter(simsubhits.sessionid==sessionid).count()

    #Get associated targets
    generateTargetsFromMols(session)

    return hitscount


def getMolInfo(inputTuples,session,export):
    '''Return Sim/Sub search hit info for a datatable running serverside

    Also, if there are hits defined (from predictive searches) filter mols by target.

    '''

    returnObj = {}
    returnmols=[]
    moldicthashes=[]
    opsDict={}
    hitscount=0

    sessionid=session.get_csrf_token()

    hitscount = DBSession.query(simsubhits).filter(simsubhits.sessionid==sessionid).count()

    for tup in inputTuples.items():

        opsDict[tup[0]]=tup[1]

    returnObj['sEcho']=int(opsDict['sEcho'])

    # We can look for hits in either the results molecule table (from a sim/sub search)
    # or in the session (target IDs) and generate our output accordingly.

    if 'hittids' in session and session['hitsource']!='simsub':
        # This will control targets/mol hits.
        hittype=False

        #hitscount = DBSession.query(simsubhits).filter(simsubhits.sessionid==sessionid).count()
        hitscount = session['hittids'].__len__()

    else:

        hittype=True



    # Get a count of all compounds
    totalrecords = DBSession.query(compound_structures).count()

    mstart = int(opsDict['iDisplayStart'])
    mstop = mstart+int(opsDict['iDisplayLength'])



    sortingColumn = opsDict['mDataProp_'+opsDict['iSortCol_0']]
    sortingDirection = opsDict['sSortDir_0']
    sortingSQL = sortingColumn+' '+sortingDirection+' nulls last'

    if hitscount > 0:# Test to see if we have hits from a search (and therfore a table to join against!) or a list of Targets

        if hittype:
            # We've got hits from a sim/sub search
            molQ = DBSession.query(compound_properties, compound_structures.canonical_smiles,simsubhits,molecule_dictionary.chembl_id) \
            .join(compound_structures, compound_properties.molregno==compound_structures.molregno)\
            .join(simsubhits, compound_properties.molregno==simsubhits.molregno) \
            .join(molecule_dictionary,compound_properties.molregno==molecule_dictionary.molregno)\
            .order_by(sortingSQL)\
            .filter(simsubhits.sessionid==sessionid)


            if export==False:
                molQ = molQ.slice(start=mstart,stop=mstop)
        else:
            # We've got target ids, so pull in all mols per target

            molQ = DBSession.query(compound_properties,compound_structures.canonical_smiles,molecule_dictionary.chembl_id) \
            .join(compound_structures, compound_properties.molregno==compound_structures.molregno)\
            .join(activities,compound_properties.molregno==activities.molregno) \
            .join(assays,activities.assay_id==assays.assay_id) \
            .join(chembl_2_uniprot,assays.tid==chembl_2_uniprot.tid) \
            .join(target,chembl_2_uniprot.component_id==target.chembl_target_component_id) \
            .join(molecule_dictionary,compound_properties.molregno==molecule_dictionary.molregno)\
            .filter(target.id.in_(session['hittids'])) \
            .distinct(compound_properties.molregno) \
            .order_by(sortingSQL)

            #Update the hitscount
            hitscount=molQ.count()


            if export==False:
                molQ=molQ.slice(start=mstart,stop=mstop)
                #molQ=molQ[mstart:mstop]

        for i,mol in enumerate(molQ):

            if hittype:
                molObj1, molObj2, molObj3, molObj4 = mol


                molObj1=dumprow(molObj1)
                molObj3=dumprow(molObj3)

                molPropsDict = dict(molObj1.items() + molObj3.items())

                molPropsDict['canonical_smiles'] = molObj2
                molPropsDict['chembl_id'] = molObj4

            else:

                molObj4,molObj5,molObj6 = mol
                #molObj1, molObj2, molObj3, molObj4,

                molObj4=dumprow(molObj4)


                molPropsDict = dict(molObj4.items())

                molPropsDict['canonical_smiles'] = molObj5

                molPropsDict['chembl_id'] = molObj6

                molPropsDict['sim']=-1

            if 'insert_date' in molPropsDict:
                del molPropsDict['insert_date']

            if 'molfile_update' in molPropsDict:
                del molPropsDict['molfile_update']

            if export==False:

                if 'molfile' in molPropsDict:
                    del molPropsDict['molfile']


            returnmols.append(molPropsDict)

        returnObj['iTotalRecords']=returnmols.__len__()

    else:

        if sortingColumn == 'sim':
            sortingSQL = 'mw_freebase'+' '+sortingDirection+' nulls last'

        molQ = DBSession.query(compound_properties, compound_structures.canonical_smiles,molecule_dictionary.chembl_id)\
        .join(compound_structures, compound_properties.molregno==compound_structures.molregno)\
        .join(molecule_dictionary,compound_properties.molregno==molecule_dictionary.molregno)\
        .order_by(sortingSQL)

        if export == False:
            molQ = molQ.slice(start=mstart,stop=mstop)

        for mol in molQ:

            molObj1, molObj2, molObj3 = mol

            molObj1=dumprow(molObj1)


            molPropsDict = dict(molObj1.items())
            molPropsDict['chembl_id'] = molObj3
            molPropsDict['canonical_smiles'] = molObj2

            if 'insert_date' in molPropsDict:
                del molPropsDict['insert_date']

            if 'molfile_update' in molPropsDict:
                del molPropsDict['molfile_update']

            if export==False:
                molPropsDict['sim']=-1

                if 'molfile' in molPropsDict:
                    del molPropsDict['molfile']

            returnmols.append(molPropsDict)

        # If we've filtered some results, we need a count for the table length.

    returnObj['iTotalRecords']=totalrecords

    if hitscount > 0:
        returnObj['iTotalDisplayRecords']=hitscount
    else:
        if hittype==False:
            returnObj['iTotalDisplayRecords']=0
        else:
            returnObj['iTotalDisplayRecords']=totalrecords



    returnObj['aaData']=returnmols

    if export == False:

        return returnObj
    else:
        opsDict['sessionid']=sessionid
        return parseExport(opsDict,returnmols,'moltable')

def clearHitsTable(sessionid):
    '''Delete the hits table associated with this session'''

    DBSession.query(simsubhits).filter(simsubhits.sessionid==sessionid).delete()


def cleanGSKnames(name,taxid):
    # String cleanup for GSK names

    if taxid == 1000009823:

        name = name.replace('_GLEAN_','_')
        name = name.replace('_MINIP','')
        name = name.replace('Minipig_','')

        return name

    elif taxid == 1000009615:

        name = name.replace('_GLEAN_','_')
        name = name.replace('_BEAGL','')
        name = name.replace('Beagle_','')

        return name

    elif taxid == 1000009544:

        name = name.replace('CR_','')
        name = name.replace('_MACMU','')

        return name
    elif taxid == 9541:

        name = name.replace('CE_','')
        name = name.replace('_MACFA','')

        return name

    else:
        return name


def parseExport(queryParams,dataObj,dataSource):

    '''Wow, this function features some nasty code reuse, and is generally a bit messy due to disparate data requirements... But, it handles all exports.'''

    newKeys=[]
    body=[]

    # Orthologue matrix export function
    if dataSource=='orthomatrix':


        taxids = get_taxids()
        classes = get_adme_classes()

        sources = get_adme_sources()

        lookupKeys = dataObj[0].keys()
        keptKeys = []

        taxlookup = {}
        taxlookup['target_id']='Human Target ID'
        taxlookup['geneid']='Gene Group'
        taxlookup['adme_class_id']='Class'
        taxlookup['source']='Source'
        taxlookup['function']='Function in Humans'

        for taxObj in taxids:
            if taxObj['taxid'] in lookupKeys:
                taxlookup[taxObj['taxid']]=taxObj['name']
                keptKeys.append(taxObj['taxid'])
                lookupKeys.remove(taxObj['taxid'])

        lookupKeys = lookupKeys + keptKeys


        for datum in dataObj:


            line=[]

            for lukey in lookupKeys:

                if type(datum[lukey]) == list:

                    sublist=[]

                    for blib in datum[lukey]:

                        blub = blib['ensembl'] if blib['ensembl']!=None else blib['uniprot'] if blib['uniprot']!=None else 'AS-'+str(blib['target_id'])

                        #sublist.append(str(blib['name_to']))
                        sublist.append(blub)

                    line.append(";".join(sublist))

                elif type(datum[lukey]) == str:

                    line.append(str(datum[lukey]))

                elif type(datum[lukey]) == dict:

                    line.append("")
                else:
                    if lukey=='adme_class_id':
                        line.append(str(classes[datum[lukey]]))
                    elif lukey=='source':
                        line.append(str(sources[datum[lukey]]))
                    else:
                        line.append(str(datum[lukey]))

            body.append("\t".join(line))

        top = "\t".join(taxlookup[x] for x in lookupKeys)
        bottom = "\n".join(body)

        return top+'\n'+bottom


    # Tissue matrix export function
    if dataSource == 'tissuematrix':

        tissues = get_adme_tissues()
        cells =  get_adme_cells()
        headerLine=[]

        lookupKeys = dataObj[0].keys()
        lookupKeys.remove('gene_id') #Not a column to expose at top level, but rather 4 nested...
        tissueFields = {}
        tissueFields['tid']='Human Target ID'
        tissueFields['fullname']='Full name'
        tissueFields['gene']='Gene'
        tissueFields['name']='Gene group'

        for key in lookupKeys:
            if key=='gene_id':
                pass
            else:
                headerLine.append(tissues[key].replace(',',':'))

        lookupKeys=tissueFields.keys()+lookupKeys

        headerLine = tissueFields.values() + headerLine

        for tissueRow in dataObj:

            line=[]

            for column in lookupKeys:

                if type(column)==str:
                    line.append(str(tissueRow['gene_id'][column]).replace(',','_'))
                else:
                    subline=[]

                    for cell in tissueRow[column].keys():
                        expressionString = str(cells[cell])+'|Level:'+str(tissueRow[column][cell]['exp_level'])+'|Type:'+str(tissueRow[column][cell]['expression_type'])+'|Reliabillity:'+str(tissueRow[column][cell]['reliability'])
                        subline.append(expressionString)
                    line.append(";".join(subline))
            body.append("\t".join(str(x) for x in line))

        top="\t".join(headerLine)
        bottom = "\n".join(body)

        return top+'\n'+bottom



    # Activities table
    if dataSource == 'activitytable' or dataSource == 'full_invivomatrix' or dataSource =='invivomatrix':

        lookupkeys = []

        if dataSource !='invivomatrix':
            for qkey in queryParams:
                if qkey.startswith('mDataProp'):
                    lookupkeys.append(queryParams[qkey])
        else:

            for i in dataObj:
                for k in i.keys():
                    if k not in lookupkeys:
                        lookupkeys.append(k)

            if 'sortedby' in lookupkeys:
                lookupkeys.remove('sortedby')

            if 'sortbyme' in lookupkeys:
                lookupkeys.remove('sortbyme')

        if 'molregno' in lookupkeys:
            lookupkeys.remove('molregno')


        if dataSource == 'activitytable':
            if 'published_value' in lookupkeys:
                lookupkeys.remove('published_value')

            if 'published_relation' in lookupkeys:
                lookupkeys.remove('published_relation')

            if 'published_type' in lookupkeys:
                lookupkeys.remove('published_type')

            if 'assay_organism' in lookupkeys:
                lookupkeys.remove('assay_organism')

            if 'published_units' in lookupkeys:
                lookupkeys.remove('published_units')

            if 'invivo' in lookupkeys:
                lookupkeys.remove('invivo')

        if 'chemblid'  in lookupkeys:
            lookupkeys.remove('chemblid')

        if 'chembl_id'  in lookupkeys:
            lookupkeys.remove('chembl_id')

        lookupkeys.insert(0,'chembl_id')
        lookupkeys.insert(1,'canonical_smiles')

        if dataSource == 'full_invivomatrix':
            lookupkeys.insert(2,'standard_value_avg')


        #lookupkeys = ['chembl_id','description','assay_organism','standard_type','standard_relation','standard_value','standard_units']
        #headerLine = ['ChEMBL ID','Description','Organism','Standard type','Standard relation','Standard value','Standard units']

        if 'format' not in queryParams:
            queryParams['format']='tsv'

        if queryParams['format']=='sdf':

            for mol in dataObj:

                ctab = DBSession.query(compound_structures.molfile).filter(compound_structures.molregno==mol['molregno']).first()[0]
                #chemblid = DBSession.query(molecule_dictionary.chembl_id).filter(molecule_dictionary.molregno==mol['molregno']).first()[0]


                if 'molfile' in mol:
                    del mol['molfile']

                if 'sessionid' in mol:
                    del mol['sessionid']

                body.append(ctab)

                #body.append('>  <CHEMBL_ID>'+'\n'+chemblid+'\n')

                for propname in mol:
                    if propname=='molformula' or mol[propname]==-1 and propname=='sim' or propname=='molregno' or propname=='acd_most_bpka' or   propname=='acd_most_apka':
                        pass
                    else:
                        body.append('>  <'+str(propname)+'>'+'\n'+str(mol[propname])+'\n')





                body.append('$$$$')

            body = "\n".join(body)
            return body

        if queryParams['format']=='tsv':

            if 'molregno' in lookupkeys:
                lookupkeys.remove('molregno')


            smilescache = {}

            for datum in dataObj:

                line=[]

                # Cache SMILES lookup, to speed up export for multiple compounds.

                if 'canonical_smiles' not in datum:

                    if datum['molregno'] in smilescache:

                        datum['canonical_smiles'] = smilescache[datum['molregno']]

                    else:

                        molinfrow = DBSession.query(compound_structures).filter(compound_structures.molregno==datum['molregno']).first()
                        datum['canonical_smiles'] = molinfrow.canonical_smiles
                        smilescache[datum['molregno']]=datum['canonical_smiles']


                for key in lookupkeys:

                    if dataSource!='invivomatrix':

                        if key in datum:

                            line.append(str(datum[key]).replace(',','_').replace('None',''))

                    else:


                        if key in datum:

                            if type(datum[key])!=dict:
                                line.append(str(datum[key]))
                            else:
                                specieskeys = datum[key].keys()

                                subline = []

                                for species in specieskeys:

                                    score=''

                                    if datum[key][species]['score']==3:
                                        score='High'

                                    if datum[key][species]['score']==2:
                                        score='Med'

                                    if datum[key][species]['score']==1:
                                        score='Low'


                                    subline.append(species+':'+score)

                                line.append(";".join(subline))


                        #elif key=='canonical_smiles':
                        #    smiles = DBSession.query(compound_structures.canonical_smiles).filter(compound_structures.molregno==datum['molregno']).first()[0]
                        #    line.append(smiles)

                        else:
                            line.append('')

                body.append("\t".join(line))

            top="\t".join(lookupkeys)
            bottom = "\n".join(body)

            return top+'\n'+bottom

    # Molecule table -> Return an SDF or TSV file
    if dataSource == 'moltable':

        # DRY!!!!  No, this is quite wet! Functions below can be added together.

        if queryParams['format']=='sdf':

            for mol in dataObj:

                ctab = DBSession.query(compound_structures.molfile).filter(compound_structures.molregno==mol['molregno']).first()[0]
                #chemblid = DBSession.query(molecule_dictionary.chembl_id).filter(molecule_dictionary.molregno==mol['molregno']).first()[0]


                if 'molfile' in mol:
                    del mol['molfile']

                if 'sessionid' in mol:
                    del mol['sessionid']

                body.append(ctab)

                #body.append('>  <CHEMBL_ID>'+'\n'+chemblid+'\n')

                for propname in mol:
                    if propname=='molformula' or mol[propname]==-1 and propname=='sim' or propname=='molregno' or propname=='acd_most_bpka' or   propname=='acd_most_apka':
                        pass
                    else:
                        body.append('>  <'+str(propname)+'>'+'\n'+str(mol[propname])+'\n')





                body.append('$$$$')

            body = "\n".join(body)
            return body


        # Molecule table -> Return a TSV file
        if queryParams['format']=='tsv':



            headerLine=dataObj[0].keys()
            if 'sessionid' in headerLine:
                headerLine.remove('sessionid')

            if 'molfile' in headerLine:
                headerLine.remove('molfile')

            if 'molregno' in headerLine:
                headerLine.remove('molregno')

            if 'canonical_smiles' in headerLine:
                headerLine.remove('canonical_smiles')

            if 'molformula' in headerLine:
                headerLine.remove('molformula')

            if 'acd_most_bpka' in headerLine:
                headerLine.remove('acd_most_bpka')

            if 'acd_most_apka' in headerLine:
                headerLine.remove('acd_most_apka')

            if 'chembl_id' in headerLine:
                headerLine.remove('chembl_id')



            if dataObj[0]['sim']==-1:
                if 'sim' in headerLine:
                    headerLine.remove('sim')



            headerLine.insert(0,'chembl_id')
            headerLine.insert(1,'canonical_smiles')



            body.append("\t".join(headerLine))



            for mol in dataObj:
                line = []

                for key in headerLine:

                    if key in mol:
                        line.append(str(mol[key]))
                    else:
                        line.append("")

                body.append("\t".join(line))

            body = "\n".join(body)
            return body





def table_dumps(**kwargs):

    '''

        Dump out tables to files, stripping mols into an sdf file.
        Optional 'path' argument to dump to a specific folder and 'overwrite' to, well, y'know...
        Gives visual feedback on progress. Blinking cursor is dull to watch!

    '''
    overwrite = False

    if 'path' in kwargs:
        if kwargs['path'].__len__()>0:
            path = kwargs['path']
    else:
        path = './'

    if 'overwrite' in kwargs:
        overwrite = kwargs['overwrite']

    csv_dump = (
        activities,
        assays,
        chembl_2_uniprot,
        compound_structures,
        compound_properties,
        compound_mols,
        docs,
        molecule_dictionary,
        target_source,
        target_source_type,
        target,
        target_clusters,
        target_sequence_variation,
        target_sequence,
        target_classification,
        #target_pfam,
        #target_scop,
        target_scop_match_regions,
        target_alignment,
        target_xref,
        target_synonym,
        target_dictionary,
        synonym_type,
        synonym_source,
        xref_type,
        adme_class,
        taxonomy,
        orthologue_mapping,
        protein_atlas_expression,
        protein_atlas_subcell_location,
        expression_tissue,
        expression_cell_type,
        target_protein_expression,
        adme_invivo_ranges
    )


    for table in csv_dump:

        # Just in case we don't want to clobber existing exports
        if os.path.isfile(path+'/adme_sarfari_'+table.__tablename__+'.csv.gz') and overwrite == False:
            print 'Found '+table.__tablename__+'.csv.gz in '+path+' -> Not exporting'
            continue

        count = DBSession.query(table).count()

        # We have some empty tables
        if count == 0:
            print table.__tablename__+' is empty!'
            continue

        select = sqla.sql.select([table])
        result = DBSession.execute(select)


        fh = gzip.open(path+'/adme_sarfari_'+table.__tablename__+'.csv.gz', 'wb')
        outcsv = csv.writer(fh)

        headers = result.keys()

        removeindex=None

        if 'molfile' in headers:
            removeindex = headers.index('molfile')
            del headers[removeindex]

        if removeindex != None:
            sdffh = gzip.open(path+'adme_sarfari_'+table.__tablename__+'_molecules.sdf.gz', 'wb')

        outcsv.writerow(headers)

        point = count/100

        increment = count/20

        if point == 0:
            point = 100

        if increment == 0:
            increment = 20

        sys.stdout.write('\n')

        for i,row in enumerate(result):

            if removeindex != None:

                row = list(row)

                sdf = row.pop(removeindex)

                molregno=str(int(row[0]))

                outcsv.writerow(row)
                sdffh.write(molregno)
                sdffh.write(sdf)
                sdffh.write('\n$$$$\n')

            else:

                outcsv.writerow(row)

            try:
                if(i % (5 * point) == 0):
                    sys.stdout.write("\r"+table.__tablename__+":[" + "=" * (i / increment) +  " " * ((count - i)/ increment) + "]" +  str(i / point) + "% ")
                    sys.stdout.flush()
            except:
                    sys.stdout.write("\r"+table.__tablename__+":[" + "=" * (i / increment) +  " " * ((count - i)/ increment) + "]" +  str(i / point) + "% ")
                    sys.stdout.flush()

        fh.close

        sys.stdout.write('\n')

























def eb_eye_dump():
    from genshi.template import MarkupTemplate
    to_dump = (
        activities,
        assays,
        #chembl_2_uniprot,
        #compound_structures,
        #compound_properties,
        #compound_mols,
        docs,
        molecule_dictionary,
        #target_source,
        #target_source_type,
        target,
        target_clusters,
        #target_sequence_variation,
        target_sequence,
        #target_classification,
        #target_pfam,
        #target_scop,
        #target_scop_match_regions,
        target_alignment,
        #target_xref,
        #target_synonym,
        target_dictionary,
        #synonym_type,
        #synonym_source,
        #xref_type,
        adme_class,
        #taxonomy,
        #orthologue_mapping,
        #protein_atlas_expression,
        #protein_atlas_subcell_location,
        expression_tissue,
        expression_cell_type,
        target_protein_expression,
        #adme_invivo_ranges
    )

    tpl_xml = '''
    <p py:for="i in data">${i}</p>
    '''
    import time

    for table in to_dump:

        count = str(DBSession.query(table).count())

        tabledata = DBSession.query(table)

        dumptable = Base.metadata.tables[table.__tablename__]

        additional_fields = []

        for col in dumptable.columns:

            additional_fields.append(col.name.replace(table.__tablename__+'.',''))

        primary_key = dumptable.primary_key.columns.keys().pop() # This assumes we can use the first primary key

        reldate = time.strftime("%Y-%m-%d")

        tpl_xml ='''<?xml version="1.0" encoding="UTF-8"?>
        <database xmlns:py="http://genshi.edgewall.org/">
         <name>ADMESARfari.${tablename}</name>
         <description>ADME SARfari ${tablename} data</description>
         <release>1.0</release>
         <release_date>${reldate}</release_date>
         <entry_count>${count}</entry_count>
            <entries>
                <entry py:for="d in tabledata" id="${d[pk]}">

                    <additional_fields>
                    <field py:for="f in additional_fields" name="${f}">${d[f]}</field>
                    </additional_fields>

                </entry>
            </entries>
         </database>'''

        '''<additional_fields>
                    py:for="f in additional_fields">
                        <field name="${f}">
                            ${f}
                        </field>
                </additional_fields>
        '''


        tpl = MarkupTemplate(tpl_xml)
        stream = tpl.generate(pk=primary_key,reldate=reldate,count=count,tablename=table.__tablename__,tabledata=tabledata,additional_fields=additional_fields)

        with open('eb_eye_dumps/'+table.__tablename__+'.xml', 'w') as f:
            stream.render(out=f)


        #
        #
        #'''
        #  <entry id="1">
        #   <cross_references>
        #    <ref dbname="ChEMBL-Target" dbkey="CHEMBL1907607"></ref>
        #    <ref dbname="ChEMBL-Target" dbkey="CHEMBL2096683"></ref>
        #   </cross_references>
        #   <additional_fields>
        #    <field name="description">Gamma-aminobutyric acid receptor subunit pi</field>
        #    <field name="component_type">PROTEIN</field>
        #    <field name="accession">O09028</field>
        #    <field name="component_synonym">Gabrp</field>
        #    <field name="component_synonym">Gamma-aminobutyric acid receptor subunit pi</field>
        #    <field name="component_synonym">GABA(A) receptor subunit pi</field>
        #   </additional_fields>
        #  </entry>
        #  '''
        #
        #
        #


        #
