'''
Custom HTTP errors for ADMESarfari
@author:Nathan Dedman
@company: EBI, Hinxton.
'''
from pyramid.response import Response
import json

def errorhandler(*args, **kwargs):
    
    ''' Returns a more verbose error object '''
    
    try:
        errortype = kwargs.get('errortype')
    except:
        pass
    
    try:
        request = kwargs.get('request')
    except:
        pass
    
    try:
        DBAPIError = kwargs.get('DBAPIError')
    except:
        pass
    
    errorobj = {}
    
    
    if DBAPIError:
        errorobj['statement'] = DBAPIError.statement
        errorobj['params'] = DBAPIError.params
    
    
    if(errortype==400):
    
        errorobj['error'] = 'Invalid target identifier'
        errorobj['request_uri'] = request.url
    
        return Response(json.dumps(errorobj), content_type='application/json', status_int=400)
    
    if(errortype==404):
    
        errorobj['error'] = 'Target not found'
        errorobj['request_uri'] = request.url
    
        return Response(json.dumps(errorobj), content_type='application/json', status_int=404)

    if(errortype==422):
    
        errorobj['error'] = 'Invalid input'
        errorobj['request_uri'] = request.url
    
        return Response(json.dumps(errorobj), content_type='application/json', status_int=422)
    


    if(errortype==500):
    
        errorobj['error'] = 'Internal Server Error'
        errorobj['request_uri'] = request.url
    
        return Response(json.dumps(errorobj), content_type='application/json', status_int=500)