'''
REST API for ADMESARfari
@author:Nathan Dedman
@company: EBI, Hinxton.
'''
from pyramid.response import Response
from pyramid.exceptions import *
from pyramid.view import view_config
from pyramid.threadlocal import get_current_registry

from cornice.service import Service,get_services
from cornice import Service
from cornice.ext.spore import generate_spore_description

import json,string,urllib2,pickle,os,urllib,cPickle,gzip,StringIO


from errorhandler import *
from returnhandler import *
from sequenceops import *
from models import *
from cheminfo import chemworker,chempupil


''' Service descriptions for REST endpoints'''
bioactivity = Service(name='bioactivity', path='/rest/{MOLREGNO}/bioactivity',description='Retrieve bioactivity data against multiple assays for this compound')
targetbioactivity = Service(name='targetbioactivity', path='/rest/{TARGET_ID}/targetbioactivity',description='Retrieve bioactivity data against multiple assays for this target')
ctabmodelprediction2 = Service(name='modelpredictor2',path='/rest/{CTAB}/modelpredictor2',description='Calculate ADME SARfari model results')
ctabmodelprediction2_post = Service(name='modelpredictor2',path='/rest/modelpredictor2',description='Calculate ADME SARfari model results')
orthomap = Service(name='orthologuematrix',path='/rest/orthologuematrix/{TAX_IDS}',description='Generate the orthologue map')
tissuemap = Service(name='expressionmatrix',path='/rest/expressionmatrix/{TISSUE_IDS}',description='Generate the tissue/expression map')
blast = Service(name='blast',path='/rest/{FASTA}/blast',description='Run BLAST for input sequence against ADME SARfari target sequences')
blast_post = Service(name='postblast',path='/rest/blast',description='Run BLAST for input sequence against ADME SARfari target sequences')
searchterm = Service(name='textsearch',path='/rest/{TEXT}/search',description='Perform a text based query.')
target = Service(name='target',path='/rest/target/{TARGET_ID}',description='Retrieve Target data')
target_alignment = Service(name='targetalignment',path='/rest/targetalignment/{TARGET_ID}/{TAX_IDS}',description='Retrieve Target alignment data')
target_sequence = Service(name='targetsequence',path='/rest/targetsequence/{TARGET_ID}',description='Retrieve Target Sequence data')
suggestion = Service(name='textsuggest',path='/rest/{TEXT}/suggest',description='Retreive potentially matching terms from designated tables.')
fasta = Service(name='fastasuggest',path='/rest/{TEXT}/fasta_suggest',description='Retreive potentially matching terms from the target tables.')
taxids  = Service(name='taxids',path='/rest/taxids',description='Retreive a list of Taxonomy IDs used.')
tissue  = Service(name='tissues',path='/rest/tissues',description='Retreive the set of tissues used')
cell  = Service(name='celltypes',path='/rest/celltypes',description='Retreive the set of cells used')
simsubsdf_post = Service(name='postsimsubsdf', path='/rest/simsubsdf/{VALUE}',description='Retreive a set of molecules via similarity to the input molecule or via substructure,return an SDF')
fullinvivomatrx = Service(name='fullinvivomatrix',path='/rest/fullinvivomatrix',description='Generate the full In vivo matrix')
file_upload = Service(name='upload',path='/rest/upload',description='File upload')
targetcompounds = Service(name='targetcompounds',path='/rest/{TARGET_ID}/targetcompounds',description='Retreive a set of SMILES strings associated with the AS target')
targetinvivodata = Service(name='targetinvivomatrix',path='/rest/{TARGET_ID}/targetinvivomatrix',description='Retreive all the binned invivo values for a particular AS target')
target_alignment_dendrogram = Service(name='alignmentdendrogram',path='/rest/alignmentdendrogram/{TARGET_ID}/{TAX_IDS}',description='Retrieve Target alignment dendrogram data')


''' Methods should only be used by the interface internally, so add to exclusion list for SPORE representation '''
clear_hits = Service(name='deletehits',path='/rest/deletehits',description='Remove hits from a session')
alignmentdepict = Service(name='depictalignment',path='/rest/{ID}/depictalignment',description='Generate a coloured multiple alignment HTML chunk')
chembldescriptors = Service(name='chembldescriptors',path='/rest/{SMILES}/chembldescriptors',description='Calculate CHEMBL specific descriptors')
tissue_target  = Service(name='expression',path='/rest/{TARGET_ID}/expression/{TISSUE_SET}',description='Retreive the set of expression levels for the tissues against this target')
simsub = Service(name='simsubsearch', path='/rest/{INPUT}/simsub/{VALUE}',description='Retreive a set of molecules via similarity to the input molecule or via substructure')
simsub_post = Service(name='postsimsub', path='/rest/simsub/{VALUE}',description='Retreive a set of molecules via similarity to the input molecule or via substructure')
test = Service(name='test', path='/rest/status',description='Status test')
spore = Service(name='spore', path='/rest/spore',description='SPORE endpoint', renderer='json')
smiles2ctab = Service(name='smiles2ctab',path='/rest/{SMILES}/smiles2ctab',description='Convert SMILES string to CTAB')
image_to_mol = Service(name='imagetomol',path='/rest/osra',description='OSRA image to SMILES conversion')
model_list = Service(name='modellist', path='/rest/models',description='Return a list of current classification models and their respective accuracies')
model_build = Service(name='modelbuild', path='/rest/generatemodel',description='Build the model for all ADME SARfari molecules')
molinfo = Service(name='molinfo', path='/rest/molinfo',description='Retreive a set of molecules and associated data via a molregno')
cleanup = Service(name='cleanup',path='/rest/{INPUT}/cleanup',description='Cleanup geometry')
delete_session = Service(name='deletesession',path='/rest/deletesession',description='Delete session contents')
ctab2image = Service(name='ctab2image',path='/rest/{CTAB}/ctab2image/{SIZE}',description='Convert CTAB string to base64 PNG image')
invivomatrx = Service(name='invivomatrix',path='/rest/invivomatrix/{TAX_IDS}/{SORT_PROPERTY}',description='Generate the In vivo matrix')
download = Service(name='export', path='/rest/export/{FLAG}',description='Export the last set of results/filtered results obtained in a session')

exclusionlist = ['simsubsearch','postsimsub','deletesession','imagetomol','test','aligndendro','smiles2ctab','imagetomol','modellist','modelbuild','cleanup','deletesession','ctab2image','deletehits','spore','upload','invivomatrix','download','simsub','simsub_post','chembldescriptors','export','textsuggest','fastasuggest','molinfo','fullinvivomatrix']

def zipit(something):
    ''' GZip a string to a gzip file contents with headers '''
    sio = StringIO.StringIO()
    gzip_file = gzip.GzipFile(fileobj=sio, mode='w')
    gzip_file.write(something)
    gzip_file.close()

    return sio.getvalue()

def saveQuery(request,qtype,qitem):
    '''Save the query and it's type in the session'''

    sessionObj = request.session

    sessionObj['qitem']=urllib.quote(qitem)
    sessionObj['qtype']=qtype

    sessionObj.changed()

def readUpload(uploadedfile):

    parsedupload=[]

    uploadedfile.seek(0)

    while True:
        data = uploadedfile.read(2<<16)
        if not data:
            break
        parsedupload.append(data)

    return "\n".join(parsedupload)


@file_upload.put()
def upload(request):
    '''Upload an input file'''


    try:
        filename = request.POST['file'].filename
        inputfile = request.POST['file'].file

        filenameparts = filename.split(".")

        inputtext=readUpload(inputfile)

        # Accepted file suffixes
        molaccepted=['sdf','SDF','mol','MOL','ctab','CTAB','SMI','smi']

        protaccepted=['FASTA','fasta','FA','fa']

        try:

            if filenameparts[1] in molaccepted:

                rdkitrunner = chemworker()

                parsedctab = rdkitrunner.parseUploadFile(inputtext)

                return {'item':parsedctab,'type':'CTAB'}

            elif filenameparts[1] in protaccepted:

                token = request.session.get_csrf_token() # We'll use the token to create a temporary web folder.

                raygun = blaster(inputtext,None,token)

                parsedprotfile = raygun.getFirstSeq()

                return {'item':parsedprotfile,'type':'FASTA'}
            else:
                return {'error':'File corrupted or incorrect format. Please try again.'}

        except:
            return {'error':'File corrupted or incorrect format. Please try again.'}
    except:
        return {'error':'File data missing!'}



@download.get()
def export(request):
    ''' Export the last set of results obtained/filtered in the desired format

    The FLAG parameter controls the operation, either building the export or serving it

    Values can be 'BUILD' or 'SERVE'
    '''

    #try:

    FLAG = request.matchdict['FLAG']
    paramDict = request.GET

    if FLAG == 'BUILD':

        if 'lastcall' in request.session:


            lastCallObj = request.session['lastcall']

            # Update the output file name based on format

            if 'format' in paramDict:
                if paramDict['format']=='sdf':
                    lastCallObj['filename'] = 'molecule_table.sdf.gz'

                if paramDict['format']=='tsv':
                    lastCallObj['filename'] = 'molecule_table.tsv.gz'

                # Appened the paramDict to the session paramDict to pass throught params

                oldParamDict = lastCallObj['params'][0]
                requestsession = lastCallObj['params'][1]
                exportbool = lastCallObj['params'][2]

                if 'format' in oldParamDict:
                    del oldParamDict['format']

                updatedParamDict= dict(paramDict.items() + oldParamDict.items())

                lastCallObj['params']=(updatedParamDict,requestsession,exportbool)

            method = globals().get(lastCallObj['method'])

            request.session['parsed_body'] = method(*lastCallObj['params'])

            return {'result':'export dataset created'}
        else:
            return {'result':'No query found to create dataset!'}

    if FLAG == 'SERVE':


        if 'lastcall' in request.session:

            lastCallObj = request.session['lastcall']

            dlResponse = Response(body=zipit(request.session['parsed_body']), content_type='application/octet-stream')

            dlResponse.content_disposition = 'attachment; filename='+lastCallObj['filename']

            return dlResponse
        else:
            return {'error':'No dataset found!'}
    #except:

        #return errorhandler(errortype=400,request=request)


@model_build.get()
def perform_model_build(request):
    '''

    Build multiclass Naive Bayesian model using RDKit and Scikit-Learn

    Will generate input molecules and fingerprints then train and validate model.
    '''

    modelbuilder = chempupil()
    status = modelbuilder.buildModel('GENERATE')


    #try:
    #   pyrasettings = get_current_registry().settings
    #
    #   if 'buildpermission' in pyrasettings and pyrasettings['buildpermission']=='True':
    #        modelbuilder = chempupil()
    #        status = modelbuilder.buildModel('GENERATE')
    #
    #        return {'result':status}
    #   else:
    #        return errorhandler(errortype=400,request=request)
    #except:
    #    return errorhandler(errortype=400,request=request)



@model_list.get()
def get_model_list(request):
    ''' Return a list of currently trained classification models and their respective accuracy.

    '''

    pyrasettings = get_current_registry().settings
    modelpath = pyrasettings['modelpath']

    modelsDict={}
    #modellist = open(modelpath+'/model.list','r')
    #
    #
    #for line in modellist:
    #    line.rstrip('\n')
    #    name,accuracy =line.split(',')
    #    modelsDict[name]=accuracy
    for files in os.listdir(modelpath):
        if files.endswith(".model"):


            loadedmodel = cPickle.load(file(modelpath+files,'rb'))
            accuracy = "%0.2f" % loadedmodel['accuracy']
            files = files.replace('.model','')

            modelsDict[files]=accuracy

    return modelsDict


@tissue.get()
def tissues(request):
    ''' Retrieve the list of tissues'''

    tissues=getTissueTypes();

    return {'results':tissues};


@cell.get()
def cells(request):
    ''' Retrieve the list of cell types'''

    tissues=getCellTypes();

    return {'results':tissues};


@bioactivity.get()
def getbioact(request):
    '''Retrieve the bioactivity and assay data for a particular molregno.

    Requires: Molregno (Int)

    If the Molregno == -1 then it will bring back all records

    Returns: Datatables format JSON.
    '''

    actinfoset=[]

    try:
        molregno = request.matchdict['MOLREGNO']
        paramDict = request.GET
    except Exception:
        return errorhandler(errortype=422,request=request)


    try:


        request.session['lastcall']={}
        request.session['lastcall']['params'] = (molregno,paramDict,request.session,True)
        request.session['lastcall']['method'] = 'getBiodata'
        request.session['lastcall']['filename'] = 'activity_data.tsv.gz'

        actinfoset = getBiodata(molregno,paramDict,request.session,False)

    except DBAPIError:

        return errorhandler(errortype=400,request=request,DBAPIError=DBAPIError)

    return parseresult(request=request,result=actinfoset)


@targetbioactivity.get()
def targgetbioact(request):
    '''Retrieve the bioactivity and assay data for a particular target

    Requires: ADME SARfari Target ID

    '''

    actinfoset=[]

    try:

        astid = request.matchdict['TARGET_ID']

    except Exception:

        return errorhandler(errortype=422,request=request)


    try:

        actinfoset = gettargbioactivity(astid)

    except DBAPIError:

        return errorhandler(errortype=400,request=request,DBAPIError=DBAPIError)

    return parseresult(request=request,result=actinfoset)

@targetcompounds.get()
def get_targetcompounds(request):

    '''Retrieve the compound SMILES associated with an ADME SARfari target (via activity)

    Requires: ADME SARfari Target ID

    '''

    actmolset=[]



    try:

        tastid = request.matchdict['TARGET_ID']

    except Exception:

        return errorhandler(errortype=422,request=request)


    try:

        actmolset = gettargetcompounds(tastid)

    except DBAPIError:

        return errorhandler(errortype=400,request=request,DBAPIError=DBAPIError)

    return parseresult(request=request,result=actmolset)

@cleanup.get()
def docleanup(request):
    '''
    Convert and clean the input

    Requires: Base64/URL encode SMILES or URL encoded CTAB

    Returns: CTAB
    '''

    try:

        INPUT = request.matchdict['INPUT']

    except:

        return errorhandler(errortype=400,request=request)


    #ppdispatch = ADME SARfariprotocols.pprunner()
    rdkitrunner = chemworker()

    try:

        #ctab = ppdispatch.cleanup(INPUT)
        ctab = rdkitrunner.cleanMolecule(INPUT)
    except:

        return errorhandler(errortype=500,request=request)

    return parseresult(request=request,result=ctab)

@image_to_mol.post()
def doimage2mol(request):
    '''
    Use OSRA to parse image for valid molecules, return as SMILES string.

    Requires: Binary encoded image.

    Returns: SMILES
    '''

    try:

        inputimage = request.body

    except:

        return errorhandler(errortype=400,request=request)


    #ppdispatch = ADME SARfariprotocols.pprunner()
    rdkitrunner = chemworker()

    try:

        smiles = rdkitrunner.imagetomol(inputimage)

        return {'result':smiles}

    except:

        return errorhandler(errortype=500,request=request)


@ctabmodelprediction2.get()
def ctabgetmodel2(request):
    '''Run the input CTAB through the ADME SARfari SciKit/RDKit Bayesian model.

    This requires a URL encoded CTAB'''

    try:

        ctab = request.matchdict['CTAB']
        #modeltype = request.matchdict['TYPE']
        saveQuery(request,'CTAB',ctab)

    except:

        return errorhandler(errortype=400,request=request)


    model = chemworker()

    try:

        prediction = model.runModel(ctab,'bnb_fp')

        returnarray=get_targets(prediction)

        request.session['hittids']=[]
        request.session['hitsource']='model'

        for result in returnarray:
            request.session['hittids'].append(result['target_id'])

    except StandardError:
        raise
        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':returnarray})

@ctabmodelprediction2_post.post()
def postctabgetmodel2(request):
    '''Run the input CTAB through the ADME SARfari SciKit/RDKit Bayesian model.

    This requires a URL encoded CTAB'''

    try:

        ctab = urllib.unquote(request.body)
        #modeltype = request.matchdict['TYPE']
        saveQuery(request,'CTAB',ctab)

    except:

        return errorhandler(errortype=400,request=request)


    model = chemworker()

    try:

        prediction = model.runModel(ctab,'bnb_fp')

        if 'error' in prediction[0]:
            return parseresult(request=request,result=prediction[0])
        
        returnarray=get_targets(prediction)

        request.session['hittids']=[]
        request.session['hitsource']='model'

        for result in returnarray:
            request.session['hittids'].append(result['target_id'])

    except StandardError:
        raise
        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':returnarray})

@invivomatrx.get()
def getinvivomatrix(request):
    '''Retrieves the invivo matrix for a specific set of Taxonomy IDs per set of compounds

    Requires: Comma seperated list of Taxonomy IDs, compounds taken from sim/sub result table.

    '''
    try:
        taxids = request.matchdict['TAX_IDS']
        paramDict = request.GET
        paramDict['sortprop']=request.matchdict['SORT_PROPERTY']
    except Exception:
        return errorhandler(400,request)

    try:

        request.session['lastcall']={}
        request.session['lastcall']['params'] = (taxids,paramDict,request.session,True)
        request.session['lastcall']['method'] = 'get_invivomatrix'
        request.session['lastcall']['filename'] = 'invivo_matrix.tsv.gz'

        results = get_invivomatrix(taxids,paramDict,request.session,False)


    except DBAPIError:

        return errorhandler(errortype=500,request=request,DBAPIError=DBAPIError)

    return results

@fullinvivomatrx.get()
def getfullinvivomatrix(request):
    '''Retrieves the invivo matrix for a specific set of Taxonomy IDs per compound

    Requires: Comma seperated list of Taxonomy IDs

    '''
    try:
        paramDict = request.GET
    except Exception:
        return errorhandler(400,request)

    try:

        request.session['lastcall']={}
        request.session['lastcall']['params'] = (paramDict,request.session,True)
        request.session['lastcall']['method'] = 'get_full_invivomatrix'
        request.session['lastcall']['filename'] = 'full_invivo_matrix.tsv.gz'

        results = get_full_invivomatrix(paramDict,request.session,False)


    except DBAPIError:

        return errorhandler(errortype=500,request=request,DBAPIError=DBAPIError)

    return results

@targetinvivodata.get()
def gettargetinvivodata(request):
    '''Retrieves the invivo matrix for a particular target

    Requires: ADME SARfari internal target id

    This will return an object with xcats,ycats and data elements (primarily used with the Highcharts Heatmap plugin.)

    '''
    try:

        astid = request.matchdict['TARGET_ID']

    except Exception:

        return errorhandler(400,request)

    try:

        results =  get_target_invivomatrix(astid)


    except DBAPIError:

        return errorhandler(errortype=500,request=request,DBAPIError=DBAPIError)

    return results



@orthomap.get()
def getorthomap(request):
    '''Retrieves the orthologue mapping matrix for a specific set of Taxonomy IDs.

    Requires: Comma seperated list of Taxonomy IDs

    '''
    try:
        taxids = request.matchdict['TAX_IDS']
        paramDict = request.GET
    except Exception:
        return errorhandler(400,request)

    results = get_orthomatrix(taxids,paramDict,request.session,False)

    try:

        request.session['lastcall']={}
        request.session['lastcall']['params'] = (taxids,paramDict,request.session,True)
        request.session['lastcall']['method'] = 'get_orthomatrix'
        request.session['lastcall']['filename'] = 'orthologue_matrix.tsv.gz'




    except DBAPIError:

        return errorhandler(errortype=500,request=request,DBAPIError=DBAPIError)

    return results

@tissuemap.get()
def gettissuemap(request):
    '''Retrieves the tissue target expression level matrix

    '''

    try:

        paramDict = request.GET
        tissueset = request.matchdict['TISSUE_IDS']

        request.session['lastcall']={}
        request.session['lastcall']['params'] = (tissueset,paramDict,request.session,True)
        request.session['lastcall']['method'] = 'get_expression_matrix'
        request.session['lastcall']['filename'] = 'tissue_matrix.tsv.gz'

        results = get_expression_matrix(tissueset,paramDict,request.session,False)

    except DBAPIError:

        return errorhandler(errortype=500,request=request,DBAPIError=DBAPIError)

    return results

@searchterm.get()
def getsearchterm(request):
    ''' Return a set of target ids where the search term appears'''

    #saveTextQuery(request.matchdict['TEXT'])
    results = text_search(request.matchdict['TEXT'])
    request.session['hittids']=[]
    request.session['hitsource']='text'


    for result in results:
        request.session['hittids'].append(result['target_id'])

    return {'results':results}


@taxids.get()
def gettaxids(request):
    ''' Return the list of taxonomy IDs used.'''

    taxids=get_taxids()

    return {'results':taxids}


@suggestion.get()
def textsuggestion(request):
    ''' Return a set of potential search terms which match the input text'''

    results = get_suggestion(request.matchdict['TEXT'])

    return {'results':results}

@fasta.get()
def fastasugguestion(request):
    ''' Return a set of potential targets'''

    results = get_fasta_suggestion(request.matchdict['TEXT'])

    return {'results':results}

@blast.get()
def runblast(request):

    '''BLAST the input sequence(s) against the ADME SARfari set of target sequences.

    This requires:

    * A URL encoded FASTA sequence (May extended to other formats via a keyword)
    '''

    token = request.session.get_csrf_token() # We'll use the token to create a temporary web folder.

    fasta = request.matchdict['FASTA']

    saveQuery(request,'FASTA',fasta)

    # Create a BLAST object
    raygun = blaster(fasta,None,token)

    request.session['hitsource']='model'

    # Returns: a dict
    status = raygun.blast()

    blastresults = raygun.blastids()

    request.session['hittids']={}

    for result in blastresults:

        request.session['hittids'][int(result['target_id'])]=float(result['percentid'])

    if status['status'] == 'completed':

        return {'results':blastresults}

    else:

        return {'error':status['statusmessage']}

@blast_post.post()
def postblast(request):

    '''BLAST the input sequence(s) against the ADME SARfari set of protein databases

    This requires a JSON encoded object:    
        
    '''

    token = request.session.get_csrf_token() # We'll use the token to create a temporary web folder.
    
    #Tokenise the query or assume we just have a fasta file - use defaults
    try:
        
        payload = dict([x.split("=") for x in request.body.split("&")])
    
        fasta = payload['fasta']
        fev = payload['fev']
        lcf = payload['lcf']
        
        if lcf == 'false':
            lcf = False
        
        if lcf == 'true':
            lcf = True
        
    except:
        
        fasta = request.body
        fev = 10
        lcf = False
        
    fasta = urllib.unquote(fasta)
    
    saveQuery(request,'FASTA',fasta)

    # Create a BLAST object
    raygun = blaster(fasta,None,token,fev,lcf)

    request.session['hitsource']='model'

    # Returns: a dict
    status = raygun.blast()

    blastresults = raygun.blastids()

    request.session['hittids']={}

    for result in blastresults:

        request.session['hittids'][int(result['target_id'])]=float(result['percentid'])

    if status['status'] == 'completed':

        return {'results':blastresults}

    else:

        return {'error':status['statusmessage']}


@target.get()
def targetinfo(request):
    ''' Return the Target information for a particular Target ID

    '''
    try:

        tid = request.matchdict['TARGET_ID']

    except:

        return errorhandler(errortype=400,request=request)

    try:

        targetinfo = get_target(tid)

    except:

        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':targetinfo})

@target_alignment.get()
def targetalign(request):
    ''' Return the alignment information for a particular Target ID

    '''
    try:

        tid = request.matchdict['TARGET_ID']
        tax = request.matchdict['TAX_IDS']
    except:

        return errorhandler(errortype=400,request=request)

    try:

        targetalignment = get_target_alignment(tid,tax)

    except:

        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':targetalignment})



@target_alignment_dendrogram.get()
def targetdendrogram(request):
    ''' Return the dendrogram tree information for a particular Target ID (from the relevant orthologues)

    Requires a target ID and a comma seperated list of tax IDs

    '''
    token = request.session.get_csrf_token() # We'll use the token to create a temporary web folder.

    try:

        tid = request.matchdict['TARGET_ID']
        tax = request.matchdict['TAX_IDS']

    except:

        return errorhandler(errortype=400,request=request)

    try:

        targetorthologues = get_sequence_set(tid,tax)
        clustalw=clustal(None,targetorthologues,token)
        newicktree = clustalw.createtree()


    except:

        return errorhandler(errortype=422,request=request)


    return parseresult(request=request,result={'phyloxml':newicktree})



@target_sequence.get()
def targetsequence(request):
    ''' Return the Target Sequence and Variation information for a particular Target ID

    '''
    try:

        tid = request.matchdict['TARGET_ID']

    except:

        return errorhandler(errortype=400,request=request)

    try:

        targetsequence = get_target_sequence(tid)

    except:

        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':targetsequence})


@clear_hits.get()
def clearhits(request):
    '''Delete any hits (generated via the model search) from the current session'''

    sessionid = request.session.get_csrf_token()



    try:
        if 'hittids' in request.session:
            del request.session['hittids']
            clearHitsTable(sessionid)
            return {'delete':'Success'}
        else:
            return {'delete':'No hits found!'}
    except Exception:
        return {'delete':'Failed'}

@delete_session.get()
def deletesession(request):
    '''Delete the contents of the current session (hits,queries)'''

    sessionid = request.session.get_csrf_token()

    if 'hittids' in request.session:
        del request.session['hittids']

    #getSimSub(0,0,request.session)
    clearHitsTable(sessionid)

    return {'results':'OK'}

@molinfo.get()
def getmolinfo(request):
    ''' Return the session results for the current similarity / substructure search.
    '''
    molinfoset=[]


    try:

        paramDict = request.GET


    except:

        return errorhandler(errortype=400,request=request)



    try:

        request.session['lastcall']={}
        request.session['lastcall']['params'] = (paramDict,request.session,True)
        request.session['lastcall']['method'] = 'getMolInfo'
        request.session['lastcall']['filename'] = 'molecule_table.sdf'

        molinfoset = getMolInfo(paramDict,request.session,False)


    except:

        return errorhandler(errortype=422,request=request)


    return parseresult(request=request,result=molinfoset)


@simsub.get()
def dosimsub(request):
    ''' Return a set of molecules via either a similarity or substructure search

    Requires:
    * URL escaped CTAB or SMILES
    * A similarity value (100 will perform a sub-structure search)

    This returns only a count of the hits. The results are stored in a temporary table against the curent session (cookie.)

    If INPUT=0 and VALUE=0, this will clear the current results set, i.e. a NULL search.

    '''


    clearhits(request)
    molinput = request.matchdict['INPUT']
    simsubval = request.matchdict['VALUE']
    sessionid = request.session.get_csrf_token()


    try:
        # Just to decide whether to add 'similarity' to drop sort menu on invivomatrix.


        if int(simsubval) == 100:

            request.session['searchtype']=0


        if int(simsubval) < 100 and int(simsubval)>0:

            request.session['searchtype']=1


        if molinput!='0':
            saveQuery(request,'CTAB',molinput)
        else:
            clearhits(request)

    except:

        return errorhandler(errortype=400,request=request)



    try:

        hitcount = getSimSub(molinput,simsubval,request.session)

    except:

        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':{'count':hitcount}})

@simsub_post.post()
def dosimsubpost(request):
    ''' Return a set of molecules via either a similarity or substructure search

    Requires:
    * The POST body to contain CTAB or SMILES
    * A similarity value (100 will perform a sub-structure search)

    This returns only a count of the hits. The results are stored in a temporary table against the curent session (cookie.)

    If INPUT=0 and VALUE=0, this will clear the current results set, i.e. a NULL search.

    '''
    try:
        clearhits(request)
        molinput = request.body
        simsubval = request.matchdict['VALUE']
        sessionid = request.session.get_csrf_token()

        if molinput!='0':
            saveQuery(request,'CTAB',molinput)
        else:
            clearhits(request)

    except:

        return errorhandler(errortype=400,request=request)



    try:

        hitcount = getSimSub(molinput,simsubval,request.session)

    except:

        return errorhandler(errortype=422,request=request)

    return parseresult(request=request,result={'results':{'count':hitcount}})


@simsubsdf_post.post()
def simsubsdfpost(request):
    ''' Return a set of molecules via either a similarity or substructure search

    Requires:
    * The POST body to contain CTAB or SMILES
    * A similarity cut-off value (100 will perform a sub-structure search)

    This returns a gzipped SDF file.

    '''
    try:
        clearhits(request)
        molinput = request.body
        simsubval = request.matchdict['VALUE']
        sessionid = request.session.get_csrf_token()

        if molinput!='0':
            saveQuery(request,'CTAB',molinput)
        else:
            clearhits(request)

    except:

        return errorhandler(errortype=400,request=request)

    try:


        results = zipit(getSimSubCTAB(molinput,simsubval,request.session))

        searchresponse = Response(body=results, content_type='application/octet-stream')

        searchresponse.content_disposition = 'attachment; filename=results.sdf.gz'

        return searchresponse


    except:

        return errorhandler(errortype=422,request=request)


@test.get()
def dotest(request):
    '''Test to see if the REST service / webserver and DB is running. Chances are if it's not running, you won't see this page either!'''

    try:
        if get_taxid('chicken')==9031:
            return "OK"
    except:
        return "DB_DOWN"



@spore.get()
def get_spore(request):
    '''Returns: the SPORE REST API description object in JSON format'''
    services = get_services(exclude=exclusionlist)

    return generate_spore_description(services,'REST API', request.application_url, '1.0')
