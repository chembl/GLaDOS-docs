from pyramid.config import Configurator
from pyramid_beaker import session_factory_from_settings
from sqlalchemy import engine_from_config
from pyramid.settings import *
import models, random, string,transaction
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import *

from pyramid.threadlocal import get_current_registry


#from security import groupfinder


#import pyramid_beaker


from sqlalchemy.orm import (
    scoped_session,
    sessionmaker
    )

from .models import DBSetup

from pyramid.threadlocal import get_current_request

def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application"""

    session_factory = session_factory_from_settings(settings)

    config = Configurator(settings=settings)
    config.set_session_factory(session_factory)
    DBSetup(settings)

    # Add in routes
    config.add_static_view('static', 'static', cache_max_age=3600)
    config.add_static_view(name='modelpath',path=settings['modelpath'])
    config.add_route('root', '/')
    config.add_route('rest', '/rest')
    config.add_route('orthomap', '/orthologues')
    config.add_route('tissuemap', '/tissues')
    config.add_route('target','/target/{tid}')
    config.add_route('alignment','/alignments/{tid}')
    config.add_route('login','/login')
    config.add_route('logout', '/logout')
    config.add_route('request','/request')
    config.add_route('admin','/admin')
    config.add_route('moltable','/molecules')
    config.add_route('activity','/bioactivity/{molregno}')
    config.add_route('acttableall','/bioactivities')
    config.add_route('invivomap','/pharmacokinetics')
    config.add_route('api', '/api')
    config.add_route('about','/about')
    #config.add_static_view('docs','docs/_build/html')

    config.scan()
    return config.make_wsgi_app()
