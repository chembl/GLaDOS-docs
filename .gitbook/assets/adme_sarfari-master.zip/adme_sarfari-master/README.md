ADMEsarfari
===========

V1.0 (Rev 30 from SVN, current production version)

This is the stripped down code base which could be used to build an egg. No dependencies are included (Blast, RDKit, etc)
